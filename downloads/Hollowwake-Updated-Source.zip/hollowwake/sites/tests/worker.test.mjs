import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Miniflare,Log,LogLevel,convertV4MiniflareOptions} from 'miniflare';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
const origin='https://hollowwake.test';
const temporary=await mkdtemp(join(tmpdir(),'hollowwake-d1-'));
const config={scriptPath:'dist/server/index.js',modules:true,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],cf:false,log:new Log(LogLevel.NONE),d1Databases:{DB:'hollowwake-test'},resourcePersistencePath:temporary,unsafeEnableSharedStorage:true,bindings:{PUBLIC_ORIGIN:origin,BETTER_AUTH_SECRET:randomBytes(48).toString('hex')}};
let mf;
async function request(path,data,cookie,token,{device=false}={}){
 const headers={...(data===undefined?{}:{'Content-Type':'application/json'}),...(cookie?{Cookie:cookie,...(device?{}:{Origin:origin})}:{}),...(token?{Authorization:'Bearer '+token}:{})};
 if(path.startsWith('/api/auth/')&&data!==undefined)headers.Origin=origin;
 const r=await mf.dispatchFetch(origin+path,{method:data===undefined?'GET':'POST',headers,...(data===undefined?{}:{body:JSON.stringify(data)})});
 const b=await r.json();return{r,b,cookie:r.headers.getSetCookie().map(x=>x.split(';')[0]).join('; ')};
}
const password=randomBytes(20).toString('hex');let alice,bob,issued,token,db;
test('D1 Worker initialization and durable migration',async()=>{
 mf=new Miniflare(convertV4MiniflareOptions(config));await mf.ready;db=await mf.getD1Database('DB');
 const sql=await readFile('drizzle/0000_mean_black_cat.sql','utf8');await db.batch(sql.split('--> statement-breakpoint').map(x=>x.trim()).filter(Boolean).map(x=>db.prepare(x)));
 const {r,b}=await request('/api/status');assert.equal(r.status,200);assert.equal(b.emailDelivery,'unavailable');assert.equal(b.fortnitePortAvailable,false);
 const benign=await request('/api/device/code',{client_id:'hollowwake-uwp'},'__cf_bm=harmless_platform_cookie',undefined,{device:true});assert.equal(benign.r.status,200);
});
test('real registration and existing-user login set protected cookies',async()=>{
 for(const [username,email]of[['worker_alice','alice@worker.example'],['worker_bob','bob@worker.example']]){const q=await request('/api/auth/sign-up/email',{username,name:username,email,password});assert.equal(q.r.status,200,JSON.stringify(q.b));assert.ok(q.cookie);if(username==='worker_alice')alice=q.cookie;else bob=q.cookie;assert.match(q.r.headers.get('set-cookie'),/HttpOnly/);assert.match(q.r.headers.get('set-cookie'),/Secure/);}
 const q=await request('/api/auth/sign-in/email',{email:'alice@worker.example',password});assert.equal(q.r.status,200);alice=q.cookie;
 const browserDevice=await request('/api/device/code',{client_id:'hollowwake-uwp'},alice);assert.equal(browserDevice.r.status,400);
});
test('device code, QR, enforced polling and explicit approval',async()=>{
 let q=await request('/api/device/code',{client_id:'hollowwake-uwp'});assert.equal(q.r.status,200,JSON.stringify(q.b));issued=q.b;assert.ok(issued.qr_png_base64);assert.equal(issued.interval,5);
 q=await request('/api/device/token',{client_id:'hollowwake-uwp',device_code:issued.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'});assert.equal(q.b.error,'authorization_pending');
 q=await request('/api/device/token',{client_id:'hollowwake-uwp',device_code:issued.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'});assert.equal(q.b.error,'slow_down');
 q=await request('/api/link/verify',{user_code:issued.user_code},alice);assert.equal(q.r.status,200);
 q=await request('/api/link/approve',{user_code:issued.user_code},bob);assert.notEqual(q.r.status,200);
 q=await request('/api/link/approve',{user_code:issued.user_code},alice);assert.equal(q.r.status,200,JSON.stringify(q.b));
 // Advance only the stored polling timestamp, never bypass the approval check.
 await db.prepare('UPDATE deviceCode SET lastPolledAt=?').bind(Date.now()-20000).run();
 const race=await Promise.all([0,1].map(()=>request('/api/device/token',{client_id:'hollowwake-uwp',device_code:issued.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'},'__cf_bm=harmless_platform_cookie',undefined,{device:true})));assert.equal(race.filter(x=>x.r.status===200).length,1);q=race.find(x=>x.r.status===200);token=q.b.access_token;assert.ok(token);
});
test('single use, own profile, persistent sign-in and server revocation',async()=>{
 let q=await request('/api/device/token',{client_id:'hollowwake-uwp',device_code:issued.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'});assert.notEqual(q.r.status,200);
 q=await request('/api/link/verify',{user_code:issued.user_code},alice);assert.equal(q.b.error,'code_already_used');
 q=await request('/api/device/profile',undefined,'__cf_bm=harmless_platform_cookie',token);assert.equal(q.r.status,200);assert.equal(q.b.publicUsername,'worker_alice');
 await mf.dispose();mf=new Miniflare(convertV4MiniflareOptions(config));await mf.ready;
 q=await request('/api/device/renew',{},null,token);assert.equal(q.r.status,200);
 q=await request('/api/devices',undefined,alice);assert.equal(q.r.status,200);const id=q.b.devices[0].id;
 q=await request('/api/devices/revoke',{id},bob);assert.equal(q.r.status,404);
 q=await request('/api/devices/revoke',{id},alice);assert.equal(q.r.status,200);
 q=await request('/api/device/profile',undefined,null,token);assert.equal(q.r.status,401);
});
test('expired codes, unavailable recovery and durable rate limits',async()=>{
 db=await mf.getD1Database('DB');let q=await request('/api/device/code',{client_id:'hollowwake-uwp'});const code=q.b;await db.prepare('UPDATE deviceCode SET expiresAt=? WHERE deviceCode=?').bind(Date.now()-1000,code.device_code).run();
 q=await request('/api/link/verify',{user_code:code.user_code},alice);assert.equal(q.b.error,'expired_token');
 q=await request('/api/auth/request-password-reset',{email:'alice@worker.example'});assert.equal(q.r.status,503);assert.equal(q.b.error,'email_delivery_unavailable');
 let limited=false;for(let i=0;i<12;i++){q=await request('/api/device/code',{client_id:'hollowwake-uwp'});if(q.r.status===429)limited=true;}assert.ok(limited);
});
test.after(async()=>{await mf?.dispose();await rm(temporary,{recursive:true,force:true});});
