import { betterAuth } from 'better-auth';
import { authOptions } from '../backend/auth-options.mjs';
import { createCore } from '../backend/core.mjs';
import assets from './assets.generated.mjs';
function application(env) {
  const origin = new URL(env.PUBLIC_ORIGIN).origin;
  if (!origin.startsWith('https://') && !env.LOCAL_TEST) throw Error('HTTPS required');
  if (!env.BETTER_AUTH_SECRET || env.BETTER_AUTH_SECRET.length < 32) throw Error('Missing authentication secret');
  const config = { origin, local: Boolean(env.LOCAL_TEST), secret: env.BETTER_AUTH_SECRET, emailDelivery: env.MAIL_API_KEY ? 'https-mail' : 'unavailable',
    requireEmailVerification: Boolean(env.MAIL_API_KEY), deviceExpires: '10m', pollInterval: '5s', sessionSeconds: 7*86400, sessionUpdateSeconds: 86400, maxDeviceDays: 30 };
  // No SMTP/TCP on Workers. This explicit HTTPS adapter needs an authorized mail account.
  const send = async message => {
    if (!env.MAIL_API_KEY || !env.MAIL_FROM) throw Error('Email delivery unavailable');
    const response = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${env.MAIL_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: env.MAIL_FROM, ...message }) });
    if (!response.ok) throw Error('Email delivery failed');
  };
  const auth = betterAuth(authOptions(config, env.DB, send));
  // The shared application awaits terminal SQL operations; both SQLite and D1 use it.
  const db = { prepare(sql) { const statement=env.DB.prepare(sql); return {
    get: (...args) => statement.bind(...args).first(),
    all: async (...args) => (await statement.bind(...args).all()).results,
    run: (...args) => statement.bind(...args).run()
  }; }};
  const app=createCore(config,{db,auth,readAsset:name=>assets[name],close:()=>{}});
  return app;
}
export default { async fetch(request,env) {
  try { return await application(env).fetch(request,request.headers.get('CF-Connecting-IP') || 'unknown'); }
  catch { return Response.json({error:'service_unavailable',message:'Account service configuration is incomplete.'},{status:503,headers:{'Cache-Control':'no-store'}}); }
}};
