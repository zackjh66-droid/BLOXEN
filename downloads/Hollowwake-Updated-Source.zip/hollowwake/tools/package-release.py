"""Create reviewed redistributable artifacts; never include private/game inputs."""
from pathlib import Path
import zipfile,json,hashlib,shutil,sys,xml.etree.ElementTree as ET,base64
root=Path(__file__).resolve().parents[1];workspace=root.parent;site=workspace/'sites/hollowwake';release=workspace/'hollowwake-release';release.mkdir(exist_ok=True)
build=Path(sys.argv[1]);temp=root/'artifacts/final-reviewed';temp.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(build) as z:
 for i in z.infolist():
  if not (temp/i.filename).resolve().is_relative_to(temp.resolve()) or i.file_size>200_000_000:raise ValueError('Unsafe artifact')
 z.extractall(temp)
appx=next(temp.rglob('Hollowwake_*.appx'));cert=temp/'HollowwakeDevelopment.cer'
expected=json.loads((temp/'package-hashes.json').read_text(encoding='utf-8-sig'))
assert hashlib.sha256(appx.read_bytes()).hexdigest().upper()==expected['Hash']
with zipfile.ZipFile(appx) as z:
 assert 'AppxSignature.p7x' in z.namelist()
 config=json.loads(z.read('backend-config.json').decode('utf-8-sig'));assert config['BackendOrigin']=='https://hollowwake.jihnjohn10.chatgpt.site' and not config['FortnitePortAvailable'] and not config['AllowLocalHttp']
 blocks=ET.fromstring(z.read('AppxBlockMap.xml'));ns={'b':'http://schemas.microsoft.com/appx/2010/blockmap'};checked=0
 for f in blocks.findall('b:File',ns):
  data=z.read(f.attrib['Name'].replace('\\','/'));assert len(data)==int(f.attrib['Size'])
  for i,b in enumerate(f.findall('b:Block',ns)):
   assert base64.b64encode(hashlib.sha256(data[i*65536:(i+1)*65536]).digest()).decode()==b.attrib['Hash']
  checked+=1
bundle=release/'Hollowwake-Companion-0.2.0-x64';bundle.mkdir(exist_ok=True)
shutil.copy2(appx,bundle/appx.name);shutil.copy2(cert,bundle/cert.name)
for f in (appx.parent/'Dependencies/x64').glob('*.appx'):
 d=bundle/'Dependencies/x64'/f.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,d)
assert len(list((bundle/'Dependencies/x64').glob('*.appx')))==3
shutil.copy2(root/'docs/XBOX.md',bundle/'INSTALL.md')
shutil.copy2(root/'docs/DELIVERY-REPORT.md',bundle/'DELIVERY-REPORT.md')
for n in ['signature-verification.log','windows-runtime-test.json','native-link-ui-test.json','package-hashes.json']:
 if (temp/n).exists():shutil.copy2(temp/n,bundle/n)
manifest={f.relative_to(bundle).as_posix():{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(bundle.rglob('*')) if f.is_file()}
(bundle/'SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(release/(bundle.name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(bundle.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(bundle))
# Public source: project-only material; the existing private source/artwork is unchanged.
source={};blocked={'node_modules','.git','.sites-runtime','.wrangler','bin','obj','AppPackages','build-work','quarantine','data','artifacts','__pycache__','dist'}
for directory in ['backend','web','uwp','docs','tools','tests','remote-build']:
 for f in (root/directory).rglob('*'):
  if f.is_file() and not (set(f.relative_to(root).parts)&blocked) and f.suffix.lower() not in ['.pfx','.key','.sqlite','.exe','.dll']:
   source[f.relative_to(root).as_posix()]=f.read_bytes()
for name in ['README.md','package.json','package-lock.json','.env.example','.gitignore']:source[name]=(root/name).read_bytes()
for f in site.rglob('*'):
 if f.is_file() and not(set(f.relative_to(site).parts)&blocked) and f.name not in ['.dev.vars','assets.generated.mjs'] and (not f.name.startswith('.env') or f.name=='.env.example'):
  source['sites/'+f.relative_to(site).as_posix()]=f.read_bytes()
# Replace only the redistribution bundle's art with the exact project-owned CI/hosted version.
source['uwp/Hollowwake/Assets/Landmark.jpg']=(site/'web/landmark.jpg').read_bytes()
source['web/assets/landmark.jpg']=(site/'web/landmark.jpg').read_bytes()
source['web/index.html']=(site/'web/index.html').read_bytes()
source['uwp/Hollowwake/MainPage.xaml']=source['uwp/Hollowwake/MainPage.xaml'].replace('Fortnite artwork © Epic Games. '.encode(),b'')
for name in list(source):
 if name.endswith('extract-auth-core.py'):del source[name]
 assert not any(x in name.lower() for x in ['.pfx','device-session.protected','.dev.vars','/outbox/'])
source['SOURCE-NOTES.md']=b'This source contains the live Sites Worker/D1 website and retained Node variant, native companion and hosted build/test scripts. Public assets use original Hollowwake artwork, identical to CI. Private Epic artwork, game inputs, credentials, databases and signing keys are excluded. The game port/lobby is unfinished. Read docs/DELIVERY-REPORT.md and docs/HOSTED-BUILD.md.\n'
with zipfile.ZipFile(release/'Hollowwake-Updated-Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(source.items()):z.writestr('hollowwake/'+name,data)
verification=release/'Hollowwake-Verification.zip'
with zipfile.ZipFile(verification,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted((root/'evidence/delivery').glob('*')):
  if f.is_file() and f.suffix in ['.json','.log','.sha256','.png']:z.write(f,'evidence/'+f.name)
 for f in sorted(temp.glob('*.log')):z.write(f,'windows/'+f.name)
 z.writestr('PACKAGE-STATIC-CHECKS.json',json.dumps({'appx_blockmap_files_verified':checked,'x64':True,'signature_verified_on_windows':True,'no_fortnite_client':True,'configured_https_origin':config['BackendOrigin']},indent=2))
result={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in release.glob('*.zip')}
(release/'ARTIFACTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
