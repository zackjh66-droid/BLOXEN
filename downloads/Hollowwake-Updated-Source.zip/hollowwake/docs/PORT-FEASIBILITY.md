# Fortnite UWP feasibility and original-client integration

## Finding

A genuine 6.21-CL-4526925 UWP/Xbox port cannot be produced from the materials and tools available here. This is a concrete engineering blocker, not a packaging or signing issue. A separate account companion is provided; it cannot load the original lobby.

## Local evidence

The inspected archive's 351 files contain no `.uproject`, `.sln`, `.vcxproj`, C++ source/headers, platform link libraries or AppxManifest. The main PE is an x64 desktop GUI executable (`Machine=0x8664`, subsystem 2). Its imported dependencies include USER32, KERNEL32, ADVAPI32, WINMM, desktop XInput, PhysX, CEF, desktop CRTs and bundled anti-cheat binaries. Examples from the import table include `CreateWindowExW`, `GetConsoleWindow`, `CreateProcessW`, `OpenProcess` and `RegCreateKeyExW`.

The PE header's GUI subsystem alone does not distinguish UWP; the actual desktop import/dependency surface and absent platform build materials are the relevant evidence. The inspected EXE has a valid offline Epic signature and embedded build identifier; none of its code has been changed for this project. Its signed provenance does not make it UWP-compatible.

Microsoft documents [GetConsoleWindow](https://learn.microsoft.com/en-us/windows/console/getconsolewindow) as a desktop-only API. Its [existing C++ to UWP guidance](https://learn.microsoft.com/en-us/cpp/porting/how-to-use-existing-cpp-code-in-a-universal-windows-platform-app?view=msvc-170) describes porting/recompilation, including dependency changes. [Win32 and COM APIs for UWP](https://learn.microsoft.com/en-us/uwp/win32-and-com/win32-and-com-for-uwp-apps) are a restricted platform API surface, not all desktop Win32. Native Windows desktop graphics/window activation and arbitrary child desktop processes are not supplied by changing an APPX manifest.

See `evidence/port-feasibility.json` and `original-pe-inspection.json` for the executable/dependency evidence. No Windows code from the archive was executed.

## Routes evaluated

| Route | Assessment |
|---|---|
| Wrap/relabel the Windows EXE as APPX | Rejected: retains desktop imports and runtime model; not a port |
| Desktop Bridge/full-trust child process | Not a native Xbox UWP port; does not replace desktop dependencies |
| Recompile original Fortnite against a UWP target | Plausible source-level direction, but Fortnite source, exact engine fork/build setup, platform backends and compatible middleware are absent |
| Use a retail Xbox Fortnite package | Not supplied; retail console packages are not interchangeable with public Dev Mode UWP packages |
| Replace every missing desktop API/runtime at binary level | A major compatibility/reimplementation project with no demonstrated compatible runtime; no evidence supports a working result here |
| Recreate/stream the lobby or embed a web page | Does not satisfy the request for the actual local Fortnite client; not delivered |
| Native account companion | Feasible independent app; source implemented. Does not run Fortnite and does not establish its compatibility |

A genuine implementation would need access to the original Fortnite client source or an independently demonstrated compatible runtime, the relevant UE4.21 game fork/build definitions and asset/cook pipeline, and a UWP-compatible replacement/build of required dependencies. The game must be adapted for UWP activation/lifecycle, graphics/window/input, storage/network restrictions and its service integration, then compiled with the Windows toolchain and tested on an Xbox. Authorized console/GDK source access would be a different route and is not assumed to provide a Dev Mode UWP binary.

The Linux workspace has no local MSBuild/UWP compiler. A standard authorized hosted Windows runner is now available and has compiled, signed, installed and activated our companion; there is still no attached Xbox or qualifying isolated host for the untrusted game. The installed Linux NSS `signtool` is not Microsoft's APPX signing tool. Installing a Linux .NET SDK would not supply the missing Windows XAML/UWP compilation pipeline or game source.

## Original-client backend investigation

Static strings in the signed executable show `/api/oauth/token`, `QueryProfile`, `ClientQuestLogin`, `/api/cloudstorage/system`, `/api/cloudstorage/user/`, `/api/storefront/v2/keychain`, `/api/storefront/v2/catalog`, MCP identity and XMPP/party/presence handling. Original Epic account, replay and telemetry host strings are also present. The relevant snippets are saved in `evidence/backend-protocol-strings.txt`.

A lobby adapter would likely need to satisfy identity/token exchange, MCP profiles (including athena/common profiles), inventory/cosmetic definitions and revision semantics, configuration/cloud storage, catalog/keychain, and any presence/party requirements actually enforced by this version. Static strings cannot prove the required request order, exact response schemas or which services are optional. There was no runtime tracing because the downloaded client remains untrusted and no qualifying isolated Windows VM exists here.

The project endpoint `GET /api/device/profile` maps the authenticated Hollowwake user to a **canonical test-profile document** (account ID, public username, empty inventory, revision and disabled matches). It is consumed by the native companion and tests. It is **not** a working Epic login-protocol adapter; the response states `clientIntegration: "not_implemented"`. No Epic OAuth token or account identity is fabricated. No endpoints intercept or proxy Epic's services, and there is no TLS-bypass code in the companion.

Do not connect the supplied desktop build to this backend and assume it can enter a lobby. Separate source-level integration is blocked along with the port. The test profile has no validated default character or original inventory because claiming otherwise would be invented behavior.

## Loading art and UI

The custom startup source displays Hollowwake, an active indicator and a frame from the supplied Season 6 console trailer at 10 seconds (Loot Lake's floating island). Original game assets remain in the unchanged source archive. The original Splash.bmp was copied separately for investigation, but it is not asserted to be the full original Season 6 loading screen. Original loading/lobby assets inside PAK files have not been loaded by a game runtime. The companion transitions to account linking and then a truthful port-unavailable screen; no fake original loading/lobby transition is shown.

## Continuation evidence

The continuation separately parses normal and delayed imports, includes a conditional-header partition analysis, and reviews an actual public compatibility-loader candidate. See [CONTINUATION-REPORT.md](CONTINUATION-REPORT.md). Not every legacy-named API is classified as unsupported; import presence/name counts alone cannot prove a functional UWP implementation. An authorized private CI control-plane probe was also completed without allocating a runner.
