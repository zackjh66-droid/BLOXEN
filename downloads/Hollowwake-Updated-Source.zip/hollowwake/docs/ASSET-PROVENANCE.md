# Visual asset provenance

- `web/assets/landmark.jpg` and the identical native `Assets/Landmark.jpg` are extracted at 10 seconds from the supplied `6.21/FortniteGame/Content/Movies/Season6/FNBR_DeimosTrailer_Console.mp4`. The frame visibly shows Loot Lake and the floating island with purple energy. The downloaded archive remains unchanged.
- Extraction command: `ffmpeg -v error -ss 10 -i <original-trailer-path> -frames:v 1 -q:v 3 -y <output.jpg>`.
- The original movie is not included in the source ZIP. Its source hash and derivative hash are recorded in `evidence/file-changes.json`.
- Native StoreLogo, square/wide tiles and SplashScreen PNGs are original geometric project icons. The Hollowwake custom loading scene uses the original-asset-derived landmark background, project wordmark and a UWP ProgressRing.
- Neither the derived image nor the companion status view is represented as a functioning Fortnite lobby. Original Fortnite loading screens remain in the original archive; game-runtime integration is blocked.
- Fortnite source artwork belongs to Epic Games; Hollowwake is an unofficial fan project. This source delivery does not grant additional rights to public redistribution of Epic assets. Review your intended deployment's asset permissions.

## Public deployment and release variant

The hosted website, public CI and redistributable source/package use original geometric Hollowwake artwork. The retained private Season 6 frame, original archive and earlier source files are preserved unchanged. Public source packaging substitutes that same project-owned image and updates the artwork caption; it does not contain Epic game assets or claim an original Fortnite loading/lobby screen.
