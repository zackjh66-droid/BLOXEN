import { DatabaseSync } from 'node:sqlite';
import { createHmac, randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { dirname } from 'node:path';
import { createCore } from './core.mjs';
import { createAuth, CLIENT_ID } from './auth.mjs';
import { migrate } from './migrate.mjs';

export async function createApplication(config, { database, sendMail, captureMigration = false } = {}) {
  mkdirSync(dirname(config.dbPath), { recursive: true, mode: 0o700 });
  const db = database || new DatabaseSync(config.dbPath);
  db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  if (!database) chmodSync(config.dbPath, 0o600);
  const localSend = config.local && !config.smtp ? async message => {
    const outbox = `${dirname(config.dbPath)}/outbox`; mkdirSync(outbox, { recursive: true, mode: 0o700 });
    writeFileSync(`${outbox}/${randomUUID()}.json`, JSON.stringify(message), { mode: 0o600 });
  } : undefined;
  const auth = createAuth(config, db, sendMail || localSend);
  await migrate(db, auth, { capture: captureMigration });
  return createCore(config, { db, auth, readAsset: name => readFileSync(new URL(`../web/${name}`, import.meta.url)), close: () => db.close() });
}
