# Install the Hollowwake companion on Xbox Dev Mode

This is an independent account-linking companion, **not a Fortnite port**. No original Season 6 loading screen, lobby, character renderer or locker is included. Xbox operation has not been verified on hardware.

1. Download the release ZIP and extract it using a browser/device you already use. No compilation, SDK or local software installation is required.
2. On the Xbox, open Dev Home, enable Device Portal/remote access and use the exact portal address shown by your console. Authenticate to your own console if requested.
3. In Device Portal, open **Apps / My games & apps → Add / Deploy apps**. Choose `Hollowwake_0.2.0.0_x64.appx`.
4. Add all three packages from `Dependencies/x64`: Microsoft.VCLibs.x64.14.00, Microsoft.NET.Native.Framework.2.2 and Microsoft.NET.Native.Runtime.2.2. Select x64 only.
5. If your portal presents a signing-certificate field, select `HollowwakeDevelopment.cer`. Xbox developer deployment and desktop certificate installation differ; the public CER is supplied for verification/trust setup. Do not disable signature validation. Install, then launch **Hollowwake Companion Preview** from Dev Home.
6. The app is configured for `https://hollowwake.jihnjohn10.chatgpt.site`. After the splash, scan its QR or visit the displayed address, create/sign into your **Hollowwake** account, compare the displayed code and explicitly approve. Never enter Epic credentials.

Intended controls: D-pad/left stick to move focus, A to select, B to cancel linking. Retry replaces a link request. The connected screen shows the public username and the explicit unavailable-game/matches message. Saved credentials are protected by Windows DataProtectionProvider in app-private storage and checked by the backend on later launches. Account settings on the website can revoke a device. Actual Xbox focus, protected storage and lifecycle behavior still need your hardware test.

If installation fails, retain the exact HRESULT/Device Portal deployment log. If linking fails, retain the visible message and approximate time; do not send passwords, bearer tokens or secret device codes. A new build uses a new ephemeral development key; always use the public certificate shipped with that exact package. Private keys are never exported or included.

Microsoft references: [Device Portal installation](https://learn.microsoft.com/en-us/windows/advanced-settings/device-portal), [Device Portal API platform distinctions](https://learn.microsoft.com/en-gb/previous-versions/windows/uwp/debug-test-perf/device-portal-api-core).
