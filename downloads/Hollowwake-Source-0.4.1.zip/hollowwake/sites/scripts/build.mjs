import { build } from 'esbuild';
import { readFile,writeFile,mkdir,cp,rm } from 'node:fs/promises';
const assets={};for(const name of ['index.html','app.js','style.css','logo.svg']) assets[name]=await readFile('web/'+name,'utf8');
// Original project artwork, not redistributed Fortnite assets.
assets['favicon.png']=Array.from(await readFile('web/favicon.png'));
assets['assets/landmark.jpg']=Array.from(await readFile('web/landmark.jpg'));
await writeFile('worker/assets.generated.mjs', 'const assets='+JSON.stringify(assets)+';assets["favicon.png"]=new Uint8Array(assets["favicon.png"]);assets["assets/landmark.jpg"]=new Uint8Array(assets["assets/landmark.jpg"]);export default assets;');
await rm('dist',{recursive:true,force:true});await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});
await build({entryPoints:['worker/index.mjs'],outfile:'dist/server/index.js',bundle:true,format:'esm',platform:'node',target:'es2022',minify:true,alias:{'@better-auth/utils/password':process.cwd()+'/node_modules/@better-auth/utils/dist/password.mjs'},banner:{js:'import {createRequire as __createRequire} from "node:module";const require=__createRequire("/hollowwake.js");'}});
await cp('.openai/hosting.json','dist/.openai/hosting.json');await cp('drizzle','dist/.openai/drizzle',{recursive:true});
await writeFile('dist/server/wrangler.json',JSON.stringify({name:'hollowwake',main:'index.js',compatibility_date:'2026-05-15',compatibility_flags:['nodejs_compat'],d1_databases:[{binding:'DB',database_name:'hollowwake',database_id:'00000000-0000-4000-8000-000000000000'}]},null,2));
console.log('Bundled Worker, embedded website and schema-only D1 migrations.');
