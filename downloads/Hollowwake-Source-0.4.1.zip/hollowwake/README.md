# Latest experimental runtime: 0.4.1

Read EXPERIMENT-0.4.1-README.md and experimental-0.4.1/docs before the preserved companion documentation below. The actual Fortnite lobby is unfinished.

# Latest experimental runtime: 0.4

Read EXPERIMENT-0.4-README.md and experimental-0.4/docs before the preserved companion documentation below. The actual Fortnite lobby is unfinished.

# Current release: Hollowwake 0.3

See [delivery report](docs/DELIVERY-REPORT.md), [Xbox installation](docs/XBOX.md), [private administration](docs/ADMIN.md) and [Game mode](docs/GAME-MODE.md). Version 0.2 linking succeeded on Xbox according to the user; no actual Fortnite client/lobby has been verified.

> **Current delivery:** the Sites website/backend are live, and the independent x64 companion has been built and development-signed on hosted Windows. The actual Fortnite UWP port remains unfinished. See [the current delivery report](docs/DELIVERY-REPORT.md). Earlier unbuilt/unhosted statements below describe the original snapshot.

# Hollowwake

**Unofficial Season 6 fan project. This delivery is a working local account website/backend plus an unbuilt native UWP companion source project. It is not a Fortnite port and contains no functioning Fortnite lobby.** No APPX was produced in this Linux environment.

## What works and what is blocked

| Part | Status |
|---|---|
| Website/backend registration, login, recovery and device authorization | Implemented; service and Chromium browser tests pass |
| Explicit linking approval, single-use codes, polling limits, account/device isolation | Implemented and tested |
| Persistent device sessions, rolling expiry, renewal, revocation | Implemented and tested through API clients, including service restart |
| Native UWP startup, code/QR screen, controller-accessible controls, protected session storage | Source provided; not compiled or runtime-tested |
| Original Fortnite loading-screen transition, lobby, character and UI | **Blocked: no compatible game runtime/source available** |
| Fortnite login protocol/offline lobby integration | Investigated statically; not implemented or claimed to work |
| Xbox APPX / Xbox validation | **Not built / not tested** |
| Hosted URL | None deployed; loopback development URL only |

The [continuation report](docs/CONTINUATION-REPORT.md) records actual browser QA, the expanded real-client API/dependency audit, and a private GitHub Actions probe that completed with no runner allocated. Windows execution remains blocked by unverified no-cost CI allowance; no local compilation is required from the user.

See [port feasibility](docs/PORT-FEASIBILITY.md) for concrete evidence and evaluated routes. Nothing opens the downloaded Windows executable. The UWP companion stops after account linking with an explicit port-unavailable message. It does not replace the real lobby with screenshots or a recreation.

## Run locally

Requires Node **24.19 or newer 24.x** and npm. Node's built-in SQLite driver is used; there are no archive-supplied dependencies.

```sh
npm ci --ignore-scripts
cp .env.example .env
node tools/init-local.mjs
npm run migrate
npm run dev
```

`init-local.mjs` fills only an empty `BETTER_AUTH_SECRET` in `.env` with a random value and sets private permissions. It refuses non-local configuration. Open **http://127.0.0.1:8787** on the same computer. That URL is not a hosted address and will not reach this machine from your Xbox or phone.

Create a project account, then use the native companion against a real HTTPS deployment or use the included local device simulator for the API flow:

```sh
node tools/device-simulator.mjs
```

The simulator prints only the website and public user code, never its secret device code or session token. Approve the displayed code in the website. The simulator validates the project profile, reports the blocked Fortnite transition and revokes its temporary session on exit. It does not run Fortnite or emulate an Xbox UI.

Local email is written to private `data/outbox/*.json` files. Open these locally to test verification/recovery; they contain sensitive links. They are not served over HTTP or included in source archives. Real hosted operation requires SMTP and verified email. No Epic account is involved.

## Build the native companion on Windows

Install Visual Studio 2022 with **Universal Windows Platform development**, C#/.NET Native support, and **Windows SDK 10.0.19041.0**. If the UWP workload is not shown in your installer, use the supported Visual Studio installer components for UWP; a desktop-only .NET SDK is insufficient.

After deploying the service at a real HTTPS origin:

```powershell
powershell -File .\tools\Build-Uwp.ps1 -BackendOrigin https://YOUR-ACTUAL-HOST
```

This is a configuration placeholder, not a live address. The script restores the pinned UWP NuGet package, builds **Release/x64**, generates a development certificate with a non-exportable private key in the current user's certificate store, signs the companion package, and exports **only the public .cer**. It restores the tracked config afterward. Output goes to `artifacts/uwp`; build/restore logs go there too. Existing certificate thumbprints can be supplied using `-CertificateThumbprint` if the subject matches `CN=HollowwakeDevelopment`.

**This command has not been run here.** Windows compile/package errors must be resolved using its actual logs. A successful companion build would not unblock Fortnite. See [Xbox installation and validation](docs/XBOX.md) for Device Portal steps and unperformed tests.

## Source layout

- `web/`: responsive, same-origin website; no browser-held bearer tokens.
- `backend/`: Better Auth 1.7.10 accounts and RFC 8628-style first-party device flow; SQLite schema/migrations.
- `uwp/`: C#/XAML UWP x64 companion project and package manifest; no external Win32 launcher.
- `tools/`: setup, simulator, preservation, build and static checks.
- `tests/`: real authentication service integration tests, not mock login results.
- `evidence/`: static build evidence, change records, audit and actual test logs. No credentials.

`build-work/` and `quarantine/` are local-only and excluded from distribution. The original archive remains at `/workspace/fortnite-alternative-analysis/6.21.zip`. Neither the full game nor quarantined executables are in the source ZIP. See [file preservation](docs/PRESERVATION.md).

## Verification

```sh
npm test
npm run check
npm audit --omit=dev
```

See [testing](docs/TESTING.md) for exactly what was run, what was clock-controlled, and what remains untested. Website/browser layout and UWP controller behavior require runtime validation; API/browser tests do not establish Xbox compatibility.

Hollowwake is not affiliated with or endorsed by Epic Games. Fortnite and the supplied source artwork belong to Epic Games. The background is a still of Loot Lake's floating island extracted from the supplied Season 6 trailer, not a screenshot of a working port.
