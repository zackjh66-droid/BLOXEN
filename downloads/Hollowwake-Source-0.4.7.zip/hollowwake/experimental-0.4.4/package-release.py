from pathlib import Path
import zipfile,hashlib,json,shutil,io,sys
root=Path('/workspace/hollowwake');exp=root/'experimental-0.4.4';out=Path('/workspace/hollowwake-experiment-release-0.4.4');out.mkdir(exist_ok=True)
artifact=Path(sys.argv[1]);run=int(sys.argv[2]);commit=sys.argv[3]
bundle=out/'Hollowwake-Client-Experiment-0.4.4-x64';bundle.mkdir(exist_ok=True);logs=bundle/'WindowsVerification';logs.mkdir(exist_ok=True)
with zipfile.ZipFile(artifact) as z:
 test=json.loads(z.read('windows-test.json').decode('utf-8-sig'));assert test['result'].startswith('PASS') and not test['xboxTested'] and not test['fortniteExecuted'] and test['clockContract'] and test['allocatorContract']
 forwarders=json.loads(z.read('forwarder-checks/forwarder-test.json').decode('utf-8-sig'));assert forwarders['productionResolverUsed'] and forwarders['fixedBaseCollisionEstablished'] and forwarders['realMappedTargetReturn']==621 and forwarders['fixedExecutableRejected'] and not forwarders['downloadedCodeExecuted'] and forwarders['mappedClockProcessAttachExecuted'] and forwarders['clockAdvancesUsingRealOsUptime'] and forwarders['clockWrapSemanticsVerified'] and forwarders['mappedLegacyMallocProcessAttach'] and forwarders['allocatorFamilyChecksPassed'] and forwarders['mappedInitializerTablesExecuted']
 for n in z.namelist():
  if n.endswith('/Hollowwake_0.4.4.0_x64.appx'):dest=bundle/'Hollowwake_0.4.4.0_x64.appx'
  elif '/Dependencies/x64/' in n and n.endswith('.appx'):dest=bundle/'Dependencies/x64'/Path(n).name
  elif n=='HollowwakeExperiment.cer':dest=bundle/n
  elif n.endswith(('.log','.json','.txt','.png')) and len(n.split('/'))<=2:dest=logs/n
  else:continue
  assert '..' not in Path(n).parts;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(n))
 for name in ['AppxSignature.p7x','AppxBlockMap.xml','AppxManifest.xml']:
  with zipfile.ZipFile(bundle/'Hollowwake_0.4.4.0_x64.appx') as a:assert name in a.namelist()
for name in ['sites-deployment.json','access-preservation.json','delivery-secret-scan.json','public-download-verification.json','initializer-callsite-audit.json','branding-alpha-check.json','layout-checks.json','sites-tests.log','sites-build.log','xbox-malloc-failure.json','tick-callsite-audit.json','xbox-tick-failure.json','crt-forwarder-audit.json','xbox-forwarder-failure.json','source-identity.json','boot-range-verified.json','native-dependency-check.json','website-readonly-check.json','site-mobile-home.png','site-mobile-link.png','site-desktop-home.png','site-desktop-project.png','site-desktop-downloads.png','deployed-browser-results.json','live-browser-results.json','website-mobile.png','website-desktop.png']:
 f=exp/'evidence'/name
 if f.exists():shutil.copy2(f,logs/f.name)
for name in ['credential-probes.json','credential-remediation.json']:
 shutil.copy2(root/'research-0.3.1/evidence'/name,logs/name)
for f in (exp/'docs').glob('*.md'):shutil.copy2(f,bundle/f.name)
summary={'version':'0.4.4.0','status':'Experimental CRT initializer-table fix and orange HW visual update; unfinished Fortnite port','sourceCommit':commit,'workflowRun':f'https://github.com/zackjh66-droid/BLOXEN/actions/runs/{run}','hostedWindows':test,'productionForwarderFixture':forwarders,'xbox':'0.4.4 update unverified; user photographed 0.4.3 dbghelp process-attach stopping at msvcrt!_initterm after allocator and clock passed; original main entry/lobby not observed','fortniteLobby':'Not achieved or tested','productionServices':'Unchanged; existing accounts/admin/companion preserved','gameInputs':'No archive code or private game content redistributed; official public Season6 promotional background included under conditional fan-content terms; private console import required'}
(logs/'verification-summary.json').write_text(json.dumps(summary,indent=2))
notes='''# Hollowwake 0.4 — client initialization experiment

This download is a development-signed x64 UWP runtime that can import the actual inspected 6.21 client privately onto the console and attempt its original initialization. It is not a completed Fortnite port. No original lobby, character, locker or shop success is claimed. User photos establish original dbghelp dependency startup in0.4.1 at GetTickCount, followed by progression in0.4.2 to the next failing call: msvcrt!malloc. User photos of0.4.3 then show progression to msvcrt!_initterm in dbghelp. The 0.4.4 update is unverified on Xbox.

The old working companion, account service, owner-only administration and rollback packages are preserved. The website visual update is saved as Sites version10 using the same persistent database and authentication configuration. Update the existing experimental package without uninstalling to retain its private import and protected session; Xbox update preservation is unverified. This package has a separate identity and uses your existing Hollowwake account with a new device approval.

Changes in 0.4.4: real msvcrt!_initterm and _initterm_e callback-table walking; focused production-mapper tests verify order, null skipping, empty tables and first-failure short-circuit. Orange-gradient transparent HW branding, licensed condensed Anton lettering, centered transparent launcher menu with orange controller focus, genuine Epic September2018 Season6 cube background, readable linking/import/errors. Actual Windows UWP screenshots, where captured, are labeled as Windows and not Xbox. Website has distinct Home, Project, Downloads, Link, Account and Recovery routes, mobile layout and reduced-motion support. Retained: real GetTickCount startup support, mapped-initializer uptime/wrap tests and packaged clock contract. Retained fix for thirteen export-only CRT shims incorrectly rejected as non-relocatable; production-resolver fixture checks; named latest-failure summary and OS errors. Retained: original x64 image/dependency mapping, TLS donors, unwind registration, supported window/message/controller hooks, real DXGI/D3D11 composition bridge, explicit original entry attempt, fail-fast missing-API logs, post-crash log access, pinned minimum import, optional full import, and orange HW/focus branding. There are no placeholder successful implementations of missing native APIs.

Hosted Windows checks passed on the exact signed package: installation/activation, executable-memory fixture, distinct packaged TLS slots, window/message and graphics contracts, actual missing-API fail-fast log/process exit, startup recovery, live own-account linking, protected restart sign-in, logout and revocation. Original mapped-TLS fixtures also passed, including modified-file rejection. The production dependency resolver also resolved two fixed-base forwarder DLLs to the same relocated original test function returning621, while rejecting a non-relocatable executable DLL. No downloaded game code ran in hosted CI. See WindowsVerification for scope and logs.

131 import offsets/sizes/hashes were statically checked against the unchanged source ZIP; a source HTTPS byte range was checked independently. Native CLR/C++ imports were checked against provided x64 VCLibs. These do not establish console execution. The user photographed 0.4.0.0 mapping original images on Xbox and stopping before original initialization at thirteen CRT-forwarder relocation rejections. This update treats proven export-only shims as read-only metadata; it does not bypass relocation requirements for executable DLLs. No physical controller or in-game behavior has been verified.

Install using INSTALL.md. Start with Show launch log, then the small Import boot files test, then Attempt client boot. Return the last EXECUTE/STOP/CRASH/CALLED_UNSUPPORTED record. The full archive is not necessary just to reproduce an unsupported call.

Remaining requirements are in LIMITATIONS.md: extensive Windows ABI/lifecycle coverage, private native HTTP/authentication handoff, complete version-compatible backend/presence and validated assets. The production client-protocol adapter remains disabled. No matches are provided.

Signing: public certificate only; private key was non-exportable on the ephemeral build runner. Self-signed development certificate, not Microsoft/Epic publisher endorsement. Executable/PAK game content is not included. Official public promotional background is included under conditional Epic fan-content terms; see VISUALS.md.

Live website: https://hollowwake.jihnjohn10.chatgpt.site
Admin remains owner-authenticated at the existing private address; it is deliberately omitted from public release metadata.
'''
(bundle/'README.md').write_text(notes);(out/'RELEASE-NOTES.md').write_text(notes)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={str(f.relative_to(bundle)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(bundle.rglob('*')) if f.is_file()};(bundle/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
def makezip(path,files):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,f in files:z.write(f,name)
makezip(out/(bundle.name+'.zip'),[(f.relative_to(bundle).as_posix(),f) for f in sorted(bundle.rglob('*')) if f.is_file()])
makezip(out/'Hollowwake-Dependencies-x64.zip',[(f.relative_to(bundle).as_posix(),f) for f in sorted((bundle/'Dependencies').rglob('*.appx'))])
makezip(out/'Hollowwake-Verification-0.4.4.zip',[(f.relative_to(bundle).as_posix(),f) for f in sorted(logs.rglob('*')) if f.is_file()]+[(f.name,f) for f in sorted((exp/'docs').glob('*.md'))])
shutil.copy2(bundle/'Hollowwake_0.4.4.0_x64.appx',out/'Hollowwake_0.4.4.0_x64.appx');shutil.copy2(bundle/'HollowwakeExperiment.cer',out/'HollowwakeExperiment.cer')
# Preserve previously reviewed complete website/backend/admin/companion source;
# replace the runtime directories with this build's original implementation.
seed=Path('/workspace/hollowwake-experiment-release-0.4.3/Hollowwake-Source-0.4.3.zip');files={}
with zipfile.ZipFile(seed) as z:
 for n in z.namelist():
  if n.startswith(('hollowwake/client-runtime/','hollowwake/experimental-0.4.4/')):continue
  files[n]=z.read(n)
for directory in [root/'client-runtime',exp]:
 for f in sorted(directory.rglob('*')):
  rel=f.relative_to(directory)
  if not f.is_file() or {'evidence','bin','obj','artifacts','AppPackages','__pycache__'} & set(rel.parts):continue
  if f.suffix.lower() in {'.pfx','.key','.sqlite','.dll','.exe'}:continue
  files['hollowwake/'+f.relative_to(root).as_posix()]=f.read_bytes()
# Preserve exact current live Sites v10 website and authentication in the source delivery.
import subprocess
site=Path('/workspace/sites/hollowwake')
tracked=subprocess.run(['git','ls-files'],cwd=site,text=True,capture_output=True,check=True).stdout.splitlines()
for name in tracked:
 f=site/name
 if f.is_file():files['hollowwake/sites/'+name]=f.read_bytes()
for name in ['backend/core.mjs','backend/auth-options.mjs','web/app.js']:
 files['hollowwake/'+name]=(root/name).read_bytes()
files['hollowwake/EXPERIMENT-0.4.4-README.md']=notes.encode()
files['hollowwake/README.md']=b'# Latest experimental runtime: 0.4.4\n\nRead EXPERIMENT-0.4.4-README.md and experimental-0.4.4/docs before the preserved companion documentation below. The actual Fortnite lobby is unfinished.\n\n'+files['hollowwake/README.md']
with zipfile.ZipFile(out/'Hollowwake-Source-0.4.4.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,data in sorted(files.items()):
  assert '..' not in Path(n).parts and not n.startswith('/')
  assert Path(n).suffix.lower() not in {'.pfx','.key','.sqlite','.pak','.exe','.dll'}
  z.writestr(n,data)
art={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(out.iterdir()) if f.is_file() and f.name not in {'ARTIFACTS.json','download-links.json'}};(out/'ARTIFACTS.json').write_text(json.dumps(art,indent=2));print(json.dumps(art,indent=2))
