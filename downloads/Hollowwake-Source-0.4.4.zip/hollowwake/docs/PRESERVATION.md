# File preservation and changes

The source archive `/workspace/fortnite-alternative-analysis/6.21.zip` was never edited. Its SHA-256 before and after project work is:

`bae66d8b0ff7e8ebea4361e835579c180bc2a2e618d04808f72b40214ababee5`

The post-work checksum is saved in `evidence/archive-after.sha256`. This is an integrity check against the inspected download, not proof of a pristine Epic distribution.

A separate **selected-file working copy** was created under `/workspace/hollowwake/build-work/6.21`. All 216 previously extracted inspection files were considered, preserving original runtime dependencies rather than deleting unsigned files indiscriminately. The original Splash.bmp and original Season 6 trailer were copied from the archive as data. Full game extraction was not performed: it would require 26.77 GB of additional space, exceeding space remaining alongside the preserved 12.53 GB archive.

These three confirmed third-party entries were copied into `/workspace/hollowwake/quarantine/6.21/FortniteGame/Binaries/Win64/` instead of the working set:

- `FortniteLauncher.exe`: unsigned, explicitly describes a Cyuubi custom SSL-pinning-bypass launcher.
- `Launcher.bat`: invokes that launcher with NOSSLPINNING.
- `imgui.ini`: contains FortMPGUI/LoadingWindow configuration.

They were **not executed**. Their inspection copies and original ZIP entries remain unchanged. All other dependencies were retained after reviewing the PE/dependency inventory. Later CMS caches were retained because their exact origin is not sufficiently established to classify every cache as a third-party modification. No claim of a pristine restored distribution is made.

`evidence/file-changes.json` records the quarantined entries and the artwork derivation with hashes. `tools/prepare_working_copy.py` reproduces the selection/quarantine from the archive, and can make a full separate extraction when `--full` is explicitly requested and sufficient disk exists. It refuses an occupied destination, verifies the complete archive hash and validates paths/links/expansion before copying. It never executes copied code.

The generated native icons/logo are new project artwork. The Loot Lake background is a still at 10 seconds from `FortniteGame/Content/Movies/Season6/FNBR_DeimosTrailer_Console.mp4`, copied to web and native assets. No original game PAK, EXE or DLL was modified. All new website/backend/native source files belong to this separate project. The source archive excludes the full game, quarantine, credentials, databases, original movies and local working copy.
