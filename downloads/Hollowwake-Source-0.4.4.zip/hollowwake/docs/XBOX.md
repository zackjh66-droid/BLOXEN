# Install the Hollowwake companion on Xbox Dev Mode

This is an independent account-linking companion, **not a Fortnite port**. No original Season 6 loading screen, lobby, character renderer or locker is included. The user reported that version 0.2 installed and linked successfully on Xbox. This is user-reported companion verification; version 0.3 and the real Fortnite client have not been independently tested on Xbox.

1. Download the release ZIP and extract it using a browser/device you already use. No compilation, SDK or local software installation is required.
2. On the Xbox, open Dev Home, enable Device Portal/remote access and use the exact portal address shown by your console. Authenticate to your own console if requested.
3. In Device Portal, open **Apps / My games & apps → Add / Deploy apps**. Choose `Hollowwake_0.3.0.0_x64.appx`.
4. Add all three packages from `Dependencies/x64`: Microsoft.VCLibs.x64.14.00, Microsoft.NET.Native.Framework.2.2 and Microsoft.NET.Native.Runtime.2.2. Select x64 only.
5. If your portal presents a signing-certificate field, select `HollowwakeDevelopment.cer`. Xbox developer deployment and desktop certificate installation differ; the public CER is supplied for verification/trust setup. Do not disable signature validation. Install, then launch **Hollowwake Companion Preview** from Dev Home.
6. The app is configured for `https://hollowwake.jihnjohn10.chatgpt.site`. After the splash, scan its QR or visit the displayed address, create/sign into your **Hollowwake** account, compare the displayed code and explicitly approve. Never enter Epic credentials.

Intended controls: D-pad/left stick to move focus, A to select, B to cancel linking. Retry replaces a link request. The connected screen shows the public username and the explicit unavailable-game/matches message. Saved credentials are protected by Windows DataProtectionProvider in app-private storage and checked by the backend on later launches. Account settings on the website can revoke a device. Actual Xbox focus, protected storage and lifecycle behavior still need your hardware test.

If installation fails, retain the exact HRESULT/Device Portal deployment log. If linking fails, retain the visible message and approximate time; do not send passwords, bearer tokens or secret device codes. A new build uses a new ephemeral development key; always use the public certificate shipped with that exact package. Private keys are never exported or included.

Microsoft references: [Device Portal installation](https://learn.microsoft.com/en-us/windows/advanced-settings/device-portal), [Device Portal API platform distinctions](https://learn.microsoft.com/en-gb/previous-versions/windows/uwp/debug-test-perf/device-portal-api-core).


## Optional Game classification

In **Dev Home → Games & apps**, highlight Hollowwake, press **View → View details**, change **App type** from **App** to **Game**, confirm with A, press B, then relaunch. This document-verified procedure makes additional resources available to compatible UWP applications; it does not make desktop Fortnite compatible. Game mode is not a verified requirement for this companion. See [GAME-MODE.md](GAME-MODE.md) for sources and limits.

## Updating and rollback

Version 0.2 and its certificate/download remain intact. Both builds use the same package identity/publisher subject, but a fresh non-exportable signing key is generated per hosted build. Some deployment paths may reject a certificate change as an update. Try the normal update first with the new package's CER. If Device Portal requires uninstall/reinstall, this can remove local protected sign-in state: relink with the same Hollowwake account; server accounts and saved project records remain. Do not uninstall other apps or clear the console's development storage. The old 0.2 package can be redeployed with its own certificate if needed; a version downgrade may require removing 0.3 first.
