> Current build/deployment status and later verification are in [DELIVERY-REPORT.md](DELIVERY-REPORT.md). Earlier unhosted/unbuilt statements below describe the prior snapshot.

# Hollowwake continuation report — 2026-10-15

## Outcome

The companion website/backend now has real Chromium UI verification and improved account-linking errors. Private remote build preparation and a non-spending GitHub Actions control-plane probe are complete. **No actual Fortnite UWP launch, Fortnite lobby, Windows executable test, APPX build or Xbox test succeeded or is claimed.** The original archive and game working inputs remain private and unchanged.

## Real-client investigation

A new static pass examined **138 retained EXE/DLL files** (the quarantined custom launcher is excluded), totaling **9,276 normal/delay import entries**. The exact main client contains **821 normal imports and 260 delayed imports**. Delayed dependencies include CEF, PhysX, Vivox, Oodle, NVIDIA components, speech graphics, audio and Media Foundation. A launcher cannot discard these dependencies by merely resolving the main executable's import table.

The main PE is not marked AppContainer and has a TLS directory with a **28-byte static TLS template**. Header flags alone do not determine compatibility; API behavior, activation, graphics and transitive dependencies also matter. Microsoft's public Win32 metadata places `CreateWindowExW` under DESKTOP/GAMES, not APP. Other APIs such as CreateProcessW and GetConsoleWindow appear in broader SDK partitions despite older documentation describing desktop usage; we do **not** classify every imported Win32 function as unsupported solely from its name. See `api-partition-evidence.json` for the actual header conditions.

The public [Xbox Win32 Runner](https://github.com/http-hadi/xbox-win32-runner) was reviewed statically at the recorded commit `84bb0f71a698ea5d2733d1e02c1caa96a33b1c01`. No downloaded loader code or binary was run or reused. Its own status document describes unfinished presentation/input work. Direct code inspection found placeholder behavior and a TLS routine that assigns an index/calls callbacks without implementing the needed static per-thread template initialization. Its D3D path still depends on desktop-style swap-chain behavior. These are material blockers for this exact client; replacing a few import names is insufficient.

A lexical registry comparison found **587** matching registration names among the main client's **1,081** imports. The other **494 are not automatically “unsupported”**: macro expansion, API-set/native forwarding and supplied DLL exports need further semantic analysis. Conversely, a name match may point to a stub. This count is an investigation aid, not a compatibility score or launch test. The comparison covers the full retained binary graph, not just the main executable.

The official historical UWP engine fork and Epic's engine repository both returned 404 under the available account. This establishes unavailable access here, not that the repositories or legitimate licensing routes do not exist. No leaked engine/game source or unauthorized SDK was obtained. Even obtaining a stock UWP engine fork would not supply Fortnite's missing game-native source/build definitions or reconstruct that code from its cooked assets.

[Project Reboot](https://github.com/Milxnor/Project-Reboot-3.0), [Instigator](https://github.com/jwhazy/instigator) and [LawinServerV2](https://github.com/Lawin0129/LawinServerV2) were investigated through their authors' documentation. These are game-server/desktop-launch/backend approaches; they do not establish a UWP runtime for this executable. No instructions to disable antivirus, enter Epic credentials or run bundled scripts were followed. No SDK dump, executable release or leaked source was incorporated.

**Minimal real-client launch gate remains unsatisfied.** There is no demonstrated compatible loader and no attached Xbox. A normal hosted Windows runner would be a build machine, not evidence of Xbox compatibility or a qualifying isolated malware-execution VM. The original game was not run there or here. The original loading/lobby integration is therefore still blocked, rather than treated as a remaining manifest/signing exercise.

## Remote Windows build investigation

GitHub access is now present. The existing private `zackjh66-droid/Use-if-needed` repository is writable. A new `hollowwake/companion-preflight` branch contains only the native companion/build material (no Fortnite EXE/DLL/PAK, server credentials or private key). Existing repository content was retained. The sole default-branch addition is a guarded `workflow_dispatch` workflow; no push-triggered build was added.

The official [Windows 2022 runner image manifest](https://github.com/actions/runner-images/blob/main/images/windows/Windows2022-Readme.md) lists UWP/.NET Native/MSBuild and SDK 19041 components. The workflow pins official checkout/artifact actions to commit hashes, uses read-only contents permission, disables persisted checkout credentials, bounds job duration, and exports only a public certificate. It defaults to skipping all jobs.

The initial path-based dispatch returned 404. After registering the workflow on the default branch and resolving its numeric ID, the **zero-runner** dispatch succeeded and [run 38767401054](https://github.com/zackjh66-droid/Use-if-needed/actions/runs/38767401054) completed **skipped**. This proves workflow-dispatch access, not a Windows compilation. No Windows runner was allocated and no build artifact storage was created by this probe.

Billing/usage, plan, runner administration, repository variable and secret inventories were unavailable or restricted (403 responses; the user API returned no plan). No credential values were printed. GitHub's [billing documentation](https://docs.github.com/en/billing/concepts/product-billing/github-actions) explains that private hosted-runner use can become billable beyond included allowance. Because the user forbids starting paid resources and the remaining allowance/spending cap cannot be verified, the build job remains disabled. A Windows job is not described as attempted or failed; only the control-plane probe ran.

The smallest requirement for an autonomous **companion build** is either billing visibility sufficient to verify no-cost Windows minutes/storage, or the owner's confirmation that an included no-cost allowance covers the bounded job. No local Windows installation or manual compilation is needed once that is established. This would still not solve the separate Fortnite runtime/source blocker.

## Website and authentication work completed

Actual headless Chromium checks on desktop 1440px and mobile 390px exercised registration, cookie login, explicit review/approval, keyboard focus and Enter activation, device polling/token issuance, test-profile mapping, persisted browser sign-in, revocation, logout/existing-user login, recovery/reset/new-password login, invalid and redeemed code messages, controlled expiry, network-loss handling and rate-limit feedback. Page-runtime exceptions were collected. See the final browser-results and screenshots for the exact passed set.

The first browser attempt exposed a password-label issue: helper text was part of the accessible label. It was separated and attached using `aria-describedby`. The unsupported diagonal-arrow glyph was replaced with a CSS-drawn indicator. These fixes preserve the existing theme and content.

Redeemed codes now have a distinct “already used” message. Migration `003-consumed-codes.sql` stores only an HMAC fingerprint of the public human code until its original expiry; the provider's one-time secret redemption remains unchanged. No extra copy of a secret device code, password or resulting credential is retained for this status check. Invalid codes have a separate error. A service integration test checks these distinctions and retained data.

Browser QA runs against a temporary service/database with generated throwaway credentials, leaving the existing database, .env and website untouched except for intended source fixes/migrations. Test mail goes to the temporary private outbox, not a real email service. Screenshots show public UI only. No browser profile, storage dump, password, token or secret device code is delivered.

## Hosting assessment

Sites access lists two existing unrelated projects. Neither is a Hollowwake deployment and neither was modified. There is no `.openai/hosting.json` for Hollowwake, no configured public backend origin, and no SMTP/recovery-delivery configuration. The existing Node/SQLite service is loopback-only. The managed environment lists no configured cloud-provider identities or hosting/mail secrets; the usable GitHub credential is reported by presence/permissions only.

A static/private Sites page would not make this Node/SQLite authentication backend reachable from the native app. A Cloudflare Worker/D1 adaptation would require a real bound database, production secret configuration and a supported mail/identity delivery arrangement, then revalidation; none is configured for Hollowwake. No unrelated site was overwritten, account created, paid resource started, proprietary asset publicly published, fake live URL invented or partial login form presented as a deployed account service.

The smallest hosting requirement is an authorized compatible persistent HTTPS target with mail delivery configuration (or a separately approved provider/recovery design). This is an infrastructure-access requirement, not a request to install software on the user's computer. The native package remains unconfigured rather than embedding an invented backend URL.

## Deliverables and limits

The updated source, website/backend, browser screenshots, CI workflow, static client audit tool, migrations and test reports are downloadable local artifacts. Private signing keys are absent. No source or artifact contains a Fortnite executable or game PAK. The full original archive and quarantined additions remain in their existing analysis directories.

**Unresolved:** real-client UWP runtime/source integration, original loading/lobby/character UI, original-client account protocol integration, native controller/runtime verification, Windows package build/signing and Xbox execution. No APPX is claimed. The companion remains explicitly labeled and is not substituted for the actual client.
