# Reproduce with the connected hosted Windows CI

No user computer or manual compilation is needed for the delivered package. It was built by the standard GitHub `windows-2022` runner in `zackjh66-droid/BLOXEN`, branch `hollowwake/companion-build`, using `.github/workflows/hollowwake-companion.yml`. The workflow is manually dispatched; it does not execute Fortnite files. The existing repository README is preserved.

GitHub documents [standard runners in public repositories as free](https://docs.github.com/en/actions/reference/runners/github-hosted-runners). The private repository's billing API was inaccessible; that was not treated as proof of cost. Public CI inputs contain project-owned art and companion source only. No paid or larger runner was started.

For another authorized hosted build, update that branch with the companion source and tools, then dispatch the workflow with `run_build=true`, `free_minutes_confirmed=true` (the documented standard public-runner route), and `backend_origin=https://hollowwake.jihnjohn10.chatgpt.site`. `tools/Build-Uwp.ps1` discovers MSBuild, restores pinned UWP dependencies, builds Release x64 with .NET Native and an actual `.appx` extension, generates a non-exportable development key on the ephemeral runner, and exports only its public certificate. It verifies the signed APPX with Microsoft's SignTool and attempts installation/activation of our own app.

`Test-NativeLink.ps1` uses Windows UI Automation and newly generated disposable project-account credentials kept in memory. It attempts displayed-code linking, app restart, logout and server revocation. Its result is separate from compiler success and from Xbox testing. If a rate-limit window is exhausted, respect it before retrying; do not weaken or bypass the limit.

Build logs, signature verification, hashes and runtime-test JSON accompany the package. CI artifacts are retained for one day; the delivered downloads are separate release artifacts. Never upload an archive containing `.env`, private keys, production database records or Fortnite inputs. The original private Season 6 artwork is deliberately replaced with original Hollowwake artwork in the public build.
