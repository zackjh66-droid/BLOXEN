# Hollowwake Control

This is a separate owner-private Sites application, not an obscure public admin route. Open the private URL supplied in the delivery message and sign into the same ChatGPT account that owns the Site. The public Hollowwake website has no link to it. Its random hostname, robots.txt and noindex headers reduce discovery; **Sites owner-only authorization is the security boundary**. Never change Control to a public/shared audience: every visitor permitted by that boundary is an administrator. Do not distribute its service bypass credential.

The browser talks only to its own `/api/control`. Admin actions additionally require the trusted Sites signed-in visitor identity; a platform service bypass by itself is denied. The private Worker signs JSON requests to the existing public backend's `/api/control/rpc`, using an HMAC key kept only in both server runtimes. Signatures cover method, path, timestamp, random nonce, owner actor and exact body. The backend validates the signature in constant time, enforces a 60-second window and single-use nonce, validates operation inputs, and uses atomic D1 batches for mutation plus audit. Browser mutations require the exact private origin. User cookies/tokens cannot authorize admin RPC. Neither RPC key nor platform bypass goes in browser JavaScript, APPX, source ZIPs or public URLs. A private-service credential appeared in a test exception in this conversation; the final server denies all identity-less admin calls, so that credential alone cannot authorize administration. It was never written to delivered reports/source.

The existing Better Auth secret, D1 binding, accounts and data are preserved. Migration 0001 adds project administration tables; it does not drop or rewrite the existing nine tables. Catalog definitions are metadata supplied by the owner, not Epic assets. No game files are uploaded/distributed and no purchases/currency transfer are implemented. Each user modification requires a reason. Account lists omit emails, passwords and tokens. Suspensions have an explicit expiry (maximum 366 days), revoke sessions/device grants, and block protected project endpoints; they do not impose Epic account bans.

## Implemented operations

The following is the actual supported scope, rather than 50 decorative buttons. Shared operations apply separately to each stated record type.

- Catalog: create, edit title/template/category/notes, duplicate draft, enable, disable, export, delete and reject stale revisions.
- Shops: create, add/remove catalog items, set integer display prices, set UTC start/end, edit, duplicate draft, publish/unpublish, export and delete. These are saved schedules; the game does not consume them yet. No automatic Epic storefront is claimed.
- Accounts: search usernames/exact ID, inspect account, inspect active linked devices, inspect project locker, suspend, restore access, revoke all project sessions, disconnect one owned companion.
- Locker: grant one known cosmetic, idempotent repeat grant, revoke one, full enabled-catalog snapshot, clear project locker; each operation is scoped to the selected account and audited.
- Project documents: create/edit/duplicate/enable/disable/export/delete announcements, news, release notes, policies, feature metadata, playlists and maintenance notices. Each type is persistent and versioned. Their operational consumption is explicitly not implemented; they are content records, not hidden runtime switches.
- Operations: account/device/document metrics, refresh, audit history, older-event pagination, export current audit page, server authorization, CSRF protection, replay rejection, bounded body size, audit reasons, safe text rendering, keyboard focus, responsive phone layout, noindex, and private sign-out.

This provides over 50 concrete editing/administration capabilities across those record types. It does **not** implement 50 additional game-server features. Unsupported capabilities have explicit boundaries: Fortnite login, real locker rendering, game kick, party moderation, match spectating and matchmaking cannot operate before the runtime/protocol integration. The API refuses game kick/matchmaking enable and refuses enabling the reserved unavailable capability flags.

## Full lockers and bans

“Give full project locker” grants every **currently enabled** cosmetic definition. Add the legitimate IDs/metadata first. This is a snapshot, not an automatic claim to all future catalog entries; disabled catalog entries are excluded. Revoking/deleting metadata does not silently erase prior grant records. “Clear project locker” removes all grants for that account and requires confirmation. `/api/project/inventory` returns only the signed-in account's own grants (browser or linked-device credentials) and explicitly reports `fortniteIntegration:false`.

“Disconnect” deletes the companion session; the app observes revocation at its next request or one-minute heartbeat. This is not a kick from a Fortnite lobby/game. Existing project account profile mappings are not Epic authentication or MCP responses.

## Deployment/reproduction

Main website/backend: `sites/` in the source download. Control source: `control/`. Run `npm ci`, `npm run build`; the main project additionally runs `npm test`. Configure main `ADMIN_RPC_SECRET` as a new >=32-byte secret and the same secret on Control, plus Control `BACKEND_ORIGIN` and its actual HTTPS `PUBLIC_ORIGIN`. Keep all values runtime-only. `global_fetch_strictly_public` is required in Control's Worker metadata for HTTPS subrequests to the other Site. Create a new Site only for an independent deployment, persist its returned ID, keep Control owner-private, push exact source, save and deploy the resulting artifact. Existing sites must reuse their IDs and database.

The standalone Node backend accepts `config.adminRpcSecret` (disabled when absent) and uses a SQLite transaction for the same batch semantics. Native own-account linking remains independent of Control availability. Recovery mail still requires an authorized mail provider and verified sending domain.
