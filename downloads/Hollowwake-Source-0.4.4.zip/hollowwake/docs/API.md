# Companion API contract

All routes share the configured PUBLIC_ORIGIN. JSON requests/responses are no-store. HTTPS is required except explicit loopback development. Device endpoints use the public client ID `hollowwake-uwp`; no embedded shared secret exists.

| Route | Method / authentication | Purpose |
|---|---|---|
| `/api/status` | GET, public | Project, origin, development/mail mode and honest port/matches capability flags |
| `/api/auth/sign-up/email` | POST, same-origin browser | email/password/public username registration |
| `/api/auth/sign-in/email` | POST, same-origin browser | HttpOnly browser session, token removed from JSON |
| `/api/auth/sign-out` | POST, browser cookie + Origin | End browser session |
| `/api/auth/request-password-reset` | POST, same-origin browser | Generic recovery request; email sent privately |
| `/api/auth/reset-password` | POST, same-origin browser | Provider one-use reset token/newPassword |
| `/api/auth/change-password` | POST, browser cookie + Origin | Current/new password; revoke other sessions forced |
| `/api/auth/update-user` | POST, browser cookie + Origin | Public username/name |
| `/api/auth/send-verification-email` | POST, same-origin browser | Provider email verification request |
| `/api/auth/verify-email` | GET, provider verification token | Provider-validated email confirmation, fixed local callback |
| `/api/me` | GET, browser cookie | Sanitized current account, no tokens |
| `/api/device/code` | POST, no cookie | Body `{client_id:"hollowwake-uwp"}`; returns device_code, user_code, verification_uri, verification_uri_complete, expires_in, interval, qr_png_base64 |
| `/api/link/verify` | POST, browser cookie + Origin | `{user_code}`; validate/claim pending code for this account before review |
| `/api/link/approve` | POST, browser cookie + Origin | `{user_code}`; explicit approval by the account that claimed it |
| `/api/link/deny` | POST, browser cookie + Origin | `{user_code}`; explicit denial |
| `/api/device/token` | POST, no cookie | `{client_id,device_code,grant_type:"urn:ietf:params:oauth:grant-type:device_code"}`; returns opaque session access_token, token_type, expires_in, scope after approval |
| `/api/device/cancel` | POST, secret device code | `{device_code}`; invalidate pending/approved unredeemed request |
| `/api/device/profile` | GET, device Bearer | Public username, canonical empty test inventory/profile, expiry and port-unavailable flags |
| `/api/device/renew` | POST `{}`, device Bearer | Validate/roll session according to update-age policy; return expires_at and policy; does not issue a refresh token |
| `/api/device/logout` | POST `{}`, device Bearer | Delete server session |
| `/api/device/matchmaking` | POST `{}`, device Bearer | Always HTTP 409, `matches_unavailable`, “Matches are not available yet” |
| `/api/devices` | GET, browser cookie | Owner's linked device IDs, labels, creation/last-seen/expiry; no credentials |
| `/api/devices/revoke` | POST, browser cookie + Origin | `{id}`; revoke only own linked session |

Other provider routes are deliberately not exposed as an alternate approval/bearer path. Browser profile endpoints reject device Bearer credentials, and device profile endpoints reject browser-cookie authentication. There is no external Epic protocol integration.

Authorization failures use HTTP 401/403. Invalid, expired or consumed codes use the library's error codes (`invalid_request`, `expired_token`, `invalid_grant`, `access_denied`, `slow_down`, `authorization_pending`); the gateway additionally returns distinct `invalid_user_code` and `code_already_used` errors, and the website explains invalid/used/expired cases. Limits use HTTP 429 and Retry-After. Do not log token responses or POST bodies. User-visible codes are public linking identifiers, never session credentials.
