# Xbox Dev Home: App and Game

Document-verified procedure (2026-10-15), not a newly performed hardware test:

1. Deploy the x64 Hollowwake APPX and its x64 dependencies first.
2. In Xbox **Dev Home → Games & apps**, highlight **Hollowwake Companion Preview**.
3. Press the controller's **View** button (two overlapping rectangles).
4. Choose **View details** and press **A**.
5. On App details, choose **App type**, change **App** to **Game**, confirm with **A**.
6. Press **B**, then launch/relaunch the application. The UI labels may vary with console OS revision.

Source: [Microsoft DirectX maintainer Chuck Walbourn's illustrated procedure](https://walbourn.github.io/directx-and-uwp-on-xbox-one/), linked from [Microsoft's system resource allocation documentation](https://learn.microsoft.com/en-us/previous-versions/windows/uwp/xbox-apps/system-resource-allocation).

Game classification makes more CPU/GPU/memory resources available to a compatible UWP app. Microsoft's resource page documents foreground budgets of 1 GB for apps and 5 GB for games; actual console allocation should be measured using MemoryManager on the target hardware. It does not provide desktop Windows APIs, a Win32 process launcher, Fortnite source, game-service responses, or a working graphics compatibility layer. x64 indicates CPU architecture; both an unsupported desktop executable and a compatible UWP can be x64.

**Optional for this companion.** The user reported successful installation/linking of version 0.2 on Xbox without reporting the App type setting. No evidence establishes Game mode as mandatory for our account-linking app. We do not add the deprecated expandedResources restricted capability or pretend a manifest setting changes Dev Home classification. The app includes the optional procedure in troubleshooting text. The project's hosted Windows build is not an Xbox Game-mode test.
