> Current build/deployment status and later verification are in [DELIVERY-REPORT.md](DELIVERY-REPORT.md). Earlier unhosted/unbuilt statements below describe the prior snapshot.

# Accounts and device authorization

## Provider choice

Pinned Better Auth 1.7.10 handles password hashing, registration, email verification, login, recovery, sessions and device authorization. Its documented [Device Authorization plugin](https://better-auth.com/docs/plugins/device-authorization) supports **first-party device sign-in into the same application**, including browser approval and account-owned sessions. That mode fits this website and companion; integration tests verify actual local behavior. It is not configured as a general third-party OAuth/OpenID provider.

The request/approve/poll interaction follows OAuth 2.0 Device Authorization Grant (RFC 8628). The plugin's `access_token` response is an **opaque Better Auth session token**, not a scoped JWT OAuth access token. No refresh token is issued in this mode. Renewal uses server-checked rolling sessions (7 days, extended after 24 hours of activity, with an absolute 30-day device limit). Expired/revoked credentials cannot renew; the app must relink. A change to a general OAuth provider would need its own client/resource registration and validation, not just renaming these credentials.

## Actual flow

1. Native companion POSTs `/api/device/code` with public client ID `hollowwake-uwp`. Unknown IDs and untrusted user pre-binding parameters are rejected.
2. Library creates a random 64-character secret device code and an independent 8-character human code, valid for ten minutes. Poll interval is at least five seconds.
3. Response contains the public verification URL, public code, and QR PNG. The QR payload is **only the same-origin `/link?user_code=...` URL**; no device/session/recovery secret is in it. The secret device code is held in native process memory, never displayed or saved to disk.
4. Browser signs into an own-project account with HttpOnly SameSite cookies, enters/reviews the code, and claims it through the maintained plugin. User must check the possession/matching-code box and click Approve; merely opening the website or signing in does not approve. Deny is also supported. A claimed code cannot be approved by a different account.
5. The native companion polls `/api/device/token`, observes pending/slow_down/expiry/denial, and receives its own one-use redemption result only after approval. The plugin atomically consumes the approved device code; concurrent replay is tested.
6. The server records that session as a device session. Companion stores the opaque session token with UWP `DataProtectionProvider("LOCAL=user")` in its app-private folder, bound to the backend origin. Browser JS never receives that token. No token/secret is intentionally logged or placed in a public URL.
7. Profile and renewal calls check server-side session existence on every request (cookie caching disabled). Account settings list only the owner's device IDs and permit revoking those sessions. Device APIs require a bearer credential from a registered device session, while browser approval/settings require an actual browser cookie session and same-origin mutations.
8. Restart reloads the protected token and revalidates it. Network loss retains protected credentials but does not claim successful offline login. A linked companion checks the server each minute while active; revoked credentials are rejected on the next request. B/Cancel invalidates a pending secret. Retry starts a new code after cancelling the old one. Suspend stops polling; resume revalidates a saved session or starts a new code.

## Security boundaries

- Browser mutation requests require an exact Origin match. Cross-origin API requests are rejected; no wildcard CORS. Original provider paths are not exposed as an unguarded bypass.
- JSON bodies are limited to 16 KiB. No URL path includes secret device codes; server has no request-body or token logging middleware.
- Device code issuance, verification and general requests have persistent SQLite limits. The plugin also enforces polling cadence. Production proxy IP headers are trusted only when the operator explicitly enables TRUST_PROXY and restricts direct server access.
- On the website, registration and password-reset requests return generic recovery messaging. Hosted deployment requires verified email and configured SMTP. Password reset revokes sessions; password change explicitly revokes other sessions.
- Browser login/signup token fields and bearer-exposure response headers are removed by the façade. API responses and HTML use no-store, no-referrer and a restrictive same-origin CSP.
- Server database contains authentication material, including provider session/device records; keep it private and encrypt backups. DB/WAL and local outbox are not source assets. The initial database is created with mode 0600 in a mode 0700 directory. A reverse proxy must not log request bodies, Authorization, cookies, mail/reset links or token responses.
- No shared client secret is in the native package. Only the backend secret and SMTP credentials live in server environment configuration. No private signing key is distributed.
- The first-party flow authorizes whoever possesses the device code and approves with their browser account; first-launch cannot pre-bind an unknown future account. Review the device code on the actual device. User codes are not proof of hardware identity and there is no Xbox hardware attestation.

This is a tested development implementation, not a third-party security audit. Availability attacks, mail operations, TLS deployment, real-device storage and game integration still require deployment review and runtime tests.

## Redeemed human-code status

Migration 003 retains an HMAC fingerprint of the public user code until original expiry, enabling a distinct already-used message after the provider consumes the request. It retains no extra secret device code or credential. The new behavior is covered by service and browser tests.
