> Current build/deployment status and later verification are in [DELIVERY-REPORT.md](DELIVERY-REPORT.md). Earlier unhosted/unbuilt statements below describe the prior snapshot.

# Deploy the website and account backend together

No live deployment was created. The included local service is the authoritative implementation; the source includes no invented live URL. Public deployment requires your own reachable HTTPS origin, persistent storage, and SMTP. The available Sites workflow was considered, but a static private website would not supply this Node/SQLite account service to an Xbox. Do not publish a disconnected account form.

## Single-instance Node service

1. Provision a Linux host/container with Node 24.19+, npm, persistent private disk and backups. Keep one application instance for this SQLite implementation. Multi-instance deployment needs a suitable shared database/provider adapter and a revalidated migration/rate-limit strategy.
2. Copy this source without `node_modules`, `.env`, `data`, original/quarantined game files or private keys. Run `npm ci --ignore-scripts --omit=dev`.
3. Create a mode-0600 `.env` outside any publicly served directory, using `.env.example`. Set a real `PUBLIC_ORIGIN=https://your-domain`, `ALLOW_LOCAL_HTTP=0`, a cryptographically random `BETTER_AUTH_SECRET`, persistent `DATABASE_PATH`, SMTP_HOST/PORT/FROM and any SMTP_USER/PASSWORD. Configure SMTP TLS appropriately. Hosted starts refuse missing mail delivery configuration. Never change the auth secret casually; it invalidates signed browser cookies and affects stored sessions.
4. Point DNS at the host. Use a normal trusted TLS certificate. Do not disable certificate verification on the Xbox or backend. TLS must be valid for the configured hostname.
5. Run `npm run migrate` against an empty production database, then `npm run dev` under a process supervisor. The name `dev` simply starts this server; no hot-reload server is involved. By default it binds only to loopback.
6. Put a TLS reverse proxy on the same machine. Example Caddyfile, replacing the placeholder with your domain:

   ```text
   your-domain.example {
     reverse_proxy 127.0.0.1:8787
   }
   ```

   This is sample configuration, not a deployed address. Enable `TRUST_PROXY=1` only when the reverse proxy overwrites forwarding headers and clients cannot reach Node directly. Otherwise keep it disabled; limits will group clients behind the proxy. Do not enable access logging of sensitive URLs/headers/bodies.
7. The site, `/api/*`, and assets must share the same origin. Do not use a CDN that caches auth pages or API responses. Check `/api/status`, registration, verification email delivery, recovery, browser approval and revocation from outside the server.
8. Re-run the service test suite and independently review production configuration. Confirm public HTTPS works on the actual Xbox before building the native source with this origin.

The optional Dockerfile uses a non-root Node user and a private persistent `/app/data` volume. Example:

```sh
docker build -t hollowwake-companion .
docker run --env-file .env -e HOST=0.0.0.0 -e DATABASE_PATH=/app/data/hollowwake.sqlite \
  -p 127.0.0.1:8787:8787 -v hollowwake-data:/app/data hollowwake-companion
```

Docker was not built/run here; verify volume ownership and your TLS proxy in your deployment. Never bind an unauthenticated development instance to your network with a loopback PUBLIC_ORIGIN. The UWP source permits HTTPS by default; it must point to the same real origin as the website/backend. Loopback on an Xbox means the Xbox itself, not a development computer.

## Migrations

`backend/migrations/001-better-auth.sql` is generated from the pinned provider on a fresh SQLite database; `002-project.sql` adds device associations and persistent rate limits; `003-consumed-codes.sql` retains short-lived keyed human-code fingerprints for distinct consumed-code errors. `npm run migrate` asks the pinned library for required schema changes and then applies the project SQL idempotently. Back up production data before upgrades. Do not run test suites against production data; tests use their own in-memory/temporary databases.

## Operations

Use encrypted backups and tested recovery, private file permissions, secret rotation procedures and a real SMTP delivery monitor. Expired provider records and old request-limit buckets need periodic maintenance according to your retention policy. Revocation is server-side; do not enable cookie/session caching that bypasses the database. The website's user settings can revoke devices. A local app sign-out while offline clears its stored credential, but the user should also revoke the device from the website to end the server session.
