"""Publish only reviewed project-owned release material through authorized Git data APIs."""
from pathlib import Path
import subprocess,json,base64,hashlib,argparse
parser=argparse.ArgumentParser();parser.add_argument('--version',default='0.2.0');args=parser.parse_args();version=args.version
root=Path(__file__).resolve().parents[1];r=root.parent/('hollowwake-release' if version=='0.2.0' else 'hollowwake-release-'+version);repo='zackjh66-droid/BLOXEN';branch='hollowwake/release-files-'+version
def api(path,payload=None,method=None):
 out=subprocess.run(['gh','api','repos/'+repo+'/'+path]+(['--method',method or 'POST','--input','-'] if payload is not None else []),input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True)
 if out.returncode:raise RuntimeError(out.stderr[:500])
 return json.loads(out.stdout) if out.stdout.strip() else {}
head=api('git/ref/heads/main')['object']['sha'];base=api('git/commits/'+head)['tree']['sha'];files={f.name:f for f in r.glob('*.zip')};files['ARTIFACTS.json']=r/'ARTIFACTS.json'
for name in ['HollowwakeDevelopment.cer','Hollowwake_'+version+'.0_x64.appx']:files[name]=r/('Hollowwake-Companion-'+version+'-x64')/name
files['README.md']=r/'RELEASE-NOTES.md';entries=[]
for name,f in files.items():
 data=f.read_bytes();blob=api('git/blobs',{'content':base64.b64encode(data).decode(),'encoding':'base64'});assert blob['sha']==hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 entries.append({'path':'downloads/'+name,'mode':'100644','type':'blob','sha':blob['sha']})
 print('Verified upload:',name,flush=True)
tree=api('git/trees',{'base_tree':base,'tree':entries});c=api('git/commits',{'message':'Deliver tested Hollowwake companion, public certificate, dependencies, source and verification; no Fortnite files','tree':tree['sha'],'parents':[head]});api('git/refs',{'ref':'refs/heads/'+branch,'sha':c['sha']})
links={}
for name in files:
 d=api('contents/downloads/'+name+'?ref='+branch);links[name]={'url':d['download_url'],'bytes':d['size'],'git_blob_sha':d['sha']}
result={'repository':repo,'branch':branch,'commit':c['sha'],'downloads':links}
(root/('evidence/delivery/downloads.json' if version=='0.2.0' else 'evidence/redesign/downloads.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
