import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
if (!existsSync('.env')) writeFileSync('.env', readFileSync('.env.example'), { mode: 0o600 });
let text = readFileSync('.env', 'utf8');
if (!/^PUBLIC_ORIGIN=http:\/\/(127\.0\.0\.1|localhost)(:\d+)?$/m.test(text) || !/^ALLOW_LOCAL_HTTP=1$/m.test(text)) throw new Error('This helper supports local development only. Configure hosted secrets separately.');
if (/^BETTER_AUTH_SECRET=\s*$/m.test(text)) text = text.replace(/^BETTER_AUTH_SECRET=\s*$/m, `BETTER_AUTH_SECRET=${randomBytes(48).toString('base64url')}`);
writeFileSync('.env', text, { mode: 0o600 }); chmodSync('.env', 0o600);
console.log('Local configuration prepared. No secret was printed.');
