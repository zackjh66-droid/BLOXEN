import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
const origin='https://hollowwake.jihnjohn10.chatgpt.site';
const response=await fetch(origin+'/api/device/code',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:'hollowwake-uwp'})});assert.equal(response.status,200);
const code=await response.json();const start=Date.now();
console.log('Issued a real deployed ten-minute code; secret stays in process memory.');
const delay=(code.expires_in+2)*1000;for(let waited=0;waited<delay;){let next=Math.min(30000,delay-waited);await new Promise(r=>setTimeout(r,next));waited+=next;}
const result=await fetch(origin+'/api/device/token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:'hollowwake-uwp',device_code:code.device_code,grant_type:'urn:ietf:params:oauth:grant-type:device_code'})});const body=await result.json();assert.equal(body.error,'expired_token');
const report={origin,check:'Real deployed code expired through normal wall-clock time',elapsedSeconds:Math.round((Date.now()-start)/1000),result:'PASS'};await writeFile('evidence/delivery/live-code-expiry.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
