"""Final private UI/layout and authorization checks; no owner-password impersonation."""
import sys,json,os,asyncio,traceback
from pathlib import Path
from playwright.async_api import async_playwright
if sys.stdin.isatty():
 import termios
 a=termios.tcgetattr(sys.stdin);a[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,a)
print('Ready for hidden service credential',flush=True)
c=json.loads(sys.stdin.readline());origin=c['origin'];token=c['token'];out=Path('/workspace/hollowwake/evidence/redesign')
async def main():
 report={'tests':[],'pageErrors':[],'ownerInteractiveLoginTested':False,'serviceBypassCannotAdminister':False}
 async with async_playwright() as p:
  proxy={'server':os.environ['HTTPS_PROXY']} if os.environ.get('HTTPS_PROXY') else None
  api=await p.request.new_context(proxy=proxy,extra_http_headers={'OAI-Sites-Authorization':'Bearer '+token})
  for spoof in [False,True]:
   headers={'Origin':origin,'Content-Type':'application/json'}
   if spoof:headers['oai-authenticated-user-id']='forged-owner'
   r=await api.post(origin+'/api/control',headers=headers,data=json.dumps({'action':'overview'}));assert r.status==403, 'Identity guard status: '+str(r.status)
  report['tests'].append('Platform service bypass and caller-forged identity cannot authorize admin RPC');report['serviceBypassCannotAdminister']=True
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
  anon=await browser.new_context();page=await anon.new_page();await page.goto(origin,wait_until='domcontentloaded');assert not await page.locator('#metrics').count();report['tests'].append('Anonymous request is gated by Sites');await anon.close()
  ctx=await browser.new_context(viewport={'width':1440,'height':1000},extra_http_headers={'OAI-Sites-Authorization':'Bearer '+token});page=await ctx.new_page();page.on('pageerror',lambda e:report['pageErrors'].append(str(e)))
  await page.goto(origin,wait_until='networkidle');await page.locator('#notice').wait_for();assert 'Sign in with the Site owner' in await page.locator('#notice').inner_text();report['tests'].append('Identity-less private preview gives actionable owner-sign-in error')
  await page.screenshot(path=str(out/'admin-final-desktop.png'),full_page=True)
  await page.set_viewport_size({'width':390,'height':844})
  for label in ['Overview','Accounts & lockers','Cosmetic catalog','Shop schedules','Content & settings','Audit trail','Capabilities & help']:
   await page.get_by_role('button',name=label,exact=True).click();widths=await page.evaluate('({scroll:document.documentElement.scrollWidth,width:innerWidth})');assert widths['scroll']<=widths['width'],(label,widths)
  await page.screenshot(path=str(out/'admin-final-mobile.png'),full_page=True);report['tests'].append('All seven final admin sections fit a 390px mobile viewport')
  await page.get_by_role('button',name='Cosmetic catalog',exact=True).click();await page.get_by_role('button',name='New cosmetic',exact=True).click();await page.locator('#doc-title').fill('Layout QA only, never saved');widths=await page.evaluate('({scroll:document.documentElement.scrollWidth,width:innerWidth})');assert widths['scroll']<=widths['width'];await page.locator('#close-editor').click();report['tests'].append('Mobile editor opens/closes without overflow; no unauthorized write attempted')
  assert not report['pageErrors'];await api.dispose();await browser.close()
 report['result']='PASS';out.joinpath('admin-final-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
try:asyncio.run(main())
except Exception:print(traceback.format_exc().replace(token,'[REDACTED]'));sys.exit(1)
