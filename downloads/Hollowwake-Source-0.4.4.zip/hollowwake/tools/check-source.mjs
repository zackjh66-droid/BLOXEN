import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';
function walk(dir) { return readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(dir, e.name)) : [join(dir, e.name)]); }
const source = ['backend', 'web', 'tools', 'tests'].flatMap(walk).filter(f => /\.(mjs|js)$/.test(f));
for (const file of source) { const run = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' }); if (run.status !== 0) throw Error(`JS syntax check failed: ${file}\n${run.stderr}`); }
const xaml = readFileSync('uwp/Hollowwake/MainPage.xaml', 'utf8'), cs = readFileSync('uwp/Hollowwake/MainPage.xaml.cs', 'utf8');
for (const match of xaml.matchAll(/(?:Click|KeyDown)="([A-Za-z_]+)"/g)) if (!cs.includes(match[1] + '(')) throw Error('Missing XAML handler: ' + match[1]);
const manifest = readFileSync('uwp/Hollowwake/Package.appxmanifest', 'utf8');
if (!manifest.includes('ProcessorArchitecture="x64"') || manifest.includes('runFullTrust')) throw Error('Invalid companion target');
for (const file of walk('uwp').filter(f => f.endsWith('.cs'))) if (/Process\.Start|DllImport|FortniteClient-Win64-Shipping\.exe/.test(readFileSync(file, 'utf8'))) throw Error('Companion must not wrap or inject desktop Fortnite');
const config = JSON.parse(readFileSync('uwp/Hollowwake/backend-config.json', 'utf8'));
if (!['', 'https://hollowwake.jihnjohn10.chatgpt.site'].includes(config.BackendOrigin) || config.AllowLocalHttp || config.FortnitePortAvailable) throw Error('Source configuration must use the actual HTTPS origin and honestly blocked port status');
for (const name of ['Landmark.jpg', 'StoreLogo.png', 'Square150x150Logo.png', 'Square44x44Logo.png', 'Wide310x150Logo.png', 'SplashScreen.png']) if (!existsSync('uwp/Hollowwake/Assets/' + name)) throw Error('Missing visual asset: ' + name);
console.log(`Passed syntax checks for ${source.length} JavaScript modules; checked XAML handlers, x64 manifest, visual assets and absence of desktop-launch paths. This is not a Windows compilation.`);
