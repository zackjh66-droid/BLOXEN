import { setTimeout as delay } from 'node:timers/promises';
const origin = new URL(process.argv[2] || 'http://127.0.0.1:8787');
if (origin.protocol !== 'https:' && !(origin.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(origin.hostname))) throw Error('HTTPS required except local loopback');
let pending, credential, stopped = false;
async function api(path, body, token) {
  const response = await fetch(new URL(path, origin), { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(token ? { authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  const data = await response.json(); if (!response.ok) throw Object.assign(new Error(data.error || 'request_failed'), { code: data.error }); return data;
}
async function cleanup() {
  stopped = true;
  try { if (credential) await api('/api/device/logout', {}, credential); else if (pending) await api('/api/device/cancel', { device_code: pending }); } catch { }
  credential = pending = undefined;
}
process.once('SIGINT', async () => { await cleanup(); process.exit(130); });
try {
  const issued = await api('/api/device/code', { client_id: 'hollowwake-uwp' }); pending = issued.device_code;
  console.log(`LOCAL DEVICE SIMULATOR (not an Xbox or Fortnite client)\nWebsite: ${issued.verification_uri}\nPublic user code: ${issued.user_code}\nSign in and explicitly approve this code. Ctrl+C cancels.`);
  let interval = Math.max(5, issued.interval), expires = Date.now() + issued.expires_in * 1000;
  while (!stopped && Date.now() < expires && !credential) {
    await delay(interval * 1000);
    try { const result = await api('/api/device/token', { grant_type: 'urn:ietf:params:oauth:grant-type:device_code', device_code: pending, client_id: 'hollowwake-uwp' }); credential = result.access_token; pending = undefined; }
    catch (error) { if (error.code === 'authorization_pending') continue; if (error.code === 'slow_down') { interval += 5; continue; } throw error; }
  }
  if (!credential) throw Error('Device authorization expired.');
  const profile = await api('/api/device/profile', undefined, credential);
  console.log(`Account linked as ${profile.publicUsername}. Fortnite integration: ${profile.clientIntegration}.`);
  try { await api('/api/device/matchmaking', {}, credential); } catch (error) { if (error.code === 'matches_unavailable') console.log('Matches are not available yet'); else throw error; }
  await cleanup(); console.log('Temporary simulator session revoked. No credentials were saved.');
} catch (error) { console.error(`Simulator stopped: ${error.code || 'connection_or_flow_error'}. No credentials printed.`); await cleanup(); process.exitCode = 1; }
