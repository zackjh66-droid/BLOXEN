"""STATIC metadata audit. Never loads/executes the game or third-party loader.
Requires independently installed pefile. Literal registration matches are NOT
claims of runtime support: macros, API sets and native resolution need review.
"""
from pathlib import Path
import argparse,collections,json,re
import pefile
ap=argparse.ArgumentParser();ap.add_argument('--client-root',type=Path,required=True);ap.add_argument('--loader-source',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
registrations=set()
for f in a.loader_source.rglob('*.cpp'):
 for dll,name in re.findall(r'REGISTER_SHIM\(\s*"([^"]+)"\s*,\s*"([^"]+)"',f.read_text(errors='replace')):registrations.add((dll.lower().removesuffix('.dll'),name.lower()))
files=[]
for f in sorted(a.client_root.rglob('*')):
 if f.suffix.lower() not in ['.exe','.dll']:continue
 pe=pefile.PE(str(f),fast_load=True);pe.parse_data_directories(directories=[1,13,9,10]);imports=[]
 for kind,attr in [('normal','DIRECTORY_ENTRY_IMPORT'),('delay','DIRECTORY_ENTRY_DELAY_IMPORT')]:
  for lib in getattr(pe,attr,[]):
   dll=lib.dll.decode(errors='replace')
   for symbol in lib.imports:
    name=symbol.name.decode(errors='replace') if symbol.name else '#'+str(symbol.ordinal)
    imports.append({'dll':dll,'symbol':name,'kind':kind,'literal_runner_registration':(dll.lower().removesuffix('.dll'),name.lower()) in registrations})
 item={'path':str(f.relative_to(a.client_root)),'imports':imports,'appcontainer_flag':bool(pe.OPTIONAL_HEADER.DllCharacteristics&0x1000),'entrypoint_rva':hex(pe.OPTIONAL_HEADER.AddressOfEntryPoint),'tls_directory':bool(pe.OPTIONAL_HEADER.DATA_DIRECTORY[9].Size),'load_config':bool(pe.OPTIONAL_HEADER.DATA_DIRECTORY[10].Size)}
 files.append(item);pe.close()
a.out.parent.mkdir(parents=True,exist_ok=True)
a.out.write_text(json.dumps({'method':'Lexical registration presence only, not support certification. Macro-generated/native-pass-through exports may not appear. No loader/game executed.','registration_pairs':len(registrations),'files':files},indent=2))
print('Static inspection finished:',len(files),'PE files;',sum(len(x['imports']) for x in files),'import entries. Real-client launch NOT tested.')
