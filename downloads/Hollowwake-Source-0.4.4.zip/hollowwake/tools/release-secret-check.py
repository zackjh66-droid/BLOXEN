"""Check known runtime credentials without ever printing them."""
import sys,json,zipfile,os,termios
from pathlib import Path
if sys.stdin.isatty():
 a=termios.tcgetattr(sys.stdin);a[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,a)
print('Ready for hidden secret comparison values',flush=True)
values=json.loads(sys.stdin.readline())
values+=[os.environ.get('GH_TOKEN','')]
values=[v.encode() for v in values if len(v)>12]
p=Path('/workspace/hollowwake-release-0.3.0');count=0
for f in p.glob('*.zip'):
 with zipfile.ZipFile(f) as z:
  for info in z.infolist():
   data=z.read(info);assert all(v not in data for v in values),'Credential detected; artifact must not publish'
   assert not info.filename.lower().endswith(('.pfx','.key','.sqlite','.pak'))
   count+=1
r={'result':'PASS','filesInspected':count,'knownRuntimeSecretsAbsent':True,'privateKeyFilesAbsent':True,'gamePaksAbsent':True}
Path('/workspace/hollowwake/evidence/redesign/release-secret-check.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
