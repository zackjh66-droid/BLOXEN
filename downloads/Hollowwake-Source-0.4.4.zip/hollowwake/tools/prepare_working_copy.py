"""Reproduce a separate selected/full copy without running archive code."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,shutil,stat,zipfile,re
EXPECTED='bae66d8b0ff7e8ebea4361e835579c180bc2a2e618d04808f72b40214ababee5'
QUARANTINE={f'6.21/FortniteGame/Binaries/Win64/{name}' for name in ['FortniteLauncher.exe','Launcher.bat','imgui.ini']}
p=argparse.ArgumentParser();p.add_argument('--archive',type=Path,required=True);p.add_argument('--destination',type=Path,required=True);p.add_argument('--full',action='store_true');a=p.parse_args()
source=a.archive.resolve();dest=a.destination.resolve()
if dest.exists() and any(dest.iterdir()):raise SystemExit('Destination must be new or empty.')
if source==dest or dest in source.parents:raise SystemExit('Destination must not contain the original archive.')
with source.open('rb') as f:
 if hashlib.file_digest(f,'sha256').hexdigest()!=EXPECTED:raise SystemExit('Source archive differs from the inspected build.')
with zipfile.ZipFile(source) as z:
 entries=z.infolist();seen=set();selected=[]
 for i in entries:
  n=i.filename;q=PurePosixPath(n);mode=i.external_attr>>16
  if q.is_absolute() or '..' in q.parts or '\\' in n or ':' in n or str(q).casefold() in seen:raise SystemExit('Unsafe/duplicate member path.')
  seen.add(str(q).casefold())
  if stat.S_ISLNK(mode) or stat.S_IFMT(mode) not in [0,stat.S_IFREG,stat.S_IFDIR] or i.flag_bits&1:raise SystemExit('Unsafe link/special/encrypted member.')
  if i.file_size>12*1024**3 or i.file_size/max(1,i.compress_size)>1000:raise SystemExit('Excess expansion.')
  if n.lower().endswith(('.zip','.rar','.7z','.cab','.iso','.gz','.tar')):raise SystemExit('Nested archive needs separate inspection.')
  if i.is_dir():continue
  bulk=q.suffix.lower() in ['.pak','.sig','.mp4','.replay','.bmp']
  if a.full or n in QUARANTINE or q.suffix.lower() in ['.exe','.dll','.bat','.cmd','.ps1','.vbs','.js'] or (not bulk and i.file_size<20*1024**2):selected.append(i)
 required=sum(i.file_size for i in selected)+1024**3
 base=dest if dest.exists() else dest.parent
 while not base.exists():base=base.parent
 if shutil.disk_usage(base).free<required:raise SystemExit(f'Insufficient disk space. Need at least {required} free bytes.')
 dest.mkdir(parents=True,exist_ok=True);changes=[]
 for i in selected:
  action='quarantined' if i.filename in QUARANTINE else 'copied unchanged'
  out=dest/('quarantine' if i.filename in QUARANTINE else 'build-work')/i.filename
  out.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();count=0
  with z.open(i) as src,out.open('xb') as dst:
   while data:=src.read(1024**2):
    count+=len(data)
    if count>i.file_size:raise SystemExit('Size limit exceeded.')
    dst.write(data);h.update(data)
  out.chmod(0o600);changes.append({'path':i.filename,'action':action,'size':count,'sha256':h.hexdigest()})
 (dest/'copy-record.json').write_text(json.dumps({'source_sha256':EXPECTED,'full_copy':a.full,'files':changes},indent=2))
print(f'Copied {len(selected)} files. Quarantined exactly three known additions. No copied code executed; no pristine-distribution claim.')
