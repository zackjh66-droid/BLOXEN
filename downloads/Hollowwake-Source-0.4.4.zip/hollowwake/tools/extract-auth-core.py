from pathlib import Path
p=Path(__file__).resolve().parents[1]
a=(p/'backend/app.mjs').read_text(); start=a.index('  const limitStmt');end=a.index('\n  return { fetch: handle, auth, db, close: () => db.close() };')
core=a[start:end]
core=core.replace('db.prepare(', 'await db.prepare(')
# prepare() itself remains synchronous; await the terminal get/run/all calls.
core=core.replace('const limitStmt = await db.prepare(', 'const limitStmt = db.prepare(')
core=core.replace('function limit(', 'async function limit(').replace('limitStmt.get(', 'await limitStmt.get(')
core=core.replace(') limit(', ') await limit(').replace('; limit(', '; await limit(')
core=core.replace("readFileSync(new URL(`../web/${name}`, import.meta.url))", 'await readAsset(name)')
core=core.replace("emailDelivery: config.smtp ? 'smtp' : 'private-local-outbox'", "emailDelivery: config.emailDelivery || (config.smtp ? 'smtp' : 'private-local-outbox')")
# No unsupported/unconfigured mail action can pretend success in production.
core=core.replace("if (browserAuth.has(path)) {", "if (browserAuth.has(path)) {\n        if (config.emailDelivery === 'unavailable' && ['/api/auth/request-password-reset','/api/auth/reset-password','/api/auth/send-verification-email'].includes(path)) throw failure('email_delivery_unavailable', 503, 'Recovery and verification email are not configured. Keep your password safe.');")
header="import { createHmac } from 'node:crypto';\nimport QRCode from 'qrcode';\nimport { CLIENT_ID } from './auth-options.mjs';\n"+a[a.index('const security'):a.index('export async function createApplication')]
(p/'backend/core.mjs').write_text(header+'export function createCore(config, { db, auth, readAsset, close }) {\n'+core+'\n  return { fetch: handle, auth, db, close };\n}\n')
wrapper=a[:a.index('  const limitStmt')]+"  return createCore(config, { db, auth, readAsset: name => readFileSync(new URL(`../web/${name}`, import.meta.url)), close: () => db.close() });\n}\n"
wrapper=wrapper.replace("import QRCode from 'qrcode';", "import { createCore } from './core.mjs';")
wrapper=wrapper[:wrapper.index('const security')]+wrapper[wrapper.index('export async function createApplication'):]
(p/'backend/app.mjs').write_text(wrapper)
b=(p/'backend/auth.mjs').read_text(); opts=b[b.index('  const auth = betterAuth({'):b.index('\n  return auth;')].replace('  const auth = betterAuth({','  return {').replace('\n  });','\n  };')
(p/'backend/auth-options.mjs').write_text("import { bearer, deviceAuthorization, username } from 'better-auth/plugins';\nexport const CLIENT_ID = 'hollowwake-uwp';\nexport function authOptions(config, database, send) {\n"+opts+'\n}\n')
(p/'backend/auth.mjs').write_text("import { betterAuth } from 'better-auth';\nimport nodemailer from 'nodemailer';\nimport { authOptions } from './auth-options.mjs';\nexport { CLIENT_ID } from './auth-options.mjs';\nexport function createAuth(config, database, sendMailOverride) {\n  const mailer = config.smtp ? nodemailer.createTransport(config.smtp) : null;\n  const send = sendMailOverride || (async message => {\n    if (!mailer) throw new Error('Mail delivery is not configured');\n    await mailer.sendMail({ from: config.smtpFrom, ...message });\n  });\n  return betterAuth(authOptions(config, database, send));\n}\n")
