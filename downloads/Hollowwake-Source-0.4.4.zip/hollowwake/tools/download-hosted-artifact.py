import sys,json,urllib.request,termios
if sys.stdin.isatty():
 a=termios.tcgetattr(sys.stdin);a[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,a)
print('Ready for hidden artifact URL',flush=True)
c=json.loads(sys.stdin.readline())
with urllib.request.urlopen(c['url'],timeout=90) as r,open(sys.argv[1],'wb') as f:
 while True:
  b=r.read(1048576)
  if not b:break
  f.write(b)
print('Saved hosted build artifact')
