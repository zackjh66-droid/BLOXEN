"""Credential-stdin fallback; official Sites filesystem helpers are unavailable here."""
import sys,json,os,subprocess,tarfile,argparse
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('directory');ap.add_argument('--open',action='store_true');a=ap.parse_args();p=Path(a.directory)
if sys.stdin.isatty():
 import termios
 attrs=termios.tcgetattr(sys.stdin);attrs[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,attrs)
print('Ready for hidden credential JSON',flush=True)
c=json.loads(sys.stdin.readline());token=c.pop('token');env=os.environ.copy();env.update({'GIT_CONFIG_COUNT':'2','GIT_CONFIG_KEY_0':'http.extraHeader','GIT_CONFIG_VALUE_0':'Authorization: Bearer '+token,'GIT_CONFIG_KEY_1':'credential.helper','GIT_CONFIG_VALUE_1':'','GIT_TERMINAL_PROMPT':'0'})
def run(*args):
 r=subprocess.run(args,cwd=p,env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr.replace(token,'[redacted]')[:1200])
 return r.stdout.strip()
if not (p/'.git').exists():
 run('git','init','-b',c['branch']);run('git','config','user.name','Hollowwake Build');run('git','config','user.email','hollowwake-build@users.noreply.github.com');run('git','remote','add','origin',c['remote_url'])
if a.open:
 run('git','fetch','origin',c['branch']);head=run('git','rev-parse','HEAD');remote=run('git','rev-parse','FETCH_HEAD')
 if head!=remote:raise RuntimeError('Remote changed; review before editing')
 print(json.dumps({'checkout_path':str(p),'commit_sha':head,'source_opened':True}));sys.exit()
run('git','add','.')
if run('git','status','--porcelain'):run('git','commit','-m','Hollowwake visual refresh and secure project administration')
commit=run('git','rev-parse','HEAD');run('git','push','origin','HEAD:refs/heads/'+c['branch'])
if run('git','status','--porcelain'):raise RuntimeError('Source changed after commit')
archive='/workspace/'+p.name+'-deployment.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 t.add(p/'.openai/hosting.json',arcname='.openai/hosting.json')
 for f in sorted((p/'dist').rglob('*')):
  if f.is_file():t.add(f,arcname=f.relative_to(p),recursive=False)
r={'project_id':json.loads((p/'.openai/hosting.json').read_text())['project_id'],'commit_sha':commit,'archive':archive}
Path('/workspace/hollowwake/evidence/redesign/'+p.name+'-source.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
