import sys,json,urllib.request,urllib.error,termios
if sys.stdin.isatty():
 a=termios.tcgetattr(sys.stdin);a[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,a)
print('Ready for hidden service credential',flush=True)
c=json.loads(sys.stdin.readline());h={'OAI-Sites-Authorization':'Bearer '+c['token']}
for path,data in [('/',None),('/api/control',{'action':'overview'})]:
 hh=h.copy()
 if data:hh.update({'Origin':c['origin'],'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(urllib.request.Request(c['origin']+path,headers=hh,data=json.dumps(data).encode() if data else None),timeout=30) as r:print(r.status,r.headers.get('Content-Type'),r.read(600).decode(errors='replace'))
 except urllib.error.HTTPError as e:print(e.code,e.read(600).decode(errors='replace'))
