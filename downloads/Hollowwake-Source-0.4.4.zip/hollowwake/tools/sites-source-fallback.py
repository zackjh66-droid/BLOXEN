"""Credential-stdin source synchronization when the Sites plugin's filesystem helpers are absent.
No credentials are persisted. The native Sites tools still save and deploy the artifact.
"""
import sys,json,os,subprocess,tarfile
from pathlib import Path
p=Path('/workspace/sites/hollowwake')
if sys.stdin.isatty():
 import termios
 attrs=termios.tcgetattr(sys.stdin);attrs[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,attrs)
print('Ready for hidden credential JSON',flush=True)
credential=json.loads(sys.stdin.readline());token=credential.pop('token');env=os.environ.copy();env.update({'GIT_CONFIG_COUNT':'2','GIT_CONFIG_KEY_0':'http.extraHeader','GIT_CONFIG_VALUE_0':'Authorization: Bearer '+token,'GIT_CONFIG_KEY_1':'credential.helper','GIT_CONFIG_VALUE_1':'','GIT_TERMINAL_PROMPT':'0'})
def run(*args):
 r=subprocess.run(args,cwd=p,env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr.replace(token,'[redacted]')[:1200])
 return r.stdout.strip()
if not (p/'.git').exists():
 run('git','init','-b',credential['branch']);run('git','config','user.name','Hollowwake Build');run('git','config','user.email','hollowwake-build@users.noreply.github.com');run('git','remote','add','origin',credential['remote_url'])
run('git','add','.');status=run('git','status','--porcelain')
if status:run('git','commit','-m','Deploy preserved Hollowwake website and real D1 authentication backend')
commit=run('git','rev-parse','HEAD');run('git','push','origin','HEAD:refs/heads/'+credential['branch'])
if run('git','status','--porcelain'):raise RuntimeError('Source changed after commit')
archive='/workspace/hollowwake-sites-deployment.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 t.add(p/'.openai/hosting.json',arcname='.openai/hosting.json')
 for f in sorted((p/'dist').rglob('*')):
  if f.is_file():t.add(f,arcname=f.relative_to(p),recursive=False)
result={'project_id':json.loads((p/'.openai/hosting.json').read_text())['project_id'],'commit_sha':commit,'archive':archive,'helper_limitation':'Official plugin scripts absent from this filesystem and unavailable through skill resources; used credential-stdin Git plus artifact tar and native Sites publish tools.'}
Path('/workspace/hollowwake/evidence/delivery/sites-source-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
