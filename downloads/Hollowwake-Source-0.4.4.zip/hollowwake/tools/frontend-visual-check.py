import asyncio,json,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
out=Path('/workspace/hollowwake/evidence/redesign');origin='https://hollowwake.jihnjohn10.chatgpt.site'
async def main():
 report={'testedViewportWidths':[1440,390],'hashes':{}}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True);page=await b.new_page(viewport={'width':1440,'height':1000});await page.goto(origin,wait_until='networkidle')
  for name in ['index.html','app.js','style.css','logo.svg','favicon.png']:
   # Use the existing browser transport (direct Python urllib is denied by the edge).
   path='/' if name=='index.html' else '/'+name
   data=await page.evaluate('''async(path)=>{const r=await fetch(path);if(!r.ok)throw Error(String(r.status));return Array.from(new Uint8Array(await r.arrayBuffer()))}''',path)
   raw=bytes(data);assert raw==(Path('/workspace/sites/hollowwake/web')/name).read_bytes(),name;report['hashes'][name]=hashlib.sha256(raw).hexdigest()
  await page.screenshot(path=str(out/'website-final-desktop.png'),full_page=True)
  await page.set_viewport_size({'width':390,'height':844});await page.screenshot(path=str(out/'website-final-mobile.png'),full_page=True);assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth');await b.close()
 report['result']='PASS';out.joinpath('live-frontend-hashes.json').write_text(json.dumps(report,indent=2));print('Final deployed frontend and branding exactly match source; desktop/mobile visual checks pass.')
asyncio.run(main())
