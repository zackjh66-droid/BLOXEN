"""Historical pre-hardening live CRUD QA. Current deployments require signed-in owner identity; use admin-final-check.py for identity-less access-denial/layout verification. Platform service credential arrives by hidden stdin only."""
import os,sys,json,asyncio,secrets
from pathlib import Path
from playwright.async_api import async_playwright
if sys.stdin.isatty():
 import termios
 attrs=termios.tcgetattr(sys.stdin);attrs[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,attrs)
print('Ready for hidden service credential',flush=True)
config=json.loads(sys.stdin.readline());origin=config['origin'];token=config['token'];out=Path('/workspace/hollowwake/evidence/redesign')
async def main():
 report={'tests':[],'page_errors':[],'privateSite':True,'platformOwnerLoginTested':False,'serviceAccessTested':True}
 globals()['qa_report']=report
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
  anon=await browser.new_context();page=await anon.new_page();r=await page.goto(origin,wait_until='domcontentloaded');assert not await page.locator('#metrics').count();report['tests'].append('Anonymous visitor cannot load admin UI');await anon.close()
  context=await browser.new_context(viewport={'width':1440,'height':1000},extra_http_headers={'OAI-Sites-Authorization':'Bearer '+token})
  page=await context.new_page();page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
  await page.goto(origin,wait_until='networkidle');await page.locator('.metric').first.wait_for();await page.screenshot(path=str(out/'admin-desktop.png'),full_page=True);report['tests'].append('Private overview reaches live main backend without exposing RPC credential')
  # Only create/delete a namespaced test catalog document. Never mutate player accounts here.
  await page.get_by_role('button',name='Cosmetic catalog',exact=True).click();await page.get_by_role('button',name='New cosmetic',exact=True).click()
  record='qa-control-'+secrets.token_hex(5);await page.locator('#doc-id').fill(record);await page.locator('#doc-title').fill('Temporary QA catalog record');await page.locator('#template-id').fill('AthenaCharacter:CID_Hollowwake_QA');await page.get_by_role('button',name='Save record',exact=True).click();await page.locator('#editor').wait_for(state='hidden');card=page.locator('#catalog-list article').filter(has_text=record);await card.wait_for();report['tests'].append('Catalog editor persists real live project record')
  await card.get_by_role('button',name='Edit',exact=True).click();await page.locator('#doc-title').fill('Updated temporary QA record');await page.get_by_role('button',name='Save record',exact=True).click();await page.locator('#editor').wait_for(state='hidden');await card.get_by_role('heading',name='Updated temporary QA record',exact=True).wait_for();report['tests'].append('Versioned update survives refresh');await page.reload(wait_until='networkidle');await page.get_by_role('button',name='Cosmetic catalog',exact=True).click();card=page.locator('#catalog-list article').filter(has_text=record);await card.wait_for()
  page.once('dialog',lambda d:d.accept());await card.get_by_role('button',name='Delete',exact=True).click();await card.wait_for(state='detached');report['tests'].append('Confirmed delete removes only QA record')
  await page.get_by_role('button',name='Audit trail',exact=True).click();await page.locator('#audit-list').get_by_text('documents.delete · '+record,exact=True).wait_for();report['tests'].append('Live audit trail records QA mutations')
  await context.set_extra_http_headers({'OAI-Sites-Authorization':'Bearer '+token})
  # Direct browser mutation with foreign Origin must fail despite valid platform access.
  api=await p.request.new_context(proxy={'server':os.environ['HTTPS_PROXY']} if os.environ.get('HTTPS_PROXY') else None,extra_http_headers={'OAI-Sites-Authorization':'Bearer '+token});r=await api.post(origin+'/api/control',headers={'Origin':'https://attacker.example','Content-Type':'application/json'},data=json.dumps({'action':'overview'}));assert r.status==403, 'Foreign-Origin response status: '+str(r.status);await api.dispose();report['tests'].append('Cross-origin admin mutation rejected')
  await page.set_viewport_size({'width':390,'height':844});await page.get_by_role('button',name='Overview',exact=True).click();await page.screenshot(path=str(out/'admin-mobile.png'),full_page=True);widths=await page.evaluate('({scroll:document.documentElement.scrollWidth,width:innerWidth})');assert widths['scroll']<=widths['width'],str(widths);report['tests'].append('Mobile owner dashboard has no horizontal document overflow')
  assert not report['page_errors'];await browser.close()
 (out/'admin-browser-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
try:asyncio.run(main())
except Exception as e:
 report=globals().get('qa_report',{});report['failure']=str(e).replace(token,'[REDACTED]');out.joinpath('admin-browser-partial.json').write_text(json.dumps(report,indent=2));print(('QA failed: '+str(e)).replace(token,'[REDACTED]'));sys.exit(1)
