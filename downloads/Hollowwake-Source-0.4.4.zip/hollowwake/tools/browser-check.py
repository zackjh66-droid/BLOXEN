"""Interactive browser checks against our loopback service only. Never logs secrets."""
import asyncio,json,secrets,re,time,os,sqlite3
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/continuation';OUT.mkdir(parents=True,exist_ok=True)
ORIGIN=os.environ.get('HOLLOWWAKE_BROWSER_ORIGIN','http://127.0.0.1:8787')
DATA=Path(os.environ.get('HOLLOWWAKE_BROWSER_DATA_DIR',str(ROOT/'data')))
async def main():
  report={'browser':'/usr/bin/chromium','origin':ORIGIN,'tests':[],'page_errors':[],'screenshots':[]}
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    context=await browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=1)
    page=await context.new_page();page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
    device=await p.request.new_context(base_url=ORIGIN)
    name='qa_'+secrets.token_hex(4);password=secrets.token_urlsafe(30);email=name+'@example.test'
    await page.goto(ORIGIN,wait_until='networkidle')
    await page.screenshot(path=str(OUT/'website-desktop.png'),full_page=True);report['screenshots'].append('website-desktop.png')
    await page.get_by_role('button',name='Create account',exact=True).click()
    await page.get_by_label('Public username',exact=True).first.fill(name)
    await page.get_by_label('Email address',exact=True).first.fill(email)
    await page.get_by_label('Password',exact=True).fill(password)
    await page.get_by_role('button',name='Create your account').click()
    await page.locator('#signed-in').wait_for(state='visible')
    assert await page.locator('#public-name').inner_text()==name
    report['tests'].append('Browser registration and automatic cookie sign-in')
    response=await device.post('/api/device/code',data={'client_id':'hollowwake-uwp'});assert response.status==200
    issued=await response.json()
    qrurl=issued['verification_uri_complete'];assert issued['device_code'] not in qrurl
    await page.goto(qrurl,wait_until='networkidle')
    await page.get_by_role('button',name='Review device').click()
    await page.locator('#approval').wait_for(state='visible')
    assert await page.get_by_role('button',name='Approve device',exact=True).is_disabled()
    assert await page.locator('#approval-code').inner_text()==issued['user_code'][:4]+' '+issued['user_code'][4:]
    await page.get_by_label('This is my device, and its displayed code matches.').focus()
    await page.keyboard.press('Space');await page.keyboard.press('Tab')
    assert await page.evaluate('document.activeElement.id')=='approve'
    await page.keyboard.press('Enter')
    report['tests'].append('Keyboard focus, possession checkbox and explicit approval via Enter')
    await page.get_by_text('Approved. Your companion will finish linking automatically. This does not start Fortnite.',exact=True).wait_for()
    tokens=await device.post('/api/device/token',data={'client_id':'hollowwake-uwp','device_code':issued['device_code'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code'});assert tokens.status==200
    token=(await tokens.json())['access_token']
    profile=await device.get('/api/device/profile',headers={'Authorization':'Bearer '+token});assert profile.status==200
    assert (await profile.json())['publicUsername']==name
    report['tests'].append('Real browser review/explicit approval, device polling redemption and profile mapping')
    await page.goto(ORIGIN+'/link?user_code='+issued['user_code'],wait_until='networkidle')
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('That code has already been processed. Request a new one on the device.',exact=True).wait_for()
    report['tests'].append('Redeemed public code has a distinct already-used browser error')
    expired_response=await device.post('/api/device/code',data={'client_id':'hollowwake-uwp'});assert expired_response.status==200
    expired=await expired_response.json()
    with sqlite3.connect(DATA/'db.sqlite') as db:
      db.execute('UPDATE deviceCode SET expiresAt=? WHERE deviceCode=?',(int(time.time()*1000)-1000,expired['device_code']))
    await page.goto(ORIGIN+'/link?user_code='+expired['user_code'],wait_until='networkidle')
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('That code has expired. Choose Retry on your device for a new code.',exact=True).wait_for()
    report['tests'].append('Browser expiry message exercised with a controlled timestamp in the temporary QA database')


    await page.goto(ORIGIN+'/settings',wait_until='networkidle')
    await page.locator('.device-row').wait_for(state='visible')
    await page.reload(wait_until='networkidle');assert await page.locator('#public-name').inner_text()==name
    await page.get_by_role('button',name='Revoke',exact=True).click()
    await page.get_by_text('Device revoked. Its session can no longer access your profile.',exact=True).wait_for()
    assert (await device.get('/api/device/profile',headers={'Authorization':'Bearer '+token})).status==401
    report['tests'].append('Browser session survives reload; account device list and revocation invalidate device token')
    await page.get_by_role('button',name='Sign out',exact=True).click()
    await page.locator('#auth-panel').wait_for(state='visible')
    await page.get_by_label('Email address',exact=True).first.fill(email);await page.get_by_label('Password',exact=True).fill(password)
    await page.get_by_role('button',name='Sign in',exact=False).last.click()
    await page.locator('#signed-in').wait_for(state='visible');report['tests'].append('Browser logout and existing-user sign-in')
    await page.goto(ORIGIN+'/recover',wait_until='networkidle')
    await page.get_by_label('Email address',exact=True).last.fill(email)
    await page.get_by_role('button',name='Send recovery email',exact=True).click()
    await page.get_by_text(re.compile('If that account exists, a recovery message has been sent')).wait_for()
    report['tests'].append('Browser recovery request completed; mail is private local outbox, not public delivery')
    # Read only this newly-created test account's local message; never print/save its secret link.
    message=None
    for mailfile in (DATA/'outbox').glob('*.json'):
      item=json.loads(mailfile.read_text())
      if item.get('to')==email and item.get('subject')=='Reset your Hollowwake password':message=item
    assert message is not None
    recovery_url=re.search(r'http[^\s]+',message['text']).group(0)
    await page.goto(recovery_url,wait_until='networkidle')
    assert not page.url.split('#')[-1].startswith('token=')
    new_password=secrets.token_urlsafe(30)
    await page.locator('#reset-form input[name="newPassword"]').fill(new_password)
    await page.get_by_role('button',name='Reset password',exact=True).click()
    await page.get_by_text('Password reset. Return to sign in. Previous sessions have ended.',exact=True).wait_for()
    await page.goto(ORIGIN,wait_until='networkidle');await page.locator('#auth-panel').wait_for(state='visible')
    await page.locator('#auth-form input[name="email"]').fill(email)
    await page.locator('#auth-form input[name="password"]').fill(new_password)
    await page.locator('#auth-submit').click();await page.locator('#signed-in').wait_for(state='visible')
    report['tests'].append('Browser recovery email → fragment-token reset → invalidated old session → login with new password')
    await page.goto(ORIGIN+'/link',wait_until='networkidle')
    await page.locator('#user-code').fill('AAAAAAAA');await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('That code is invalid. Check the eight characters on your device.',exact=True).wait_for()
    report['tests'].append('Invalid code displays the expected actionable browser error')
    await context.set_offline(True)
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('Connection lost. Check your network, then try again.',exact=True).wait_for()
    await context.set_offline(False)
    report['tests'].append('Browser reports connectivity loss and resumes requests after network restoration')
    for _ in range(9):
      await context.request.post(ORIGIN+'/api/link/verify',data={'user_code':'AAAAAAAA'},headers={'Origin':ORIGIN})
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('Too many attempts. Wait ten minutes before trying again.',exact=True).wait_for()
    report['tests'].append('Browser displays the rate-limit error after exhausting real API attempts')


    mobile=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
    phone=await mobile.new_page();phone.on('pageerror',lambda e:report['page_errors'].append(str(e)))
    for path in ['/','/link','/recover','/reset','/settings']:
      await phone.goto(ORIGIN+path,wait_until='networkidle')
      widths=await phone.evaluate('({scroll:document.documentElement.scrollWidth,viewport:innerWidth})')
      assert widths['scroll']<=widths['viewport']+1,(path,widths)
    await phone.goto(ORIGIN,wait_until='networkidle');await phone.screenshot(path=str(OUT/'website-mobile.png'),full_page=True);report['screenshots'].append('website-mobile.png')
    report['tests'].append('390px mobile routes load without horizontal overflow')
    assert not report['page_errors'],report['page_errors']
    await device.dispose();await mobile.close();await context.close();await browser.close()
  report['result']='PASS';(OUT/'browser-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({'result':report['result'],'tests':report['tests'],'page_errors':report['page_errors']},indent=2))
if __name__=='__main__':asyncio.run(main())
