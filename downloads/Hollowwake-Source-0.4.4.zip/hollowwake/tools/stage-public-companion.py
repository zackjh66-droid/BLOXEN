"""Publish only project-owned companion inputs to a dedicated branch; no Epic files."""
import subprocess,json,base64,io,sys
from pathlib import Path
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]; repo='zackjh66-droid/BLOXEN'; branch='hollowwake/companion-build'
def api(path,payload=None,method=None):
 p=subprocess.run(['gh','api','repos/'+repo+'/'+path]+(['--method',method or 'POST','--input','-'] if payload is not None else []),input=json.dumps(payload) if payload is not None else None,text=True,capture_output=True)
 if p.returncode: raise RuntimeError(p.stderr[:500]+p.stdout[:500])
 return json.loads(p.stdout) if p.stdout.strip() else {}
head=api('git/ref/heads/main')['object']['sha']; base=api('git/commits/'+head)['tree']['sha']
image=Image.new('RGB',(1280,720),'#110d20');d=ImageDraw.Draw(image)
for y in range(720):d.line((0,y,1280,y),fill=(17+y//55,13+y//70,32+y//14))
d.ellipse((650,80,1050,480),outline='#7b60ac',width=3);d.polygon([(260,290),(680,230),(1020,340),(620,410)],fill='#776194');d.polygon([(260,290),(620,410),(540,610)],fill='#372d51');d.polygon([(620,410),(1020,340),(540,610)],fill='#4b3a68');d.line((590,170,620,410),fill='#d5fb80',width=9)
buf=io.BytesIO();image.save(buf,format='JPEG',quality=92)
files={}
for f in (root/'uwp').rglob('*'):
 if f.is_file() and not any(x in f.parts for x in ['bin','obj','AppPackages']):files['hollowwake/'+f.relative_to(root).as_posix()]=f.read_bytes()
files['hollowwake/uwp/Hollowwake/Assets/Landmark.jpg']=buf.getvalue()
# Public build variant has original Hollowwake art, never the private Epic movie frame.
x='hollowwake/uwp/Hollowwake/MainPage.xaml';files[x]=files[x].replace(b'Fortnite artwork \xc2\xa9 Epic Games. ',b'')
files['hollowwake/tools/Build-Uwp.ps1']=(root/'tools/Build-Uwp.ps1').read_bytes()
workflow=(root/'remote-build/.github/workflows/hollowwake-companion.yml').read_text().replace('Owner has confirmed included Windows minutes/storage or explicitly authorized costs','Verified standard public-repository runner is free; no paid runner')
files['.github/workflows/hollowwake-companion.yml']=workflow.encode()
entries=[]
for path,data in files.items():
 blob=api('git/blobs',{'content':base64.b64encode(data).decode(),'encoding':'base64'})
 entries.append({'path':path,'mode':'100644','type':'blob','sha':blob['sha']})
tree=api('git/trees',{'base_tree':base,'tree':entries})
commit=api('git/commits',{'message':'Build independent Hollowwake UWP companion with original project artwork; no Fortnite files','tree':tree['sha'],'parents':[head]})
try:api('git/refs',{'ref':'refs/heads/'+branch,'sha':commit['sha']})
except RuntimeError:api('git/refs/heads/'+branch,{'sha':commit['sha'],'force':False},'PATCH')
# Register dispatchable workflow without changing the existing README or other main files.
mt=api('git/trees',{'base_tree':base,'tree':[e for e in entries if e['path'].startswith('.github/')]})
mc=api('git/commits',{'message':'Register manually dispatched free Windows companion build','tree':mt['sha'],'parents':[head]})
api('git/refs/heads/main',{'sha':mc['sha'],'force':False},'PATCH')
result={'repository':repo,'branch':branch,'commit':commit['sha'],'workflow_registration_commit':mc['sha'],'file_count':len(files),'epic_assets_uploaded':False,'private_keys_uploaded':False}
(root/'evidence/delivery/public-ci-staging.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
