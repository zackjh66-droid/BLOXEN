from pathlib import Path
import hashlib,json,zipfile
p=Path(__file__).resolve().parents[1]
allowed_dirs=['backend','web','uwp','docs','tools','tests','remote-build']
files=[p/n for n in ['README.md','package.json','package-lock.json','.env.example','.gitignore','.dockerignore','Dockerfile']]
for name in allowed_dirs:
 for f in (p/name).rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts and not any(v in f.parts for v in ['bin','obj','AppPackages']):files.append(f)
for f in (p/'evidence').iterdir():
 if f.is_file() and f.name not in ['source-delivery-manifest.json','package-result.log'] and f.suffix in ['.json','.log','.sha256','.txt']:files.append(f)
for f in (p/'evidence/continuation').iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.sha256','.txt','.png'] and f.name not in ['package-result.log','source-delivery-manifest.json','artifact-bundles.log']:files.append(f)
files=sorted(set(files))
for f in files:
 assert f.name not in ['.env'] and f.suffix.lower() not in ['.pfx','.key','.exe','.dll','.sqlite','.mp4','.zip']
manifest=[{'path':str(f.relative_to(p)),'sha256':hashlib.file_digest(f.open('rb'),'sha256').hexdigest(),'action':'new project source/derived visual asset or retained inspection evidence; original archive unchanged'} for f in files]
manifest_path=p/'evidence/source-delivery-manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2));files.append(manifest_path)
out=p.parent/'hollowwake-source-continuation.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,Path('hollowwake')/f.relative_to(p))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert not any('/quarantine/' in n or '/data/' in n or n.endswith(('.pfx','.key','.exe','.dll')) for n in z.namelist())
sha=hashlib.file_digest(out.open('rb'),'sha256').hexdigest();out.with_suffix('.zip.sha256').write_text(sha+'  '+out.name+'\n')
print(json.dumps({'source_zip':str(out),'bytes':out.stat().st_size,'files':len(files),'sha256':sha,'appx_created':False,'includes_game_executables':False,'includes_private_keys':False},indent=2))
