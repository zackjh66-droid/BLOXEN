from pathlib import Path
import subprocess,json,base64,sys
p=Path(__file__).resolve().parents[1];repo='zackjh66-droid/BLOXEN';branch='hollowwake/companion-build'
def api(path,payload=None,method=None):
 r=subprocess.run(['gh','api','repos/'+repo+'/'+path]+(['--method',method or 'POST','--input','-'] if payload is not None else []),input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr[:600])
 return json.loads(r.stdout) if r.stdout.strip() else {}
head=api('git/ref/heads/'+branch)['object']['sha'];base=api('git/commits/'+head)['tree']['sha'];entries=[]
for name in sys.argv[1:]:
 data=(p/name).read_bytes()
 if name.endswith('MainPage.xaml'):data=data.replace(b'Fortnite artwork \xc2\xa9 Epic Games. ',b'')
 blob=api('git/blobs',{'content':base64.b64encode(data).decode(),'encoding':'base64'});entries.append({'path':'hollowwake/'+name,'mode':'100644','type':'blob','sha':blob['sha']})
tree=api('git/trees',{'base_tree':base,'tree':entries});c=api('git/commits',{'message':'Fix observed Hollowwake companion Windows build issues','tree':tree['sha'],'parents':[head]});api('git/refs/heads/'+branch,{'sha':c['sha'],'force':False},'PATCH');print(json.dumps({'commit':c['sha'],'changed_files':sys.argv[1:]}))
