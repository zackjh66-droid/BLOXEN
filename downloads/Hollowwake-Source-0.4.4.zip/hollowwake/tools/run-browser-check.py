"""Run a temporary local auth service and Chromium QA without changing existing data."""
from pathlib import Path
import os,subprocess,tempfile,secrets,time,http.client
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='hollowwake-browser-') as tmp:
 env=os.environ.copy();env.update(PUBLIC_ORIGIN='http://127.0.0.1:8790',ALLOW_LOCAL_HTTP='1',HOST='127.0.0.1',PORT='8790',DATABASE_PATH=str(Path(tmp)/'db.sqlite'),BETTER_AUTH_SECRET=secrets.token_urlsafe(48),SMTP_HOST='',SMTP_FROM='',REQUIRE_EMAIL_VERIFICATION='0',HOLLOWWAKE_BROWSER_ORIGIN='http://127.0.0.1:8790',HOLLOWWAKE_BROWSER_DATA_DIR=tmp)
 log=ROOT/'evidence/continuation/browser-service.log'
 with log.open('w') as stream:
  process=subprocess.Popen(['node','backend/server.mjs'],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT)
  try:
   for i in range(100):
    if process.poll() is not None:raise SystemExit('Temporary QA service failed; see browser-service.log')
    try:
     c=http.client.HTTPConnection('127.0.0.1',8790,timeout=1);c.request('GET','/api/status');r=c.getresponse();ok=r.status==200;r.read();c.close()
     if ok:break
    except OSError:pass
    time.sleep(.1)
   else:raise SystemExit('QA service readiness failed')
   result=subprocess.run(['python3','tools/browser-check.py'],cwd=ROOT,env=env,timeout=180)
   if result.returncode:raise SystemExit(result.returncode)
  finally:
   process.terminate()
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:process.kill();process.wait()
