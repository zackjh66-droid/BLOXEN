"""Static source checks only, not a Windows/UWP compile or runtime test."""
from pathlib import Path
import xml.etree.ElementTree as ET
import re,json
from PIL import Image
root=Path(__file__).resolve().parents[1]
for f in (root/'uwp').rglob('*'):
    if f.suffix in ['.xml','.xaml','.csproj','.appxmanifest']:ET.parse(f)
for f in (root/'uwp/Hollowwake/Assets').glob('*.png'):
    with Image.open(f) as im:im.verify()
for source in (root/'uwp').rglob('*.cs'):
    s=source.read_text();assert 'Process.Start' not in s and 'DllImport' not in s
print('XML parsed; native PNG assets decode; no desktop execution/injection code. Windows build and Xbox runtime NOT performed.')
