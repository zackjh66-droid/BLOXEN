from pathlib import Path
import zipfile,json,hashlib,difflib,tempfile,subprocess
p=Path(__file__).resolve().parents[1];out=p.parent
full=out/'hollowwake-source-continuation.zip';baseline=out/'hollowwake-source.zip'
with zipfile.ZipFile(full) as z:current={n.removeprefix('hollowwake/'):z.read(n) for n in z.namelist()}
with zipfile.ZipFile(baseline) as z:old={n.removeprefix('hollowwake/'):z.read(n) for n in z.namelist()}
roots={'backend','web','uwp','docs','tools','tests','remote-build'}
text_extensions={'.md','.mjs','.js','.css','.html','.json','.sql','.py','.yml','.yaml','.ps1','.cs','.csproj','.sln','.xaml','.appxmanifest','.xml','.txt'}
patch=[]
for name in sorted(set(current)|set(old)):
 if name.split('/')[0] not in roots and name not in ['README.md','package.json','package-lock.json','.gitignore','.dockerignore','Dockerfile','.env.example']:continue
 if Path(name).suffix not in text_extensions and '/' in name:continue
 a=old.get(name,b'');b=current.get(name,b'')
 if a==b:continue
 try:before=a.decode();after=b.decode()
 except UnicodeDecodeError:continue
 patch.append(f'diff --git a/{name} b/{name}\n')
 if name not in old:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+name if name in old else '/dev/null',tofile='b/'+name if name in current else '/dev/null'))
patchfile=out/'hollowwake-continuation.patch';patchfile.write_text(''.join(patch))
with tempfile.TemporaryDirectory(prefix='hollowwake-patch-check-') as tmp:
 root=Path(tmp)
 for name,data in old.items():
  f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 r=subprocess.run(['git','apply','--check',str(patchfile)],cwd=root,capture_output=True,text=True)
 if r.returncode:raise SystemExit('Patch validation failed: '+r.stderr)
def bundle(filename,select,overrides=None):
 f=out/filename
 with zipfile.ZipFile(f,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in current.items():
   if select(name):z.writestr('hollowwake/'+name,(overrides or {}).get(name,data))
 with zipfile.ZipFile(f) as z:assert z.testzip() is None
 return f
web_package=json.loads(current['package.json']);web_package['scripts'].pop('check',None)
web_readme=b'''# Hollowwake website/backend

Working local companion accounts service, not a Fortnite client. No public deployment is configured.

This component archive includes registration/login/recovery, explicit device-code approval, sessions/revocation, migrations and backend integration tests. The full source bundle contains native source and browser QA tooling.

For optional development on a suitable Node 24 host: npm ci --ignore-scripts; copy .env.example to .env; node tools/init-local.mjs; npm run migrate; npm run dev. Run npm test for the included service suite. These steps are reproducibility instructions, not a requirement for the user to perform local compilation.

See docs/DEPLOYMENT.md and docs/CONTINUATION-REPORT.md. No live website address, APPX or actual Fortnite lobby is claimed. No credentials or signing keys are included.
'''
website=bundle('hollowwake-website-backend.zip',lambda n:n.split('/')[0] in {'backend','web','tests'} or n in {'README.md','package.json','package-lock.json','.env.example','.gitignore','.dockerignore','Dockerfile','tools/init-local.mjs','tools/device-simulator.mjs','tools/http-smoke.mjs','docs/API.md','docs/AUTHENTICATION.md','docs/DEPLOYMENT.md','docs/CONTINUATION-REPORT.md'},overrides={'package.json':json.dumps(web_package,indent=2).encode()+b'\n','README.md':web_readme})
native=bundle('hollowwake-native-source-unbuilt.zip',lambda n:n.split('/')[0] in {'uwp','remote-build'} or n in {'tools/Build-Uwp.ps1','docs/XBOX.md','docs/PORT-FEASIBILITY.md','docs/CONTINUATION-REPORT.md'})
verification=bundle('hollowwake-verification.zip',lambda n:n.startswith('evidence/continuation/') or n in {'docs/CONTINUATION-REPORT.md','docs/TESTING.md','docs/PORT-FEASIBILITY.md','tools/inspect-client-compatibility.py','tools/browser-check.py','tools/run-browser-check.py'})
artifacts=[]
for f in [full,website,native,verification,patchfile]:
 artifacts.append({'name':f.name,'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.file_digest(f.open('rb'),'sha256').hexdigest()})
(out/'hollowwake-artifacts.json').write_text(json.dumps({'artifacts':artifacts,'appx_produced':False,'patch_validated_against':'hollowwake-source.zip','private_keys_included':False},indent=2))
print(json.dumps({'artifacts':artifacts,'appx_produced':False,'patch_check':'PASS'},indent=2))
