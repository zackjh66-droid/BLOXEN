// Uses a fresh throwaway account against a local service. No secrets are printed.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
const origin = process.argv[2] || 'http://127.0.0.1:8787';
if (!['127.0.0.1', 'localhost'].includes(new URL(origin).hostname)) throw Error('Smoke tool is restricted to loopback test deployments');
for (const [path, type] of [['/', 'text/html'], ['/link', 'text/html'], ['/settings', 'text/html'], ['/recover', 'text/html'], ['/reset', 'text/html'], ['/style.css', 'text/css'], ['/app.js', 'text/javascript'], ['/assets/landmark.jpg', 'image/jpeg']]) {
  const r = await fetch(origin + path); assert.equal(r.status, 200); assert(r.headers.get('content-type').includes(type)); assert.equal(r.headers.get('cache-control'), 'no-store'); console.log(`${path}: 200 ${type}`);
}
let cookie = '';
async function call(path, body, browser = false, token) {
  const response = await fetch(origin + path, { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(browser ? { origin, cookie } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  if (browser) { const next = response.headers.getSetCookie(); if (next.length) cookie = next.map(c => c.split(';')[0]).join('; '); }
  return { status: response.status, data: await response.json() };
}
const name = 'http_' + randomUUID().slice(0, 8), password = randomUUID() + randomUUID();
assert.equal((await call('/api/auth/sign-up/email', { email: `${name}@example.test`, name, username: name, password }, true)).status, 200);
const device = (await call('/api/device/code', { client_id: 'hollowwake-uwp' })).data;
assert.equal((await call('/api/link/verify', { user_code: device.user_code }, true)).status, 200);
assert.equal((await call('/api/link/approve', { user_code: device.user_code }, true)).status, 200);
const issued = await call('/api/device/token', { client_id: 'hollowwake-uwp', grant_type: 'urn:ietf:params:oauth:grant-type:device_code', device_code: device.device_code }); assert.equal(issued.status, 200);
assert.equal((await call('/api/device/profile', undefined, false, issued.data.access_token)).data.publicUsername, name);
assert.equal((await call('/api/device/matchmaking', {}, false, issued.data.access_token)).status, 409);
assert.equal((await call('/api/device/logout', {}, false, issued.data.access_token)).status, 200);
assert.equal((await call('/api/device/profile', undefined, false, issued.data.access_token)).status, 401);
await call('/api/auth/sign-out', {}, true);
console.log('Live loopback HTTP flow: registration → browser approval → device token → test profile → disabled matches → revocation PASSED. No Xbox/Fortnite client ran.');
