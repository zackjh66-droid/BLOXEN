from pathlib import Path
from PIL import Image,ImageDraw
import shutil
p=Path('/workspace/hollowwake/branding');p.mkdir(exist_ok=True)
# Two upright strokes linked by an offset open wake; intentionally asymmetric negative space.
polys=[[(12,8),(30,8),(30,42),(55,42),(43,58),(30,58),(30,88),(12,88)],[(66,8),(84,8),(84,88),(66,88),(66,58),(51,58),(63,42),(66,42)]]
svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><title>Hollowwake</title><g fill="white">'+''.join('<polygon points="'+' '.join(f'{x},{y}' for x,y in poly)+'"/>' for poly in polys)+'</g></svg>'
(p/'hollowwake.svg').write_text(svg)
def logo(w,h,size,bg=(0,0,0,255)):
 im=Image.new('RGBA',(w*3,h*3),bg);d=ImageDraw.Draw(im)
 for poly in polys:d.polygon([((w-size)/2*3+x/96*size*3,(h-size)/2*3+y/96*size*3) for x,y in poly],fill='white')
 return im.resize((w,h),Image.Resampling.LANCZOS)
a=Path('/workspace/hollowwake/uwp/Hollowwake/Assets')
for n,w,h,s in [('Square44x44Logo',44,44,32),('Square150x150Logo',150,150,104),('Wide310x150Logo',310,150,104),('StoreLogo',50,50,36),('SplashScreen',620,300,116),('HollowwakeMark',192,192,176)]:logo(w,h,s,bg=(0,0,0,0) if n=='HollowwakeMark' else (0,0,0,255)).save(a/(n+'.png'))
for root in [Path('/workspace/sites/hollowwake/web'),Path('/workspace/hollowwake/web')]:
 (root/'logo.svg').write_text(svg);logo(64,64,48).save(root/'favicon.png')
print('Original vector H and native PNG variants generated.')
