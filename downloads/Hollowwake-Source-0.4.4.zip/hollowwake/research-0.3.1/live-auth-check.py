"""Browser QA against the actual deployed site. Never logs passwords or device secrets."""
import asyncio,json,secrets,re,time,os,sqlite3
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path('/workspace/hollowwake')
OUT=Path(os.environ.get('HOLLOWWAKE_BROWSER_OUT',str(ROOT/'evidence/delivery')));OUT.mkdir(parents=True,exist_ok=True)
ORIGIN=os.environ.get('HOLLOWWAKE_BROWSER_ORIGIN','https://hollowwake.jihnjohn10.chatgpt.site')
DATA=Path(os.environ.get('HOLLOWWAKE_BROWSER_DATA_DIR',str(ROOT/'data')))
async def main():
  report={'browser':'/usr/bin/chromium','origin':ORIGIN,'tests':[],'page_errors':[],'screenshots':[]}
  globals()['qa_report']=report
  async with async_playwright() as p:
    browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    context=await browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=1)
    page=await context.new_page();report['api_statuses']=[];page.on('response',lambda r:report['api_statuses'].append({'path':r.url.split('?')[0].replace(ORIGIN,''),'status':r.status}) if '/api/' in r.url else None);page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
    device=await p.request.new_context(base_url=ORIGIN,proxy={'server':os.environ['HTTPS_PROXY']} if os.environ.get('HTTPS_PROXY') else None)
    name='qa_'+secrets.token_hex(4);password=secrets.token_urlsafe(30);email=name+'@example.test'
    await page.goto(ORIGIN,wait_until='networkidle')
    await page.screenshot(path=str(OUT/'website-desktop.png'),full_page=True);report['screenshots'].append('website-desktop.png')
    await page.get_by_role('button',name='Create account',exact=True).click()
    await page.get_by_label('Public username',exact=True).first.fill(name)
    await page.get_by_label('Email address',exact=True).first.fill(email)
    await page.get_by_label('Password',exact=True).fill(password)
    await page.get_by_role('button',name='Create your account').click()
    await page.locator('#signed-in').wait_for(state='visible')
    assert await page.locator('#public-name').inner_text()==name
    report['tests'].append('Browser registration and automatic cookie sign-in')
    response=await device.post('/api/device/code',data={'client_id':'hollowwake-uwp'});assert response.status==200
    issued=await response.json()
    qrurl=issued['verification_uri_complete'];assert issued['device_code'] not in qrurl
    await page.goto(qrurl,wait_until='networkidle')
    await page.get_by_role('button',name='Review device').click()
    await page.locator('#approval').wait_for(state='visible')
    assert await page.get_by_role('button',name='Approve device',exact=True).is_disabled()
    assert await page.locator('#approval-code').inner_text()==issued['user_code'][:4]+' '+issued['user_code'][4:]
    other=await p.request.new_context(base_url=ORIGIN,proxy={'server':os.environ['HTTPS_PROXY']} if os.environ.get('HTTPS_PROXY') else None)
    other_name='qa_'+secrets.token_hex(4)
    other_signup=await other.post('/api/auth/sign-up/email',data={'username':other_name,'name':other_name,'email':other_name+'@example.test','password':secrets.token_urlsafe(30)},headers={'Origin':ORIGIN});assert other_signup.status==200
    unauthorized=await other.post('/api/link/approve',data={'user_code':issued['user_code']},headers={'Origin':ORIGIN});assert unauthorized.status!=200
    report['tests'].append('Another signed-in account cannot approve this account’s claimed code')
    await page.get_by_label('This is my device, and its displayed code matches.').focus()
    await page.keyboard.press('Space');await page.keyboard.press('Tab')
    assert await page.evaluate('document.activeElement.id')=='approve'
    await page.keyboard.press('Enter')
    report['tests'].append('Keyboard focus, possession checkbox and explicit approval via Enter')
    await page.get_by_text('Approved. Your companion will finish linking automatically. This does not start Fortnite.',exact=True).wait_for()
    await asyncio.sleep(5)
    tokens=await device.post('/api/device/token',data={'client_id':'hollowwake-uwp','device_code':issued['device_code'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code'});assert tokens.status==200, {'status':tokens.status,'error':(await tokens.json()).get('error')}
    token=(await tokens.json())['access_token']
    profile=await device.get('/api/device/profile',headers={'Authorization':'Bearer '+token});assert profile.status==200
    assert (await profile.json())['publicUsername']==name
    report['tests'].append('Real browser review/explicit approval, device polling redemption and profile mapping')
    await page.goto(ORIGIN+'/link?user_code='+issued['user_code'],wait_until='networkidle')
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('That code has already been processed. Request a new one on the device.',exact=True).wait_for()
    report['tests'].append('Redeemed public code has a distinct already-used browser error')
    await page.goto(ORIGIN+'/settings',wait_until='networkidle')
    await page.locator('.device-row').wait_for(state='visible')
    await page.reload(wait_until='networkidle');assert await page.locator('#public-name').inner_text()==name
    updated_name=name+'_new'
    await page.locator('#settings-name').fill(updated_name);await page.get_by_role('button',name='Save username',exact=True).click()
    await page.get_by_text('Public username updated for the companion test profile.',exact=True).wait_for()
    updated=await device.get('/api/device/profile',headers={'Authorization':'Bearer '+token});assert (await updated.json())['publicUsername']==updated_name
    await page.reload(wait_until='networkidle');assert await page.locator('#public-name').inner_text()==updated_name
    report['tests'].append('Saved username persists across reload and updates the linked companion profile')
    renew=await device.post('/api/device/renew',data={},headers={'Authorization':'Bearer '+token});assert renew.status==200
    report['tests'].append('Persisted device credential restores its profile and renews through the live service')
    await page.get_by_role('button',name='Revoke',exact=True).click()
    await page.get_by_text('Device revoked. Its session can no longer access your profile.',exact=True).wait_for()
    assert (await device.get('/api/device/profile',headers={'Authorization':'Bearer '+token})).status==401
    report['tests'].append('Browser session survives reload; account device list and revocation invalidate device token')
    await page.get_by_role('button',name='Sign out',exact=True).click()
    await page.locator('#auth-panel').wait_for(state='visible')
    await page.get_by_label('Email address',exact=True).first.fill(email);await page.get_by_label('Password',exact=True).fill(password)
    await page.get_by_role('button',name='Sign in',exact=False).last.click()
    await page.locator('#signed-in').wait_for(state='visible');report['tests'].append('Browser logout and existing-user sign-in')
    await page.goto(ORIGIN+'/recover',wait_until='networkidle')
    await page.get_by_text('Recovery email is not configured yet. Contact the project operator; no recovery message can be sent.',exact=True).wait_for()
    assert not await page.locator('#recovery-form').is_visible()
    report['tests'].append('Hosted recovery is explicitly unavailable; no false email-delivery claim')
    await page.goto(ORIGIN+'/link',wait_until='networkidle')
    await page.locator('#user-code').fill('AAAAAAAA');await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('That code is invalid. Check the eight characters on your device.',exact=True).wait_for()
    report['tests'].append('Invalid code displays the expected actionable browser error')
    await context.set_offline(True)
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('Connection lost. Check your network, then try again.',exact=True).wait_for()
    await context.set_offline(False)
    report['tests'].append('Browser reports connectivity loss and resumes requests after network restoration')
    for _ in range(9):
      await page.evaluate("async()=>{await fetch('/api/link/verify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({user_code:'AAAAAAAA'})})}")
    await page.get_by_role('button',name='Review device').click()
    await page.get_by_text('Too many attempts. Wait ten minutes before trying again.',exact=True).wait_for()
    report['tests'].append('Browser displays the rate-limit error after exhausting real API attempts')


    mobile=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=1)
    phone=await mobile.new_page();phone.on('pageerror',lambda e:report['page_errors'].append(str(e)))
    for path in ['/','/link','/recover','/reset','/settings']:
      await phone.goto(ORIGIN+path,wait_until='networkidle')
      widths=await phone.evaluate('({scroll:document.documentElement.scrollWidth,viewport:innerWidth})')
      assert widths['scroll']<=widths['viewport']+1,(path,widths)
    await phone.goto(ORIGIN,wait_until='networkidle');await phone.screenshot(path=str(OUT/'website-mobile.png'),full_page=True);report['screenshots'].append('website-mobile.png')
    report['tests'].append('390px mobile routes load without horizontal overflow')
    assert not report['page_errors'],report['page_errors']
    await other.dispose();await device.dispose();await mobile.close();await context.close();await browser.close()
  report['result']='PASS';(OUT/'browser-results.json').write_text(json.dumps(report,indent=2));print(json.dumps({'result':report['result'],'tests':report['tests'],'page_errors':report['page_errors']},indent=2))
if __name__=='__main__':
  try:asyncio.run(main())
  except Exception as e:
    report=globals().get('qa_report',{});report['result']='FAILED';report['failure']=type(e).__name__;OUT.joinpath('browser-partial.json').write_text(json.dumps(report,indent=2));raise
