"""Package project-only research. No game or reviewed third-party code is redistributed."""
from pathlib import Path
import zipfile, json, hashlib, shutil, base64, xml.etree.ElementTree as ET
root=Path('/workspace/hollowwake'); research=root/'research-0.3.1'
out=Path('/workspace/hollowwake-research-release-0.3.1');out.mkdir(exist_ok=True)
build=research/'diagnostic-final';appx=next(build.rglob('RuntimeDiagnostic_*.appx'))
expected=json.loads((build/'package-hashes.json').read_text(encoding='utf-8-sig'))['Hash']
assert hashlib.sha256(appx.read_bytes()).hexdigest().upper()==expected
with zipfile.ZipFile(appx) as z:
 assert 'AppxSignature.p7x' in z.namelist()
 ns={'b':'http://schemas.microsoft.com/appx/2010/blockmap'}
 blockmap=ET.fromstring(z.read('AppxBlockMap.xml'));checked=0
 for f in blockmap.findall('b:File',ns):
  data=z.read(f.attrib['Name'].replace('\\','/'));assert len(data)==int(f.attrib['Size'])
  for i,b in enumerate(f.findall('b:Block',ns)):
   assert base64.b64encode(hashlib.sha256(data[i*65536:(i+1)*65536]).digest()).decode()==b.attrib['Hash']
  checked+=1
deps=appx.parent/'Dependencies/x64/Microsoft.VCLibs.x64.14.00.appx'
with zipfile.ZipFile(out/'Hollowwake-Runtime-Diagnostic-x64.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f,n in [(appx,appx.name),(build/'HollowwakeDiagnostic.cer','HollowwakeDiagnostic.cer'),(deps,'Dependencies/x64/'+deps.name),(research/'docs/INSTALL-DIAGNOSTIC.md','INSTALL.md'),(build/'signature.log','signature.log'),(build/'diagnostic-test.json','windows-test.json'),(build/'diagnostic-windows.json','windows-diagnostic.json'),(build/'package-hashes.json','package-hashes.json')]:z.write(f,n)
for f in [appx,build/'HollowwakeDiagnostic.cer',deps]:shutil.copy2(f,out/f.name)
blocked={'rollback','node_modules','.git','.sites-runtime','.wrangler','bin','obj','AppPackages','build-work','quarantine','data','artifacts','__pycache__','dist','research-0.3.1'}
source={}
def collect(base,prefix,dirs=None):
 for f in base.rglob('*'):
  rel=f.relative_to(base)
  if not f.is_file() or set(rel.parts)&blocked:continue
  if dirs and rel.parts[0] not in dirs:continue
  if f.name in {'.dev.vars','assets.generated.mjs','site-request.json'}:continue
  if f.name.startswith('.env') and f.name!='.env.example':continue
  if f.suffix.lower() in {'.pfx','.key','.sqlite','.db','.exe','.dll','.pyc'}:continue
  if f.name.startswith('.') and len(rel.parts)==1 and f.name not in {'.env.example','.gitignore'}:continue
  if prefix=='control/' and f.name=='hosting.json':source[prefix+rel.as_posix()]=b'{"d1":null,"r2":null}\n'
  else:source[prefix+rel.as_posix()]=f.read_bytes()
collect(root,'',{'backend','web','uwp','docs','tools','tests','remote-build','branding','runtime-diagnostic','README.md','package.json','package-lock.json','.env.example','.gitignore'})
collect(Path('/workspace/sites/hollowwake'),'sites/')
collect(Path('/workspace/sites/hollowwake-control'),'control/')
# Only the project-owned artwork already used by the hosted release is redistributable.
site=Path('/workspace/sites/hollowwake')
for key in ['uwp/Hollowwake/Assets/Landmark.jpg','web/assets/landmark.jpg']:source[key]=(site/'web/landmark.jpg').read_bytes()
source['web/index.html']=(site/'web/index.html').read_bytes()
source['uwp/Hollowwake/MainPage.xaml']=source['uwp/Hollowwake/MainPage.xaml'].replace('Fortnite artwork © Epic Games. '.encode(),b'')
for f in (research/'docs').glob('*.md'):source['research-0.3.1/docs/'+f.name]=f.read_bytes()
for name in ['loader-preflight.py','scan-pak-index.py','live-auth-check.py','package-research.py']:source['research-0.3.1/'+name]=(research/name).read_bytes()
source['SOURCE-NOTES.md']=b'Original Hollowwake source, live Sites backend and admin source, companion, independent diagnostic, fixtures, protocol prototype and additive migrations. No Fortnite game files or actual client port is included. No upstream reference implementation, compiled candidate probe, private keys, credentials or database is included. Production adapter remains disabled; real-client interoperability and Xbox execution are unproven. See research-0.3.1/docs/RESULTS.md.\n'
with zipfile.ZipFile(out/'Hollowwake-Research-Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(source.items()):z.writestr('hollowwake/'+name,data)
with zipfile.ZipFile(out/'Hollowwake-Research-Report.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted((research/'docs').glob('*.md')):z.write(f,'docs/'+f.name)
 for f in sorted((research/'evidence').glob('*')):
  if f.suffix in {'.json','.log','.sha256','.stderr'} and not any(s in f.name for s in ['-tree.json','installed-cosmetics-private','diagnostic-source']):z.write(f,'evidence/'+f.name)
 for name in ['signature.log','diagnostic-test.json','diagnostic-windows.json']:z.write(build/name,'windows/'+name)
 z.writestr('STATIC-CHECKS.json',json.dumps({'diagnosticAppxBlockmapFilesChecked':checked,'windowsSignatureVerification':'passed','containsFortnite':False,'candidateFixtureExecution':False,'xboxTested':False},indent=2))
with zipfile.ZipFile(out/'Hollowwake-Original-Windows-Fixtures.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted((research/'fixtures-delivered').glob('*')):
  if f.suffix in {'.dll','.log','.json'}:z.write(f,f.name)
 for f in (root/'runtime-diagnostic/fixtures').glob('*.cpp'):z.write(f,'source/'+f.name)
 z.writestr('README.txt','Original Windows DLL fixtures and scoped test logs. Not an Xbox package. Probe source needs the pinned private routine extracted by Test-OriginalFixtures.ps1; generated upstream code/compiled probe are not redistributed. Windows OS loader success is not experimental-loader success.\n')
result={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in out.iterdir() if f.is_file() and f.name!='ARTIFACTS.json'}
(out/'ARTIFACTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
