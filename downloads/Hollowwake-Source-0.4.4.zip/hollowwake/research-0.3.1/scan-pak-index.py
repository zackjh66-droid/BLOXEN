"""Stream immutable ZIP members as data. Read unencrypted PAK indexes only; no decryption/asset extraction."""
from pathlib import Path
import zipfile,struct,hashlib,json,re,zlib
root=Path(__file__).parent;z=zipfile.ZipFile('/workspace/fortnite-alternative-analysis/6.21.zip');results=[];cosmetics=[]
limit=96*1024*1024
for member in z.infolist():
 if '/FortniteGame/Content/Paks/' not in member.filename or not member.filename.endswith('.pak'):continue
 print('Streaming bounded tail:',member.filename,flush=True)
 tail=bytearray();total=0
 with z.open(member) as stream:
  while True:
   b=stream.read(4*1024*1024)
   if not b:break
   total+=len(b);tail.extend(b)
   if len(tail)>limit:del tail[:len(tail)-limit]
 r={'pak':member.filename,'bytes':total,'tailBytes':len(tail),'indexRead':False}
 pos=tail.rfind(struct.pack('<I',0x5a6f12e1))
 if pos>=0 and pos+44<=len(tail):
  version,offset,size=struct.unpack_from('<IQQ',tail,pos+4);expected=bytes(tail[pos+24:pos+44]);r.update(version=version,indexOffset=offset,indexSize=size)
  start=offset-(total-len(tail))
  if 0<=start and size<=limit and start+size<=len(tail):
   index=bytes(tail[start:start+size]);r['indexSha1Valid']=hashlib.sha1(index).digest()==expected
   # Unreal FString and count sanity; encrypted/random indexes are never interpreted as asset names.
   if r['indexSha1Valid'] and len(index)>8:
    n=struct.unpack_from('<i',index,0)[0]
    if 0<n<4096 and n+8<=len(index) and index[4+n-1]==0:
     mount=index[4:4+n-1].decode('utf-8',errors='replace');count=struct.unpack_from('<I',index,4+n)[0];r.update(indexRead=True,mount=mount,indexEntries=count)
     # Index strings include per-entry metadata; recognize bounded length-prefixed UE strings.
     for match in re.finditer(rb'(?:Athena/Items/Cosmetics/|Athena/Items/)([A-Za-z0-9_./-]{1,220})\.uasset\x00',index,re.I):
      path=match.group(0)[:-1].decode();base=path.rsplit('/',1)[-1][:-7]
      category=next((c for prefix,c in [('CID_','AthenaCharacter'),('BID_','AthenaBackpack'),('Pickaxe_','AthenaPickaxe'),('Glider_','AthenaGlider'),('EID_','AthenaDance'),('Trails_','AthenaSkyDiveContrail'),('LSID_','AthenaLoadingScreen'),('Wrap_','AthenaItemWrap')] if base.lower().startswith(prefix.lower())),None)
      if category:cosmetics.append({'templateId':category+':'+base,'path':path,'pak':member.filename,'indexSha256':hashlib.sha256(index).hexdigest(),'evidence':'indexed asset path exists; asset object/type/game usability not decoded'})
    else:r['reason']='Index hash valid but mount string unreadable; possibly encrypted or unsupported index'
  else:r['reason']='Index outside bounded retained tail'
 else:r['reason']='Supported PAK footer not found'
 results.append(r);print(json.dumps(r),flush=True)
root.joinpath('evidence/pak-index-report.json').write_text(json.dumps(results,indent=2));root.joinpath('evidence/installed-cosmetics-private.json').write_text(json.dumps({'build':'6.21-CL-4526925','archiveSha256':'bae66d8b0ff7e8ebea4361e835579c180bc2a2e618d04808f72b40214ababee5','cosmetics':list({x['templateId'].lower():x for x in cosmetics}.values())},indent=2));print('Unique indexed cosmetics:',len(set(x['templateId'].lower() for x in cosmetics)),flush=True)
