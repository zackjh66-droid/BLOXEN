# Untrusted reference audit

## LawinServerV2

Repository `Lawin0129/LawinServerV2`, pinned commit `2205696e4e1f828b4f6457233901373c07f3e180` (main). LICENSE contains GPLv3; package metadata says GPL-3.0. Original Hollowwake adapter code is newly authored protocol research, not copied route bodies/default profiles. This report links behavior/source positions. The GPL source/default game data are retained privately for inspection, not bundled into proprietary-looking Hollowwake source. Any future code reuse must comply with its license; GitHub availability is not permission to relicense it.

Fetched 68 bounded source/config/document files as inert data. Did not execute index.js, start/install batch files, Discord bot, XMPP server or package lifecycle scripts. Did not install its dependencies. `npm audit --ignore-scripts` checked the lockfile only: 22 advisories (4 critical, 12 high, 3 moderate, 3 low) at inspection time. Findings include jsonwebtoken/jws, express/body-parser/path-to-regexp, mongoose, ws, form-data and archive/install-tool transitive packages. Exact advisories/versions are in evidence/lawin-npm-audit.json. Audit results do not prove malicious intent, but direct deployment is inappropriate.

Runtime uses Express, MongoDB/Mongoose, bcrypt, JWT-related packages, ws/XML helpers and Discord integration. Startup reads/writes tokenManager/tokens.json, builds global token allowlists and can starts its Discord service. Auth verification decodes JWTs and checks global token membership/expiry/user bans; do not inaccurately infer that any unsigned/forged JWT is accepted just because jwt.decode is present. It also persists access/refresh tokens in plaintext JSON, contains a hardcoded placeholder refresh-token response in a legacy OAuth branch, and an invalid-refresh error can echo the submitted secret. These patterns are not adopted. Some routes such as catalog/cloudstorage/public identity have no authentication middleware; dedicated_server profile access is unauthenticated in the reviewed declaration. Hollowwake retains own-account authorization and rejects unsupported access.

The MCP file mixes legacy favorite_* equipment fields with modern cosmetic loadout/locker structures. A generic QueryProfile/ClientQuestLogin/BulkEquip handler can return success without executing the game's desired side effects. Version branches include >=12.20 revision handling. Thus its broad-version claims are not evidence of exact 6.21 completeness. Default profiles and a universal cosmetic list are not trusted Season6 asset manifests. Reference XMPP runs over WebSocket; it is not assumed to require a raw TCP-only host, nor assumed sufficient for this build without transcripts.

## Microsoft ATG

Repository `microsoft/Xbox-ATG-Samples`, commit `ff629a6e4876e38fe8761ead116a0e53f634ca67`, MIT. Reviewed the **UWPSamples** SimpleTriangleUWP (graphics/view), GamepadUWP, SimplePLM_UWP (lifecycle) and SimplePlaySoundUWP references. XDK and PC sample paths are not treated as retail Xbox UWP implementations. The original diagnostic uses public Windows SDK/CoreWindow/D3D11, Windows.Gaming.Input and XAudio2 APIs. It does not include proprietary Xbox SDK code, Xbox Live services or copied sample media. The official examples are engineering references, not proof that our particular APPX ran on a console.

## Experimental Win32 runner

`http-hadi/xbox-win32-runner`, commit `84bb0f71a698ea5d2733d1e02c1caa96a33b1c01`, unchanged since prior inspection. No standard license grant was established: its README's “License” section says educational/open-source but does not supply a conventional reuse license. Its source is not republished in our delivery. Reviewed source remains private; a reproducible test fetches exact pinned/hash-verified bytes and compiles **only the short ProcessTls routine** into a bounded data probe, excluding that generated code from artifacts. No full runner, host agent or game executable is run. This scoped test makes no claim that the full loader was exercised or is safe to run arbitrary inputs.

See RUNTIME-MATRIX.md for exact gaps and fixture scope. Placeholder exports/lexical registration counts are not functional compatibility. A full loader execution test against original fixtures remains a later milestone requiring a reviewed/licensed complete candidate and an appropriate environment; the scoped TLS negative test is deliberately narrower.

## Neo / Echo identities

- `NeoniteDev/NeoniteV2`, pinned commit `8a60e5c5ca7cf0d37cd36450f19f2e5c02439536`: JavaScript lobby backend/emulator; GitHub license classification NOASSERTION/custom Neo terms. This is an identifiable project, but neither its “Neo” association nor its backend establishes a UWP binary runtime. No code/dependencies executed or adopted.
- `rifter712/Project-Echo`: pinned repository identity/tree in evidence/neo-echo.json. README claims a loader and recommends disabling antivirus; no such instruction was followed. Promotional text and a downloadable “Build” are not source-reviewed graphics/TLS/Xbox execution evidence. No release/installer run.
- `troon-dev/Code-LauncherNeo`: pinned identity/tree in evidence. README explicitly describes static analysis/reverse engineering of a Windows installer, not official/private server source. It mentions desktop .NET/WinUI/WebView2/Tauri services. This does not establish official Neo authorship or Xbox client compatibility; no reverse-engineered code adopted.

Other similarly named results were not conflated with these projects. No independently established public Neo/Echo source or reproducible evidence proving Fortnite6.21 in Xbox Dev Mode was identified in this search. This is a bounded finding, not a claim that no private implementation exists.
