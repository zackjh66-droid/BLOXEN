# Hollowwake0.3 research continuation — 2026-10-15

This iteration preserves the released Hollowwake0.3 companion (prior package installation/linking was user-reported on Xbox), public website, own-account data/authentication secret, private admin boundary, original Fortnite archive and previous release/rollback packages. No companion features or actual Fortnite screenshots/mock lobby were added. The separate diagnostic is clearly original test content.

## Credential remediation

The exposed credential was a **Sites identity-less private-site service bypass**, not the project authentication/HMAC secret. Native Sites token rotation completed; the old token is rejected with401 on UI and API, including a later recheck. Replacement reaches static UI but receives403 for administration without the trusted signed-in owner identity. No old/replacement value was printed or written to deliverables. It was never in the runtime environment; no consumer deployment needed a replacement value. Platform rotation took effect at dispatch, preserving accounts and server credentials. Control remains owner-private; random hostname is not authorization.

Available bounded Worker logs returned23 events (15 HTTP200,8 HTTP403) over the requested180-minute interval. These include application requests, not a complete platform token-use/authentication audit; gate-denied requests may be absent. They cannot prove absence of misuse. No unrelated service was probed with the token. Native secret configuration metadata showed only ADMIN_RPC_SECRET, BACKEND_ORIGIN and PUBLIC_ORIGIN; values were not exposed. Owner identity remains mandatory.

## Backend/protocol work

Pinned LawinServerV2 source/license/dependencies were inspected as inert data; no server/scripts/bot/dependencies were executed/installed. It is GPL3, with22 lockfile advisories at inspection time (4critical,12high,3moderate,3low). No route bodies, default game profiles, asset keychain or token handling were copied into Hollowwake. See REFERENCE-AUDIT.md and PROTOCOL-MATRIX.md for85 reference routes, exact-client static evidence, formats/auth/presence mapping and version-specific gaps.

An original adapter prototype now implements delegated one-time exchange, separate short-lived capability tokens, own-account mapping, minimal athena/common profiles, legacy equipment/revision persistence and catalog derivation from the existing authoritative admin data. Project session/refresh tokens never reach Lawin/Epic. Admin shop edits/grants/revocations/suspensions are exercised through the same real data paths in disposable D1 tests. Unknown assets/styles/operations fail closed. The prototype is deployed **disabled**, not advertised as a working6.21 login/lobby service. No native client handoff, Basic-client identity compatibility, client refresh, XMPP/presence, cloudstorage/config, complete quests/defaults or purchase service is proven.

The existing account+IP linking throttle was supplemented with an account-only throttle. A changing-IP regression now verifies it cannot evade the account limit; old limits remain. The initial live regression did not reach the expected throttling display; another overlapping-window attempt was blocked before approval. Those failures are retained. After the rate-limit window and the account-wide fix, all14 live desktop/mobile browser scenarios pass with zero page errors. Earlier failures are retained.

17 Worker/D1 test groups and11 retained Node integration tests pass. Additive migration0002 introduces client adapter tables without deleting/replacing existing accounts. Main Site is now saved/deployed version8 with the adapter flag absent/off and existing DB/auth secret. The website source/artwork is unchanged from0.3. No paid/larger runner was started.

## Asset investigation

Unchanged12,528,679,454-byte6.21.zip SHA256 remains bae66d8b0ff7e8ebea4361e835579c180bc2a2e618d04808f72b40214ababee5. Six game PAK v7 indexes were streamed with bounded retained tails, never extracted/executed. None passed plaintext index validation; a separate footer read confirms encrypted-index flag1 in the smallest split. No decryption attempted or keys adopted. Zero actual cosmetics validated; production validation registry stays empty. A full project locker grant therefore cannot be represented as a valid Fortnite locker.

## Runtime milestones

The original C++ UWP diagnostic is development-signed, x64, installs side-by-side with the companion and uses real CoreWindow/D3D11 presentation. Hosted Windows run38794182076 passes build, signature, install/activation, advancing Present0→600 and keyboard events. Audio init is0x80070490 (no endpoint); no audible output, physical controller, suspend/resume or Xbox success claimed. A separate initial/fatal log and device-family flag help console testing. Follow INSTALL-DIAGNOSTIC.md and return the app's LocalState/diagnostic.json.

Original fixture tests now pass normal/delayed imports, C++ exception handling, initialized static TLS and per-thread isolation under the **Windows OS loader**. A narrow reviewed candidate routine is tested with bounded non-executable metadata buffers; it is not a full-loader or game execution. Its index allocator assigns index0 already occupied by the original host's TLS; it can also report success with no initialization when callback pointer is null. The exact main client's28-byte template and non-null empty callback list are accounted for by a separate original-data variant. The allocator/storage bug is **not fixed into a working runtime**: preflight rejects it. Full loader-fixture execution, CoreWindow bridging and the full dependency surface remain unproven.

The exact client main SHA256 is9d18fb5c5c43ddc21251d5ce9e026ca01f90d42921dd741973bd5536e8949478. The reviewed runner is unchanged at84bb0f71a698ea5d2733d1e02c1caa96a33b1c01. Its full reuse license is not established; source/generated candidate code and compiled probe are excluded from delivery. Original fixture DLLs, source, build scripts and observed logs are supplied. Neo/Echo candidates were identified and distinguished from promotional/name matches; none established a6.21 Xbox UWP runtime.

## Unfinished main target

No original Fortnite executable/launcher/DLL was executed in the hosted environment. There is no credential-free, network-isolated disposable Windows game VM or attached Xbox; normal CI is not such a sandbox. No original loading screen/lobby/character/locker/controller integration is delivered. A working authorized source port or a complete, verified runtime with TLS/thread/graphics/dependency support, followed by validated client protocol integration and actual Xbox execution, is still required. This is an unresolved engineering milestone, not an APPX signing issue.


Final fixture run38796343383 also passes an exact-client-shaped28-byte TLS/non-null-empty-callback-list variant and reproduces the index0 collision. This is scoped data probing, not a full candidate load. CLI GitHub authentication expired near delivery; native connected GitHub tools remain authorized, so artifact retrieval/publication continues through that connection.
