# Install the separate Hollowwake Runtime Diagnostic

This is original UWP graphics/input/audio/lifecycle test code. **No Fortnite client, lobby or Win32 loader is included.** It uses a different package identity and does not replace the working Hollowwake0.3 companion, account data or saved sign-in. It has no network capability or account credentials.

1. Download and extract Hollowwake-Runtime-Diagnostic-x64.zip. No compilation or PC tool installation is required.
2. In your Xbox Dev Home, open the console's displayed Device Portal address and use its Apps/Add/Deploy interface.
3. Select RuntimeDiagnostic_0.1.0.0_x64.appx and the supplied Dependencies/x64/Microsoft.VCLibs.x64.14.00.appx. Use the matching HollowwakeDiagnostic.cer if your deployment path asks for the certificate. Never disable signature validation. Private key is not supplied.
4. Launch **Hollowwake Runtime Diagnostic** alongside your companion. The default is a dark background, original colored triangle and text counters. An increasing successful Present count demonstrates this diagnostic's presentation only.
5. Left stick/D-pad moves the triangle; A plays a short quiet440Hz tone; B changes the background and should stay inside this app; Menu pauses/resumes animation and saves the diagnostic log. B may also generate a handled navigation event; watch the counter and window behavior. Windows keyboard equivalents are arrow keys, Space, C and P.
6. Let it run for at least10seconds and press Menu to save. For lifecycle testing, return to Dev Home and resume the same running app, then save again; a newly terminated/restarted app resets its per-process counters. Note the behavior rather than assuming a resume occurred.
7. In Device Portal's app file explorer, select the diagnostic package and download **LocalState/diagnostic.json**. If your console/portal does not expose this view, send a screenshot of the diagnostic counters and the approximate steps instead. The log contains only diagnostic counters/HRESULTs/device-family flag, no credentials.

Please report Xbox model/OS, App or Game classification, screenshot and JSON; whether the triangle moves with the controller; whether A is audible; whether B stays in-app; and whether suspend/resume increments on resuming the same process. Do not send console passwords/tokens. Xbox results remain user-reported unless independently observed.

Optional resource classification: Dev Home → highlight the diagnostic → controller **View → View details → App type → Game**, confirm with A, B to return, relaunch. This document-verified procedure changes resource allocation; it is not a verified prerequisite for this simple diagnostic and does not make desktop Fortnite compatible.

Hosted Windows build38794182076 passed native install/activation, advancing D3D11 Present counts and keyboard input; audio initialization returned0x80070490 because no audio endpoint is available there. Hardware controller, audible output, suspension/resume and Xbox operation were not verified in that VM. The current package SHA256 is supplied in ARTIFACTS.json and its own package manifest.
