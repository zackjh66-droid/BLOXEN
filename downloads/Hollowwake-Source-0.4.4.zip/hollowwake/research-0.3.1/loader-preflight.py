"""Data-only fail-closed check for the reviewed experimental runner; never loads an image."""
import argparse,struct,hashlib,json
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('image',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args()
with a.image.open('rb') as f:
 size=f.seek(0,2);f.seek(0);dos=f.read(64);assert dos[:2]==b'MZ';peoff=struct.unpack_from('<I',dos,60)[0];assert 0<peoff<size-24;f.seek(peoff);head=f.read(24);assert head[:4]==b'PE\0\0';machine,nsections,_,_,_,optsize,_=struct.unpack_from('<HHIIIHH',head,4);assert machine==0x8664 and nsections<128 and 112<=optsize<=4096;opt=f.read(optsize);assert struct.unpack_from('<H',opt)[0]==0x20b;imagebase=struct.unpack_from('<Q',opt,24)[0];sections=f.read(nsections*40)
 def read_rva(rva,count):
  for i in range(nsections):
   vsize,va,rawsize,rawptr=struct.unpack_from('<IIII',sections,i*40+8)
   if va<=rva and rva+count<=va+rawsize:
    off=rawptr+rva-va;assert 0<=off and off+count<=size;f.seek(off);return f.read(count)
  raise ValueError('RVA does not fit bounded raw section')
 rva,dsize=struct.unpack_from('<II',opt,112+9*8);tlsbytes=zero=callbacks=0
 if rva:
  assert dsize>=40;start,end,index,cb,zero,_=struct.unpack('<QQQQII',read_rva(rva,40));assert end>=start;tlsbytes=end-start
  if cb:
   for i in range(32):
    pointer=struct.unpack('<Q',read_rva(cb-imagebase+i*8,8))[0]
    if not pointer:break
    callbacks+=1
   else:raise ValueError('Unbounded callback list')
 f.seek(0);h=hashlib.file_digest(f,'sha256').hexdigest()
blockers=['Reviewed runner has no established CoreWindow presentation bridge']
if tlsbytes or zero:blockers.append('Static TLS requires per-thread template/zero-fill and noncolliding index/lifecycle; reviewed routine does not provide it')
r={'sha256':h,'machine':'x64','staticTLSBytes':tlsbytes,'TLSZeroFillBytes':zero,'TLSCallbackCount':callbacks,'candidateCommit':'84bb0f71a698ea5d2733d1e02c1caa96a33b1c01','canAttemptExecutionWithThisCandidate':False,'blockers':blockers,'executionPerformed':False}
if a.output:a.output.write_text(json.dumps(r,indent=2))
print(json.dumps(r,indent=2))
