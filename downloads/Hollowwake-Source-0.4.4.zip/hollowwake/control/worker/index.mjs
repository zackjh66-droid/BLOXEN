import {createHmac,randomUUID} from 'node:crypto';
import assets from './assets.generated.mjs';
const security={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Robots-Tag':'noindex, nofollow, noarchive','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'"};
export default {async fetch(request,env){
 const url=new URL(request.url),reply=(v,s=200)=>Response.json(v,{status:s,headers:security});
 if(url.origin!==env.PUBLIC_ORIGIN)return reply({error:'Invalid host'},400);
 // This app MUST remain owner-private in Sites. Dispatch authenticates the owner before these routes.
 // Service bypass (held only by authorized operators) shares that private boundary, without visitor identity.
 if(request.method==='GET'){
  const file=url.pathname==='/'?'index.html':url.pathname.slice(1);
  if(file==='robots.txt')return new Response('User-agent: *\nDisallow: /',{headers:{...security,'Content-Type':'text/plain'}});
  if(!Object.hasOwn(assets,file))return reply({error:'Not found'},404);
  const type={'index.html':'text/html','app.js':'text/javascript','style.css':'text/css','logo.svg':'image/svg+xml','favicon.png':'image/png'}[file];
  return new Response(assets[file],{headers:{...security,'Content-Type':type}});
 }
 if(request.method!=='POST'||url.pathname!=='/api/control')return reply({error:'Not found'},404);
 if(request.headers.get('Origin')!==env.PUBLIC_ORIGIN||request.headers.get('Content-Type')!=='application/json')return reply({error:'Invalid browser origin'},403);
 if(!env.ADMIN_RPC_SECRET||!env.BACKEND_ORIGIN?.startsWith('https://'))return reply({error:'Administration service not configured'},503);
 const raw=await request.text();if(Buffer.byteLength(raw)>32768)return reply({error:'Request too large'},413);
 const actor=request.headers.get('oai-authenticated-user-id');
 if(!actor)return reply({error:'Sign in with the Site owner account to administer Hollowwake. Service bypass cannot authorize administration.'},403);
 const timestamp=String(Date.now()),nonce=randomUUID();
 const signature=createHmac('sha256',env.ADMIN_RPC_SECRET).update(`POST\n/api/control/rpc\n${timestamp}\n${nonce}\n${actor}\n${raw}`).digest('hex');
 try{
  const response=await fetch(env.BACKEND_ORIGIN+'/api/control/rpc',{method:'POST',redirect:'manual',headers:{'Content-Type':'application/json','X-HW-Time':timestamp,'X-HW-Nonce':nonce,'X-HW-Actor':actor,'X-HW-Signature':signature},body:raw});
  if(response.status>=300&&response.status<400)return reply({error:'Unexpected backend redirect; check deployment configuration.'},502);
  return new Response(await response.text(),{status:response.status,headers:{...security,'Content-Type':'application/json'}});
 }catch(e){console.error('control_subrequest_failure',e.name,String(e.message).slice(0,200));return reply({error:'Backend unreachable; no change confirmed. Refresh before retrying.'},502);}
}};
