import {build} from 'esbuild';import {readFile,writeFile,mkdir,cp,rm} from 'node:fs/promises';
const assets={};for(const f of ['index.html','app.js','style.css','logo.svg'])assets[f]=await readFile('web/'+f,'utf8');assets['favicon.png']=Array.from(await readFile('web/favicon.png'));
await writeFile('worker/assets.generated.mjs','const assets='+JSON.stringify(assets)+';assets["favicon.png"]=new Uint8Array(assets["favicon.png"]);export default assets;');
await rm('dist',{recursive:true,force:true});await mkdir('dist/server',{recursive:true});await mkdir('dist/.openai',{recursive:true});
await build({entryPoints:['worker/index.mjs'],outfile:'dist/server/index.js',bundle:true,format:'esm',platform:'node',target:'es2022',minify:true});
await cp('.openai/hosting.json','dist/.openai/hosting.json');await writeFile('dist/server/wrangler.json',JSON.stringify({name:'hollowwake-control',main:'index.js',compatibility_date:'2026-05-15',compatibility_flags:['nodejs_compat','global_fetch_strictly_public']},null,2));
