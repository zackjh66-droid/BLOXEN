import {test} from 'node:test';import assert from 'node:assert/strict';import {randomBytes,createHmac} from 'node:crypto';import worker from '../worker/index.mjs';
const env={PUBLIC_ORIGIN:'https://control.test',BACKEND_ORIGIN:'https://backend.test',ADMIN_RPC_SECRET:randomBytes(48).toString('hex')};
test('private proxy rejects CSRF, signs server-side RPC and refuses redirects',async()=>{
 const original=globalThis.fetch;let calls=0;
 globalThis.fetch=async(url,init)=>{calls++;assert.equal(url,env.BACKEND_ORIGIN+'/api/control/rpc');assert.equal(init.redirect,'manual');assert.equal(init.headers['X-HW-Actor'],'test-owner');const signature=createHmac('sha256',env.ADMIN_RPC_SECRET).update(`POST\n/api/control/rpc\n${init.headers['X-HW-Time']}\n${init.headers['X-HW-Nonce']}\n${init.headers['X-HW-Actor']}\n${init.body}`).digest('hex');assert.equal(signature,init.headers['X-HW-Signature']);return Response.json({ok:true});};
 try{
  let r=await worker.fetch(new Request(env.PUBLIC_ORIGIN+'/api/control',{method:'POST',headers:{Origin:'https://attacker.test','Content-Type':'application/json'},body:'{}'}),env);assert.equal(r.status,403);assert.equal(calls,0);
  r=await worker.fetch(new Request(env.PUBLIC_ORIGIN+'/api/control',{method:'POST',headers:{Origin:env.PUBLIC_ORIGIN,'oai-authenticated-user-id':'test-owner','Content-Type':'application/json'},body:'{"action":"overview"}'}),env);assert.equal(r.status,200);assert.deepEqual(await r.json(),{ok:true});assert.equal(calls,1);
  r=await worker.fetch(new Request(env.PUBLIC_ORIGIN+'/api/control',{method:'POST',headers:{Origin:env.PUBLIC_ORIGIN,'Content-Type':'application/json'},body:'{}'}),env);assert.equal(r.status,403);
  globalThis.fetch=async()=>new Response(null,{status:302,headers:{Location:'https://attacker.test'}});
  r=await worker.fetch(new Request(env.PUBLIC_ORIGIN+'/api/control',{method:'POST',headers:{Origin:env.PUBLIC_ORIGIN,'oai-authenticated-user-id':'test-owner','Content-Type':'application/json'},body:'{}'}),env);assert.equal(r.status,502);
  for(const file of ['/app.js','/index.html']){const r=await worker.fetch(new Request(env.PUBLIC_ORIGIN+file),env),body=await r.text();assert.ok(!body.includes(env.ADMIN_RPC_SECRET));assert.equal(r.headers.get('X-Robots-Tag'),'noindex, nofollow, noarchive');}
 }finally{globalThis.fetch=original;}
});
