# Hollowwake Control

Owner-private administration Site. Keep this Site owner-only: every authorized viewer is an administrator. The hostname is not a credential. Browser sign-in is handled by Sites. Its server uses signed, replay-protected RPC to the existing persistent Hollowwake backend; no service secret is sent to the browser. No real Fortnite runtime is integrated. See the source download's docs/ADMIN.md for exact capabilities and limits.

`npm ci`, `npm run build`; deploy with Sites. Runtime `PUBLIC_ORIGIN`, `BACKEND_ORIGIN`, secret `ADMIN_RPC_SECRET` (same random key on backend). No database binding is needed here; the existing backend owns all durable data. Worker metadata must include `global_fetch_strictly_public` for cross-Site requests. Never add a public audience or client-side admin key.
