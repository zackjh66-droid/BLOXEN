# Hollowwake Sites deployment

Preserves the existing Hollowwake website and Better Auth 1.7.10 account/device authorization flow. This Worker uses the same `backend/core.mjs` and `auth-options.mjs` as the retained Node server; the D1 adapter makes its SQL operations asynchronous. Real persistent D1 tables are provisioned by Sites and migrated before the Worker is uploaded. No user records or secrets are shipped with the source.

`npm ci`, `npm run db:generate` for a new schema change, `npm run build`, `npm test`. The existing initial migration is immutable after publication. The build embeds the frontend into the Worker and copies schema migrations to `dist/.openai/drizzle`. The source hosting manifest declares `DB` and no R2 bucket.

Runtime secrets: `BETTER_AUTH_SECRET` (random, at least 32 characters), optional `MAIL_API_KEY` and `MAIL_FROM` for an authorized Resend account. `PUBLIC_ORIGIN` must be the actual HTTPS Sites origin. No mail account is connected: recovery and verification explicitly return 503, addresses remain unverified, and users can register/sign in with project passwords. Do not represent an unverified address as proof of ownership. The original Node/SMTP recovery flow remains preserved separately.

Sites' public audience allows the Xbox to reach the first-party device API. Hollowwake account authorization protects profile/device records. The library uses its maintained scrypt implementation; the Worker bundle selects its portable implementation with identical parameters. Do not retain a Better Auth instance across Worker request contexts.

Private Epic assets were preserved in the original local project. This hosted variant uses original geometric Hollowwake art; no game files are redistributed. This site and the companion do not contain a functioning Fortnite client or lobby.
