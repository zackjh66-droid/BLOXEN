"""Register only a guarded workflow on main; probe dispatch with ALL jobs disabled.
No hosted runner is requested. Existing README/source stay unchanged.
"""
from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parents[1];out=p/'evidence/continuation';repo='zackjh66-droid/Use-if-needed'
def api(endpoint,payload=None,method=None):
 args=['gh','api',endpoint]
 if payload is not None:args+=['--method',method or 'POST','--input','-']
 r=subprocess.run(args,input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True)
 try:data=json.loads(r.stdout) if r.stdout else {}
 except:data={}
 if r.returncode:raise RuntimeError(json.dumps({'endpoint':endpoint,'response':data,'error':r.stderr[:400]}))
 return data
try:
 head=api('repos/'+repo+'/git/ref/heads/main')['object']['sha'];commit=api('repos/'+repo+'/git/commits/'+head)
 tree=api('repos/'+repo+'/git/trees',{'base_tree':commit['tree']['sha'],'tree':[{'path':'.github/workflows/hollowwake-companion.yml','mode':'100644','type':'blob','content':(p/'remote-build/.github/workflows/hollowwake-companion.yml').read_text()}]})
 commit=api('repos/'+repo+'/git/commits',{'message':'Register guarded Hollowwake companion workflow; no automatic runner triggers','tree':tree['sha'],'parents':[head]})
 api('repos/'+repo+'/git/refs/heads/main',{'sha':commit['sha'],'force':False},'PATCH')
 outcome={'registered_main_commit':commit['sha'],'preserved_existing_files':True,'only_main_addition':'.github/workflows/hollowwake-companion.yml','run_build':False,'free_minutes_confirmed':False}
 try:
  api('repos/'+repo+'/actions/workflows/hollowwake-companion.yml/dispatches',{'ref':'hollowwake/companion-preflight','inputs':{'run_build':False,'free_minutes_confirmed':False,'backend_origin':''}})
  outcome['dispatch']='accepted, all jobs disabled'
 except Exception as e:outcome['dispatch_error']=str(e)
except Exception as e:outcome={'error':str(e),'runner_requested':False}
(out/'private-ci-registration.json').write_text(json.dumps(outcome,indent=2));print(json.dumps(outcome,indent=2))
