#include <windows.h>
#include "../Native/DataFiles.h"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
static void Check(bool v,const char* reason){if(!v)throw std::runtime_error(reason);}
template<class T>T Api(const char* name){auto pointer=ResolveDataFileImport("kernel32.dll",name);if(!pointer)throw std::runtime_error(name);return reinterpret_cast<T>(pointer);}
#define API(n) Api<decltype(&n)>(#n)
int wmain(int count,wchar_t** args){try{
 Check(count==2,"Owned scratch directory required");auto root=std::filesystem::absolute(args[1]);auto package=root/L"Package";auto data=root/L"LocalState/GameClean";auto relative=std::filesystem::path(L"6.21/FortniteGame/Content/Paks");std::filesystem::create_directories(data/relative);std::filesystem::create_directories(package/L"6.21/FortniteGame/Binaries/Win64");std::ofstream(data/relative/L"owned.pak",std::ios::binary)<<"owned-data-fixture";std::ofstream(package/L"OwnedCode.dll",std::ios::binary)<<"owned-code-header-fixture";
 Check(ConfigureDataFiles(package.c_str(),data.c_str()),"Data namespace configuration failed");Check(RegisterCodeFileAlias(L"6.21/Engine/OwnedCode.dll",L"OwnedCode.dll"),"Installed code alias registration failed");
 auto logical=package/relative/L"owned.pak";auto handle=API(CreateFileW)(logical.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);Check(handle!=INVALID_HANDLE_VALUE,"Installed-path data request did not map to LocalState");char bytes[64]={};DWORD read=0;Check(ReadFile(handle,bytes,64,&read,nullptr)&&std::string(bytes,read)=="owned-data-fixture","Actual file read returned wrong bytes");CloseHandle(handle);
 WIN32_FIND_DATAW found={};auto pattern=package/relative/L"*.pak";auto search=API(FindFirstFileExW)(pattern.c_str(),FindExInfoBasic,&found,FindExSearchNameMatch,nullptr,0);Check(search!=INVALID_HANDLE_VALUE&&!wcscmp(found.cFileName,L"owned.pak"),"Actual data enumeration failed");FindClose(search);
 auto code=package/L"6.21/Engine/OwnedCode.dll";handle=API(CreateFileW)(code.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,0,nullptr);Check(handle!=INVALID_HANDLE_VALUE,"Installed native code metadata alias failed");CloseHandle(handle);Check(API(CreateFileW)(code.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,0,nullptr)==INVALID_HANDLE_VALUE&&GetLastError()==ERROR_ACCESS_DENIED,"Installed executable write was admitted");
 auto unregistered=data/relative/L"unknown.dll";Check(API(CreateFileW)(unregistered.c_str(),GENERIC_READ,0,nullptr,OPEN_EXISTING,0,nullptr)==INVALID_HANDLE_VALUE&&GetLastError()==ERROR_ACCESS_DENIED,"LocalState executable read/load source admitted");
 auto outside=package/L"6.21/../../outside.txt";Check(API(CreateFileW)(outside.c_str(),GENERIC_READ,0,nullptr,OPEN_EXISTING,0,nullptr)==INVALID_HANDLE_VALUE&&GetLastError()==ERROR_ACCESS_DENIED,"Traversal escaped game data namespace");
 Check(API(CreateFileW)(logical.c_str(),GENERIC_WRITE,0,nullptr,OPEN_EXISTING,0,nullptr)==INVALID_HANDLE_VALUE&&GetLastError()==ERROR_ACCESS_DENIED,"Verified content was writable by guest code");auto savedRelative=std::filesystem::path(L"6.21/FortniteGame/Saved");std::filesystem::create_directories(data/savedRelative);auto created=package/savedRelative/L"settings.ini";handle=API(CreateFileW)(created.c_str(),GENERIC_WRITE,0,nullptr,CREATE_ALWAYS,0,nullptr);Check(handle!=INVALID_HANDLE_VALUE,"Own data write failed");DWORD wrote=0;Check(WriteFile(handle,"saved",5,&wrote,nullptr)&&wrote==5,"Own data write bytes failed");CloseHandle(handle);std::ifstream saved(data/savedRelative/L"settings.ini");std::string text;saved>>text;Check(text=="saved","Mapped write did not persist physically");
 std::cout<<"PASS production data route: actual LocalState read/write/find, registered installed-code metadata, executable write rejection and traversal rejection. No game/Xbox execution.\n";return 0;
 }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<"\n";return 1;}}
