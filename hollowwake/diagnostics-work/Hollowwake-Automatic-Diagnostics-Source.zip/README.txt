Hollowwake automatic startup diagnostics source changes.
Native base: zackjh66-droid/BLOXEN commit 71bbf25216056a3268123a687c81338a4834b65e, hollowwake/native-client-0.5.0.
Backend source commit b5dddde81878ba0a0dfd13db24f59231a40593ea; owner control d217f5f8dfe3a2b0358f2bceb4bef2178cfcf2a3.
These are changes and test evidence, not an installable package or a complete independent checkout.
Backend deployed; native compilation pending at time of source export.
No game binaries, credentials or signing keys included.
