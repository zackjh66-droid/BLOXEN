CREATE TABLE `client_diagnostic_report` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`device_id` text NOT NULL,
	`received_at` integer NOT NULL,
	`content_hash` text NOT NULL,
	`report` text NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `diagnostic_user_hash` ON `client_diagnostic_report` (`user_id`,`content_hash`);--> statement-breakpoint
CREATE INDEX `diagnostic_received` ON `client_diagnostic_report` (`received_at`);