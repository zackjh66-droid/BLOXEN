import {test,after} from 'node:test';
import assert from 'node:assert/strict';
import {Miniflare,Log,LogLevel,convertV4MiniflareOptions} from 'miniflare';
import {readFile,mkdtemp,rm,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes,createHmac} from 'node:crypto';
const origin='https://hollowwake.test',directory=await mkdtemp(join(tmpdir(),'hw-diagnostics-')),secret=randomBytes(48).toString('hex');let mf,db;
const report={schema:1,build:'6.21-CL-4526925',packageVersion:'0.5.2.0',attemptId:'a'.repeat(32),trigger:'launch_return',runtime:'native-packaged',entryReported:false,previousAttemptIncomplete:false,events:[{kind:'NATIVE_PROXY_BLOCKED',name:'KERNEL32.dll!__chkstk',values:{}}],missing:[{name:'KERNEL32.dll!__chkstk',source:'redirected',error:127,normal:true,main:true}],counts:{platformTotal:838,platformMissing:42,redirectedMissing:1,eventsOmitted:0}};
async function request(path,body,token,cookie){const headers={Origin:origin,...(body===undefined?{}:{'Content-Type':'application/json'}),...(token?{Authorization:'Bearer '+token}:{}),...(cookie?{Cookie:cookie}:{})};const r=await mf.dispatchFetch(origin+path,{method:body===undefined?'GET':'POST',headers,...(body===undefined?{}:{body:JSON.stringify(body)})});return{r,b:await r.json()};}
test('diagnostic migration and linked-device fixtures use real Better Auth validation',async()=>{
 mf=new Miniflare(convertV4MiniflareOptions({scriptPath:'dist/server/index.js',modules:true,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],cf:false,log:new Log(LogLevel.NONE),d1Databases:{DB:'diagnostics'},resourcePersistencePath:directory,unsafeEnableSharedStorage:true,bindings:{PUBLIC_ORIGIN:origin,BETTER_AUTH_SECRET:secret,ADMIN_RPC_SECRET:secret}}));await mf.ready;db=await mf.getD1Database('DB');
 for(const file of (await readdir('drizzle')).filter(x=>x.endsWith('.sql')).sort()){const sql=await readFile('drizzle/'+file,'utf8');await db.batch(sql.split('--> statement-breakpoint').map(x=>x.trim()).filter(Boolean).map(x=>db.prepare(x)));}
 for(const id of ['alice','bob']){await db.prepare('INSERT INTO user(id,name,email,emailVerified,createdAt,updatedAt,username) VALUES(?,?,?,0,?,?,?)').bind(id,id,id+'@fixture.test',Date.now(),Date.now(),id).run();for(const suffix of ['browser','device']){const s=id+'-'+suffix;await db.prepare('INSERT INTO session(id,expiresAt,token,createdAt,updatedAt,userId) VALUES(?,?,?,?,?,?)').bind(s,Date.now()+86400000,s+'-token',Date.now(),Date.now(),id).run();if(suffix==='device')await db.prepare('INSERT INTO project_device(session_id,user_id,label,created_at,last_seen_at) VALUES(?,?,?,?,?)').bind(s,id,'Original diagnostics fixture',Date.now(),Date.now()).run();}}
});
let reportId;
test('automatic uploads require linked device; duplicate uploads retain one actual report',async()=>{
 assert.equal((await request('/api/device/diagnostics',report)).r.status,401);
 assert.equal((await request('/api/device/diagnostics',report,'alice-browser-token')).r.status,401);
 let q=await request('/api/device/diagnostics',report,'alice-device-token');assert.equal(q.r.status,200,JSON.stringify(q.b));reportId=q.b.reportId;assert.equal(q.b.executionVerified,false);
 q=await request('/api/device/diagnostics',report,'alice-device-token');assert.equal(q.b.reportId,reportId);assert.equal((await db.prepare('SELECT COUNT(*) n FROM client_diagnostic_report').first()).n,1);
});
test('raw logs, credentials, URLs, arbitrary fields and malformed bindings are rejected',async()=>{
 for(const data of [{...report,password:'must-not-store'},{...report,rawLog:'Bearer must-not-store'},{...report,missing:[{...report.missing[0],name:'https://example.invalid/token'}]},{...report,events:[{kind:'NATIVE_CRASH',values:{access_token:'must-not-store'}}]},{...report,events:[{kind:'NATIVE_CRASH',values:{code:'not-an-integer-token'}}]}])assert.equal((await request('/api/device/diagnostics',data,'alice-device-token')).r.status,400);
 const rows=await db.prepare('SELECT report FROM client_diagnostic_report').all();assert.equal(rows.results.length,1);assert.ok(!rows.results[0].report.includes('must-not-store'));
});
test('browser report reads are account-scoped and owner RPC remains signed',async()=>{
 assert.equal((await request('/api/diagnostics')).r.status,401);assert.equal((await request('/api/diagnostics',undefined,'alice-device-token')).r.status,401);
 const cookie=id=>'__Secure-hollowwake.session_token='+id+'.'+createHmac('sha256',secret).update(id).digest('base64');
 let q=await request('/api/diagnostics',undefined,undefined,cookie('alice-browser-token'));assert.equal(q.r.status,200,JSON.stringify(q.b));assert.equal(q.b.reports[0].id,reportId);
 q=await request('/api/diagnostics',undefined,undefined,cookie('bob-browser-token'));assert.equal(q.r.status,200);assert.equal(q.b.reports.length,0);
 assert.equal((await request('/api/control/rpc',{action:'diagnostics.list'})).r.status,401);
 const data={action:'diagnostics.detail',id:reportId},raw=JSON.stringify(data),time=String(Date.now()),nonce=randomBytes(16).toString('hex'),actor='owner-fixture';const signature=createHmac('sha256',secret).update(`POST\n/api/control/rpc\n${time}\n${nonce}\n${actor}\n${raw}`).digest('hex');
 const response=await mf.dispatchFetch(origin+'/api/control/rpc',{method:'POST',headers:{'Content-Type':'application/json','X-HW-Time':time,'X-HW-Nonce':nonce,'X-HW-Actor':actor,'X-HW-Signature':signature},body:raw});assert.equal(response.status,200);const result=await response.json();assert.equal(result.report.missing[0].name,'KERNEL32.dll!__chkstk');
});
test('upload throttling and revocation apply to real device sessions',async()=>{
 let limited=false;for(let i=0;i<62;i++){const q=await request('/api/device/diagnostics',{...report,attemptId:'b'.repeat(32)},'bob-device-token');if(q.r.status===429){limited=true;break;}assert.equal(q.r.status,200);}assert.ok(limited);
 await db.prepare('DELETE FROM session WHERE id=?').bind('alice-device').run();assert.equal((await request('/api/device/diagnostics',report,'alice-device-token')).r.status,401);
});
after(async()=>{await mf?.dispose();await rm(directory,{recursive:true,force:true});});
