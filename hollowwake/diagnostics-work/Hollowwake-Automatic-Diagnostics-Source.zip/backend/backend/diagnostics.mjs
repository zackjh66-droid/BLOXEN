// Only structured loader diagnostics are accepted: never arbitrary log text,
// credentials, file contents, command lines, URLs or process environment data.
import {createHash,randomUUID} from 'node:crypto';
const kinds=new Set('ATTEMPT_BEGIN NATIVE_PREFLIGHT NATIVE_PLATFORM_PREFLIGHT NATIVE_PROXY_BLOCKED NATIVE_LOAD_BLOCKED NATIVE_LOAD_FAILED NATIVE_LOAD_EXCEPTION NATIVE_STARTUP_FAILED NATIVE_STARTUP_BOUND NATIVE_THREAD_FAILED NATIVE_ENTRY NATIVE_CRASH NATIVE_LOAD NATIVE_STARTUP NATIVE_ROUTE DEPENDENCY IMPORT UNWIND PROTECT HASH MAP RELOC STOP CALLED_UNSUPPORTED CRASH EXECUTE CLIENT_NOT_READY USER_REQUESTED CONTENT_READY CONTENT_FAILED OTHER_NATIVE_FAILURE'.split(' '));
const triggers=new Set(['launch_return','next_start','preflight','before_entry','manual']);
const sources=new Set(['redirected','platform']);
const valueKeys=new Set(['code','error','HRESULT','Win32','RVA','address','bytes','unresolved','total','registered','missing','windowBind','controllerCount']);
const binding=s=>typeof s==='string'&&s.length<=320&&/^[A-Za-z0-9_.-]{1,96}![A-Za-z0-9_?@$#.:~+<>\-]{1,220}$/.test(s);
const integer=v=>Number.isSafeInteger(v)&&v>=0&&v<=1000000;
const error=(code,status=400)=>Object.assign(Error(code),{code,status});
const exact=(object,keys)=>object&&typeof object==='object'&&!Array.isArray(object)&&Object.keys(object).every(k=>keys.includes(k));
export function validateDiagnostic(d){
 if(!exact(d,['schema','build','packageVersion','attemptId','trigger','runtime','entryReported','previousAttemptIncomplete','events','missing','counts'])||d.schema!==1||d.build!=='6.21-CL-4526925'||d.runtime!=='native-packaged'||!/^\d{1,5}(?:\.\d{1,5}){3}$/.test(d.packageVersion||'')||!/^[a-f0-9]{32}$/.test(d.attemptId||'')||!triggers.has(d.trigger)||typeof d.entryReported!=='boolean'||typeof d.previousAttemptIncomplete!=='boolean')throw error('invalid_diagnostic');
 if(!Array.isArray(d.events)||d.events.length>256||!Array.isArray(d.missing)||d.missing.length>2048||!exact(d.counts,['platformTotal','platformMissing','redirectedMissing','eventsOmitted'])||Object.values(d.counts).some(v=>!integer(v)))throw error('invalid_diagnostic');
 for(const e of d.events){
  if(!exact(e,['kind','name','caller','values'])||!kinds.has(e.kind)||e.name!==undefined&&!binding(e.name)||e.caller!==undefined&&!/^[A-Za-z0-9_.-]{1,96}$/.test(e.caller)||!exact(e.values,[...valueKeys])||Object.values(e.values).some(v=>typeof v!=='string'||! /^-?(?:0x)?[0-9a-fA-F]{1,20}$/.test(v)))throw error('invalid_diagnostic');
 }
 for(const e of d.missing)if(!exact(e,['name','source','error','normal','main'])||!binding(e.name)||!sources.has(e.source)||!integer(e.error)||typeof e.normal!=='boolean'||typeof e.main!=='boolean')throw error('invalid_diagnostic');
 return d;
}
export async function diagnosticBody(request){
 if(!request.headers.get('content-type')?.startsWith('application/json'))throw error('json_required',415);
 if(Number(request.headers.get('content-length')||0)>262144)throw error('request_too_large',413);
 const reader=request.body?.getReader();if(!reader)throw error('invalid_json');const parts=[];let total=0;
 try{while(true){const {value,done}=await reader.read();if(done)break;total+=value.length;if(total>262144){await reader.cancel();throw error('request_too_large',413);}parts.push(value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(total);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 let d;try{d=JSON.parse(new TextDecoder().decode(bytes));}catch{throw error('invalid_json');}return validateDiagnostic(d);
}
export async function saveDiagnostic(db,current,report){
 const data=JSON.stringify(report),hash=createHash('sha256').update(data).digest('hex');
 await db.prepare('INSERT OR IGNORE INTO client_diagnostic_report(id,user_id,device_id,received_at,content_hash,report) VALUES(?,?,?,?,?,?)').run(randomUUID(),current.user.id,current.session.id,Date.now(),hash,data);
 const row=await db.prepare('SELECT id,received_at FROM client_diagnostic_report WHERE user_id=? AND content_hash=?').get(current.user.id,hash);
 return {ok:true,reportId:row.id,receivedAt:row.received_at,executionVerified:false};
}
