// Original single-CoreWindow Win32 message bridge. No native desktop HWND APIs.
// One fullscreen surface; partial raw mouse support. Desktop child windows/IME remain unsupported.
#include <windows.h>
#include <string>
#include <vector>
#include <deque>
#include <memory>
#include <mutex>
#include <condition_variable>
#include <cstring>
#include <algorithm>
#include <climits>
static void ReleaseRaw(LPARAM);
static void ReleaseTouch(LPARAM);
static void ResetRaw();
static void ClearRawFocus();
static void ResetSystemMenu();
using Proc=LRESULT(CALLBACK*)(HWND,UINT,WPARAM,LPARAM);
struct ClassW {UINT style;Proc proc;int clsExtra,wndExtra;HINSTANCE instance;HICON icon;HCURSOR cursor;HBRUSH brush;LPCWSTR menu,name;};
struct Msg {HWND window;UINT message;WPARAM wp;LPARAM lp;DWORD time;POINT point;DWORD privateData;};
struct Class {ATOM atom;std::wstring name;Proc proc;HINSTANCE instance;int classExtra=0,windowExtra=0;UINT style=0;std::vector<BYTE> extra;HICON icon=nullptr,smallIcon=nullptr;HCURSOR cursor=nullptr;HBRUSH brush=nullptr;};
struct Window {bool alive,destroying;Proc proc;std::wstring title;bool visible=false,enabled=true;LONG_PTR style=0,extended=0,user=0;HINSTANCE instance=nullptr;DWORD owner=0;std::vector<BYTE> extra;std::wstring cls;ATOM atom=0;HICON icon=nullptr,smallIcon=nullptr;};
struct CreateStruct {void* params;HINSTANCE instance;HMENU menu;HWND parent;int cy,cx,y,x;LONG style;LPCWSTR name,cls;DWORD exStyle;};
static std::recursive_mutex mutex;static std::condition_variable_any wake;static std::vector<Class> classes;static std::unique_ptr<Window> window;static std::deque<Msg> queue;static LONG width=0,height=0;static bool keys[256]={};
static unsigned nextClassAtom=0xc000;static bool hostActive=true;static HWND focused=nullptr,captured=nullptr;
static bool Push(HWND,UINT,WPARAM,LPARAM);
static HWND Handle(){return reinterpret_cast<HWND>(window.get());}
static bool Valid(HWND h){return window&&window->alive&&h==Handle();}
extern "C" __declspec(dllexport) void __cdecl HWViewport(int w,int h){std::lock_guard<std::recursive_mutex> l(mutex);if(w<=0||h<=0||w>32767||h>32767){SetLastError(ERROR_INVALID_PARAMETER);return;}width=w;height=h;if(window&&window->alive)Push(Handle(),5,0,MAKELPARAM(width,height));}
extern "C" __declspec(dllexport) HRESULT __cdecl HWReadViewport(UINT* x,UINT* y){std::lock_guard<std::recursive_mutex> l(mutex);if(!x||!y)return E_POINTER;if(width<=0||height<=0)return E_UNEXPECTED;*x=width;*y=height;return S_OK;}
static bool Push(HWND target,UINT message,WPARAM wp,LPARAM lp){if(queue.size()>=4096){SetLastError(ERROR_NOT_ENOUGH_MEMORY);return false;}queue.push_back({target,message,wp,lp,(DWORD)GetTickCount64(),{0,0},0});wake.notify_all();return true;}
extern "C" __declspec(dllexport) void __cdecl HWKeyDetails(unsigned,unsigned,int,int,int,int,int);
extern "C" __declspec(dllexport) void __cdecl HWCharacterDetails(unsigned,unsigned);
extern "C" __declspec(dllexport) void __cdecl HWKey(unsigned key,int down){HWKeyDetails(key,0,down,1,0,0,0);}
extern "C" __declspec(dllexport) void __cdecl HWChar(unsigned key){HWCharacterDetails(key,0);}
static ATOM WINAPI Register(const ClassW* value){if(!value||!value->name||!value->proc||value->clsExtra<0||value->clsExtra>4096||value->wndExtra<0||value->wndExtra>4096){SetLastError(ERROR_NOT_SUPPORTED);return 0;}std::lock_guard<std::recursive_mutex> l(mutex);for(auto& c:classes)if(!_wcsicmp(c.name.c_str(),value->name)){SetLastError(ERROR_CLASS_ALREADY_EXISTS);return 0;}if(classes.size()>=64){SetLastError(ERROR_NOT_ENOUGH_MEMORY);return 0;}if(nextClassAtom>0xffff){SetLastError(ERROR_NOT_ENOUGH_MEMORY);return 0;}ATOM atom=(ATOM)nextClassAtom++;classes.push_back({atom,value->name,value->proc,value->instance});auto& added=classes.back();added.classExtra=value->clsExtra;added.windowExtra=value->wndExtra;added.style=value->style;added.icon=value->icon;added.cursor=value->cursor;added.brush=value->brush;added.extra.resize(value->clsExtra);return atom;}
static HWND WINAPI Create(DWORD ex,LPCWSTR name,LPCWSTR title,DWORD style,int x,int y,int cx,int cy,HWND parent,HMENU menu,HINSTANCE instance,void* params){
 Proc proc=nullptr;HWND handle;int extras=0;ATOM clsAtom=0;std::wstring className;
 {std::lock_guard<std::recursive_mutex> l(mutex);if(width<=0||height<=0||parent||window){SetLastError(ERROR_NOT_SUPPORTED);return nullptr;}for(auto& c:classes)if(((ULONG_PTR)name<=0xffff?c.atom==(ATOM)(ULONG_PTR)name:!_wcsicmp(c.name.c_str(),name))&&c.instance==instance){proc=c.proc;extras=c.windowExtra;clsAtom=c.atom;className=c.name;}if(!proc){SetLastError(ERROR_CANNOT_FIND_WND_CLASS);return nullptr;}window.reset(new Window{true,false,proc,title?title:L""});ResetSystemMenu();handle=Handle();window->visible=(style&0x10000000)!=0;window->style=style;window->extended=ex;window->instance=instance;window->owner=GetCurrentThreadId();window->extra.resize(extras);window->cls=className;window->atom=clsAtom;}
 CreateStruct create={params,instance,menu,parent,cy,cx,y,x,(LONG)style,title,name,ex};
 if(!proc(handle,0x81,0,(LPARAM)&create)||proc(handle,1,0,(LPARAM)&create)==-1){proc(handle,0x82,0,0);std::lock_guard<std::recursive_mutex> l(mutex);window.reset();return nullptr;}
 {std::lock_guard<std::recursive_mutex> l(mutex);Push(handle,5,0,MAKELPARAM(width,height));}return handle;
}
static BOOL WINAPI Post(HWND h,UINT message,WPARAM wp,LPARAM lp){std::lock_guard<std::recursive_mutex> l(mutex);if(h&&!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}return Push(h,message,wp,lp);}
static void WINAPI Quit(int code){std::lock_guard<std::recursive_mutex> l(mutex);Push(nullptr,0x12,code,0);}
static BOOL WINAPI Peek(Msg* out,HWND h,UINT min,UINT max,UINT flags){if(!out||flags&~1){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}std::lock_guard<std::recursive_mutex> l(mutex);for(auto i=queue.begin();i!=queue.end();++i){if((!h||h==i->window)&&(!min&&!max||(min<=i->message&&i->message<=max))){*out=*i;if(flags&1)queue.erase(i);return TRUE;}}return FALSE;}
static LRESULT WINAPI Dispatch(const Msg* msg){if(!msg)return 0;Proc proc=nullptr;{std::lock_guard<std::recursive_mutex> l(mutex);if(Valid(msg->window))proc=window->proc;}auto result=proc?proc(msg->window,msg->message,msg->wp,msg->lp):0;if(msg->message==0xff)ReleaseRaw(msg->lp);if(msg->message==0x240)ReleaseTouch(msg->lp);return result;}
static BOOL WINAPI Rect(HWND h,RECT* out){std::lock_guard<std::recursive_mutex> l(mutex);if(!out||!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}*out={0,0,width,height};return TRUE;}
static BOOL WINAPI Destroy(HWND h){Proc proc;{std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||window->destroying){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}window->destroying=true;proc=window->proc;}proc(h,2,0,0);proc(h,0x82,0,0);{std::lock_guard<std::recursive_mutex> l(mutex);if(focused==h)focused=nullptr;if(captured==h)captured=nullptr;ResetRaw();window.reset();queue.erase(std::remove_if(queue.begin(),queue.end(),[&](const Msg& m){return m.window==h;}),queue.end());}return TRUE;}
static LRESULT WINAPI Default(HWND h,UINT message,WPARAM wp,LPARAM lp){
 if(message==0x7f||message==0x80){ // WM_GETICON / WM_SETICON: borrowed resource handles.
  std::lock_guard<std::recursive_mutex> lock(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}
  if(wp>1&&!(message==0x7f&&wp==2)){SetLastError(ERROR_INVALID_PARAMETER);return 0;}
  auto& icon=wp==1?window->icon:window->smallIcon;auto prior=icon;if(message==0x80)icon=reinterpret_cast<HICON>(lp);return reinterpret_cast<LRESULT>(prior);
 }
if(message==0x240){ReleaseTouch(lp);return 0;}if(message==0xff){ReleaseRaw(lp);return 0;}if(message==0x81)return TRUE;if(message==0x10){Destroy(h);return 0;}if(message==0x83||message>=0x400)return 0;SetLastError(ERROR_NOT_SUPPORTED);return 0;}
static BOOL WINAPI Get(Msg* out,HWND h,UINT min,UINT max){if(!out){SetLastError(ERROR_INVALID_PARAMETER);return -1;}std::unique_lock<std::recursive_mutex> l(mutex);for(;;){for(auto i=queue.begin();i!=queue.end();++i)if(i->message==0x12||((!h||h==i->window)&&(!min&&!max||(min<=i->message&&i->message<=max)))){*out=*i;queue.erase(i);return out->message==0x12?0:1;}wake.wait(l);}}
static SHORT WINAPI KeyState(int key){std::lock_guard<std::recursive_mutex> l(mutex);return key>=0&&key<256&&keys[key]?(SHORT)0x8000:0;}

// State is scoped to the single virtual fullscreen CoreWindow. These are not
// desktop HWNDs, monitor handles or assertions that every USER32 API is supported.
extern "C" __declspec(dllexport) void __cdecl HWHostActivation(int active){std::lock_guard<std::recursive_mutex> l(mutex);hostActive=active!=0;if(!hostActive){ClearRawFocus();memset(keys,0,sizeof(keys));focused=nullptr;captured=nullptr;}if(window&&window->alive){Push(Handle(),0x1c,hostActive,0);Push(Handle(),6,hostActive?1:0,0);if(hostActive&&window->visible&&window->enabled){focused=Handle();Push(Handle(),7,0,0);}}}
static BOOL WINAPI Is(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);return Valid(h);}
static BOOL WINAPI Enabled(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);return Valid(h)&&window->enabled;}
static BOOL WINAPI Iconic(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h))SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}
static BOOL WINAPI Zoomed(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);return Valid(h)&&(window->style&0x1000000)!=0;}
static HWND WINAPI Parent(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h))SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}
static BOOL WINAPI Child(HWND a,HWND b){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(a)||!Valid(b))SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}
static BOOL WINAPI Enable(HWND h,BOOL value){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}bool previous=window->enabled;window->enabled=value!=0;if(window->enabled)window->style&=~(LONG_PTR)0x08000000;else window->style|=0x08000000;if(!window->enabled){if(focused==h){focused=nullptr;Push(h,8,0,0);}if(captured==h)captured=nullptr;}if(previous!=window->enabled)Push(h,0xa,window->enabled,0);return !previous;}
static BOOL WINAPI Show(HWND h,int command){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}if(command!=0&&command!=1&&command!=3&&command!=5&&command!=8&&command!=9&&command!=4&&command!=10){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}bool prior=window->visible;window->visible=command!=0;if(window->visible)window->style|=0x10000000;else window->style&=~(LONG_PTR)0x10000000;if(command==3)window->style|=0x1000000;else if(command==1||command==9)window->style&=~(LONG_PTR)0x1000000;if(prior!=window->visible)Push(h,0x18,window->visible,0);return prior;}
static HWND WINAPI Focus(){std::lock_guard<std::recursive_mutex> l(mutex);return hostActive&&window&&window->owner==GetCurrentThreadId()?focused:nullptr;}
static HWND WINAPI SetFocusBridge(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(h&&(!Valid(h)||!window->enabled||window->owner!=GetCurrentThreadId())){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}auto prior=focused;focused=h;if(prior!=h){if(prior)Push(prior,8,(WPARAM)h,0);if(h)Push(h,7,(WPARAM)prior,0);}return prior;}
static HWND WINAPI Active(){std::lock_guard<std::recursive_mutex> l(mutex);return hostActive&&window&&window->alive&&window->visible?Handle():nullptr;}
static HWND WINAPI SetActive(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);auto old=Active();if(h&&!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}hostActive=h!=nullptr;if(window)Push(Handle(),6,hostActive?1:0,0);return old;}
static BOOL WINAPI Foreground(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}if(!hostActive){SetLastError(ERROR_ACCESS_DENIED);return FALSE;}SetFocusBridge(h);return TRUE;}
static HWND WINAPI Capture(){std::lock_guard<std::recursive_mutex> l(mutex);return captured;}
static HWND WINAPI SetCaptureBridge(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}auto prior=captured;captured=h;return prior;}
static BOOL WINAPI ReleaseCaptureBridge(){std::lock_guard<std::recursive_mutex> l(mutex);auto prior=captured;captured=nullptr;if(prior)Push(prior,0x215,0,0);return TRUE;}
static LONG_PTR WINAPI GetLong(HWND h,int index){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}if(index>=0){if((size_t)index+sizeof(LONG_PTR)>window->extra.size()){SetLastError(ERROR_INVALID_INDEX);return 0;}LONG_PTR value=0;memcpy(&value,window->extra.data()+index,sizeof(value));return value;}switch(index){case -4:return (LONG_PTR)window->proc;case -6:return (LONG_PTR)window->instance;case -8:return 0;case -16:return window->style;case -20:return window->extended;case -21:return window->user;default:SetLastError(ERROR_INVALID_INDEX);return 0;}}
static LONG_PTR WINAPI SetLong(HWND h,int index,LONG_PTR value){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}if(index>=0){auto prior=GetLong(h,index);if((size_t)index+sizeof(value)>window->extra.size()){SetLastError(ERROR_INVALID_INDEX);return 0;}memcpy(window->extra.data()+index,&value,sizeof(value));return prior;}auto prior=GetLong(h,index);switch(index){case -4:if(!value){SetLastError(ERROR_INVALID_PARAMETER);return 0;}window->proc=(Proc)value;break;case -16:window->style=value;break;case -20:window->extended=value;break;case -21:window->user=value;break;default:SetLastError(ERROR_NOT_SUPPORTED);return 0;}return prior;}
static LONG WINAPI GetLong32(HWND h,int index){std::lock_guard<std::recursive_mutex> l(mutex);if(index<0)return (LONG)GetLong(h,index);if(!Valid(h)||(size_t)index+4>window->extra.size()){SetLastError(ERROR_INVALID_INDEX);return 0;}LONG value=0;memcpy(&value,window->extra.data()+index,4);return value;}static LONG WINAPI SetLong32(HWND h,int index,LONG value){std::lock_guard<std::recursive_mutex> l(mutex);if(index>=0){auto prior=GetLong32(h,index);if(!Valid(h)||(size_t)index+4>window->extra.size()){SetLastError(ERROR_INVALID_INDEX);return 0;}memcpy(window->extra.data()+index,&value,4);return prior;}if(index==-4||index==-6||index==-8||index==-21){SetLastError(ERROR_NOT_SUPPORTED);return 0;}return (LONG)SetLong(h,index,value);}
static DWORD WINAPI Owner(HWND h,DWORD* process){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){if(process)*process=0;SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}if(process)*process=GetCurrentProcessId();return window->owner;}
static BOOL WINAPI Text(HWND h,LPCWSTR title){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!title){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}auto size=wcsnlen_s(title,32768);if(size==32768){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}window->title.assign(title,size);return TRUE;}
static BOOL WINAPI Coordinates(HWND h,POINT* point){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!point){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}return TRUE; /* Fullscreen client/screen origins coincide. */}
static HWND WINAPI FromPoint(POINT p){std::lock_guard<std::recursive_mutex> l(mutex);return window&&window->alive&&window->visible&&p.x>=0&&p.y>=0&&p.x<width&&p.y<height?Handle():nullptr;}
static BOOL WINAPI Unregister(LPCWSTR name,HINSTANCE instance){std::lock_guard<std::recursive_mutex> l(mutex);if(!name){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}for(auto i=classes.begin();i!=classes.end();++i)if(((ULONG_PTR)name<=65535?i->atom==(ATOM)(ULONG_PTR)name:i->name==name)&&i->instance==instance){if(window&&window->alive){SetLastError(ERROR_CLASS_HAS_WINDOWS);return FALSE;}classes.erase(i);return TRUE;}SetLastError(ERROR_CLASS_DOES_NOT_EXIST);return FALSE;}

static BOOL WINAPI Adjust(RECT* rect,DWORD style,BOOL menu,DWORD extended){if(!rect||rect->right<rect->left||rect->bottom<rect->top){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}if(menu||(style&0xc40000)||(extended&0x300)){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}return TRUE; /* Borderless fullscreen has no nonclient frame. */}
struct Position {HWND hwnd,after;int x,y,cx,cy;UINT flags;};
static BOOL WINAPI PositionWindow(HWND h,HWND after,int x,int y,int cx,int cy,UINT flags){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return FALSE;}if((!(flags&2)&&(x||y))||(!(flags&1)&&(cx!=width||cy!=height))||(!(flags&4)&&after&&(ULONG_PTR)after!=(ULONG_PTR)-1&&(ULONG_PTR)after!=(ULONG_PTR)-2&&(ULONG_PTR)after!=1)||flags&~0x67ff){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}
 if(flags&0x40)Show(h,5);if(flags&0x80)Show(h,0);if(!(flags&0x10)&&hostActive)SetFocusBridge(h);Push(h,5,0,MAKELPARAM(width,height));return TRUE;
}
struct Placement {UINT size,flags,show;POINT minimum,maximum;RECT normal;};
static BOOL WINAPI GetPlacement(HWND h,Placement* out){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!out||out->size!=sizeof(Placement)){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}out->flags=0;out->show=window->visible?(window->style&0x1000000?3:1):0;out->minimum=out->maximum={0,0};out->normal={0,0,width,height};return TRUE;}
static BOOL WINAPI PutPlacement(HWND h,const Placement* in){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!in||in->size!=sizeof(Placement)){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}if(in->flags||in->normal.left||in->normal.top||in->normal.right!=width||in->normal.bottom!=height){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}SetLastError(0);Show(h,in->show);return GetLastError()==0;}
struct Information {DWORD size;RECT outer,client;DWORD style,extended,status;UINT borderX,borderY;WORD atom,version;};
static BOOL WINAPI Info(HWND h,Information* out){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!out||out->size!=sizeof(Information)){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}out->outer=out->client={0,0,width,height};out->style=(DWORD)window->style;out->extended=(DWORD)window->extended;out->status=hostActive?1:0;out->borderX=out->borderY=0;out->atom=window->atom;out->version=0;return TRUE;}
static HWND WINAPI Top(HWND parent){std::lock_guard<std::recursive_mutex> l(mutex);if(parent){if(!Valid(parent))SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}return window&&window->alive?Handle():nullptr;}
static HWND WINAPI Reparent(HWND h,HWND parent){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}if(parent){SetLastError(ERROR_NOT_SUPPORTED);return nullptr;}SetLastError(0);return nullptr; /* Already a top-level window; previous parent is NULL. */}
static BOOL WINAPI Parameters(UINT action,UINT parameter,void* output,UINT flags){std::lock_guard<std::recursive_mutex> l(mutex);if(action==0x30&&output&&!flags){*(RECT*)output={0,0,width,height};return TRUE;}SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}


struct ClassEx {UINT size,style;Proc proc;int clsExtra,wndExtra;HINSTANCE instance;HICON icon;HCURSOR cursor;HBRUSH brush;LPCWSTR menu,name;HICON small;};
static ATOM WINAPI RegisterEx(const ClassEx* in){if(!in||in->size!=sizeof(ClassEx)){SetLastError(ERROR_INVALID_PARAMETER);return 0;}ClassW value={in->style,in->proc,in->clsExtra,in->wndExtra,in->instance,in->icon,in->cursor,in->brush,in->menu,in->name};auto atom=Register(&value);if(atom){std::lock_guard<std::recursive_mutex> lock(mutex);for(auto& cls:classes)if(cls.atom==atom){cls.smallIcon=in->small;break;}}return atom;}
static LONG_PTR WINAPI ClassLong(HWND h,int index){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}for(auto& cls:classes)if(cls.atom==window->atom){if(index>=0){if((size_t)index+sizeof(LONG_PTR)>cls.extra.size()){SetLastError(ERROR_INVALID_INDEX);return 0;}LONG_PTR value=0;memcpy(&value,cls.extra.data()+index,sizeof(value));return value;}switch(index){case -14:return (LONG_PTR)cls.icon;case -34:return (LONG_PTR)cls.smallIcon;case -12:return (LONG_PTR)cls.cursor;case -10:return (LONG_PTR)cls.brush;case -24:return (LONG_PTR)cls.proc;case -16:return (LONG_PTR)cls.instance;case -32:return cls.atom;case -26:return cls.style;case -18:return cls.windowExtra;case -20:return cls.classExtra;default:SetLastError(ERROR_NOT_SUPPORTED);return 0;}}SetLastError(ERROR_CLASS_DOES_NOT_EXIST);return 0;}
static int WINAPI ClassName(HWND h,LPWSTR text,int capacity){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!text||capacity<=0){SetLastError(ERROR_INVALID_PARAMETER);return 0;}auto length=(std::min)(window->cls.size(),(size_t)capacity-1);std::wmemcpy(text,window->cls.c_str(),length);text[length]=0;return (int)length;}
static int WINAPI Title(HWND h,LPWSTR text,int capacity){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)||!text||capacity<=0){SetLastError(ERROR_INVALID_PARAMETER);return 0;}auto length=(std::min)(window->title.size(),(size_t)capacity-1);std::wmemcpy(text,window->title.c_str(),length);text[length]=0;return (int)length;}
static int WINAPI TitleLength(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}return (int)window->title.size();}
static BOOL WINAPI Visible(HWND h){std::lock_guard<std::recursive_mutex> l(mutex);return Valid(h)&&window->visible;}
using Enumeration=BOOL(CALLBACK*)(HWND,LPARAM);
static BOOL WINAPI Enumerate(Enumeration callback,LPARAM value){HWND h=nullptr;{std::lock_guard<std::recursive_mutex> l(mutex);if(!callback){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}if(window&&window->alive)h=Handle();}return h?callback(h,value):TRUE;}
static BOOL WINAPI EnumerateChildren(HWND parent,Enumeration callback,LPARAM value){if(!parent)return Enumerate(callback,value);std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(parent)||!callback){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}return TRUE; /* This virtual namespace contains no child HWNDs. */}
static BOOL WINAPI EnumerateThread(DWORD thread,Enumeration callback,LPARAM value){std::lock_guard<std::recursive_mutex> l(mutex);if(!callback){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}return window&&window->alive&&window->owner==thread?callback(Handle(),value):TRUE;}
static HWND WINAPI Find(LPCWSTR cls,LPCWSTR title){std::lock_guard<std::recursive_mutex> l(mutex);if(!window||!window->alive)return nullptr;if(cls&&((ULONG_PTR)cls<=65535?window->atom!=(ATOM)(ULONG_PTR)cls:_wcsicmp(cls,window->cls.c_str())!=0))return nullptr;if(title&&_wcsicmp(title,window->title.c_str()))return nullptr;return Handle();}
static HWND WINAPI FindEx(HWND parent,HWND after,LPCWSTR cls,LPCWSTR title){std::lock_guard<std::recursive_mutex> l(mutex);if(parent||after)return nullptr;return Find(cls,title);}
static LRESULT WINAPI Call(Proc proc,HWND h,UINT message,WPARAM wp,LPARAM lp){if(!proc||(ULONG_PTR)proc<=65535){SetLastError(ERROR_INVALID_PARAMETER);return 0;}return proc(h,message,wp,lp);}
static LRESULT WINAPI Send(HWND h,UINT message,WPARAM wp,LPARAM lp){Proc proc=nullptr;{std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return 0;}if(window->owner!=GetCurrentThreadId()){SetLastError(ERROR_NOT_SUPPORTED);return 0;}proc=window->proc;}return proc(h,message,wp,lp);}
static BOOL WINAPI PostThread(DWORD owner,UINT message,WPARAM wp,LPARAM lp){std::lock_guard<std::recursive_mutex> l(mutex);if(!window||window->owner!=owner){SetLastError(ERROR_INVALID_THREAD_ID);return FALSE;}return Push(nullptr,message,wp,lp);}
static BOOL WINAPI EmptyRectangle(RECT* value){if(!value){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}*value={0,0,0,0};return TRUE;}
static BOOL WINAPI RectangleEmpty(const RECT* value){if(!value){SetLastError(ERROR_INVALID_PARAMETER);return TRUE;}return value->left>=value->right||value->top>=value->bottom;}
static BOOL WINAPI RectanglesEqual(const RECT* a,const RECT* b){if(!a||!b){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}return a->left==b->left&&a->top==b->top&&a->right==b->right&&a->bottom==b->bottom;}
static BOOL WINAPI PointInside(const RECT* value,POINT point){return value&&point.x>=value->left&&point.x<value->right&&point.y>=value->top&&point.y<value->bottom;}
static BOOL WINAPI Intersection(RECT* out,const RECT* a,const RECT* b){if(!out||!a||!b){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}RECT value={(std::max)(a->left,b->left),(std::max)(a->top,b->top),(std::min)(a->right,b->right),(std::min)(a->bottom,b->bottom)};if(RectangleEmpty(&value)){*out={0,0,0,0};return FALSE;}*out=value;return TRUE;}
static BOOL WINAPI Offset(RECT* value,int x,int y){if(!value){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}long long parts[]={(long long)value->left+x,(long long)value->top+y,(long long)value->right+x,(long long)value->bottom+y};for(auto p:parts)if(p<(-2147483647LL-1)||p>2147483647LL){SetLastError(ERROR_ARITHMETIC_OVERFLOW);return FALSE;}*value={(LONG)parts[0],(LONG)parts[1],(LONG)parts[2],(LONG)parts[3]};return TRUE;}
static BOOL WINAPI Inflate(RECT* value,int x,int y){if(!value){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}long long parts[]={(long long)value->left-x,(long long)value->top-y,(long long)value->right+x,(long long)value->bottom+y};for(auto p:parts)if(p<(-2147483647LL-1)||p>2147483647LL){SetLastError(ERROR_ARITHMETIC_OVERFLOW);return FALSE;}*value={(LONG)parts[0],(LONG)parts[1],(LONG)parts[2],(LONG)parts[3]};return TRUE;}

static int virtualMonitor;
static HMONITOR WINAPI MonitorWindow(HWND h,DWORD flags){std::lock_guard<std::recursive_mutex> l(mutex);if(!Valid(h)&&!(flags&3)){SetLastError(ERROR_INVALID_WINDOW_HANDLE);return nullptr;}return width>0&&height>0?(HMONITOR)&virtualMonitor:nullptr;}
static HMONITOR WINAPI MonitorPoint(POINT p,DWORD flags){std::lock_guard<std::recursive_mutex> l(mutex);return width>0&&height>0&&((p.x>=0&&p.y>=0&&p.x<width&&p.y<height)||(flags&3))?(HMONITOR)&virtualMonitor:nullptr;}
static HMONITOR WINAPI MonitorRect(const RECT* p,DWORD flags){if(!p){SetLastError(ERROR_INVALID_PARAMETER);return nullptr;}return MonitorPoint({p->left,p->top},flags);}
struct MonitorInfo {DWORD size;RECT monitor,work;DWORD flags;wchar_t device[32];};
static BOOL WINAPI MonitorInformation(HMONITOR h,MonitorInfo* info){std::lock_guard<std::recursive_mutex> l(mutex);if(h!=(HMONITOR)&virtualMonitor||!info||(info->size!=40&&info->size!=104)){SetLastError(ERROR_INVALID_PARAMETER);return FALSE;}info->monitor=info->work={0,0,width,height};info->flags=1;if(info->size==104)wcscpy_s(info->device,L"HollowwakeCoreWindow");return TRUE;}
using MonitorProc=BOOL(CALLBACK*)(HMONITOR,HDC,RECT*,LPARAM);
static BOOL WINAPI Monitors(HDC dc,const RECT* clip,MonitorProc proc,LPARAM data){std::lock_guard<std::recursive_mutex> l(mutex);if(dc||!proc||width<=0||height<=0){SetLastError(ERROR_NOT_SUPPORTED);return FALSE;}RECT r={0,0,width,height};if(clip){r.left=(std::max)(r.left,clip->left);r.top=(std::max)(r.top,clip->top);r.right=(std::min)(r.right,clip->right);r.bottom=(std::min)(r.bottom,clip->bottom);}if(r.left>=r.right||r.top>=r.bottom)return TRUE;return proc((HMONITOR)&virtualMonitor,nullptr,&r,data);}
static int WINAPI Metrics(int value){std::lock_guard<std::recursive_mutex> l(mutex);switch(value){case 0:case 16:case 78:return width;case 1:case 17:case 79:return height;case 76:case 77:return 0;case 80:return width>0&&height>0?1:0;default:SetLastError(ERROR_NOT_SUPPORTED);return 0;}}

#include "WindowInput.h"
#include "WindowTouch.h"
#include "WindowCursor.h"
#include "WindowMenu.h"
static void ReleaseTouch(LPARAM token){std::lock_guard<std::recursive_mutex> l(mutex);touchPackets.erase((ULONG_PTR)token);}
static void ReleaseRaw(LPARAM token){std::lock_guard<std::recursive_mutex> l(mutex);rawPackets.erase((ULONG_PTR)token);}
static void ClearRawFocus(){touchPackets.clear();queue.erase(std::remove_if(queue.begin(),queue.end(),[](const Msg& m){return m.message==0x240;}),queue.end());textRecords.clear();rawPackets.clear();pointerButtons=0;queue.erase(std::remove_if(queue.begin(),queue.end(),[](const Msg& m){return m.message==0xff;}),queue.end());}
static void ResetRaw(){touchRegistered=false;ClearRawFocus();mouseRegistered=false;mouseRegistration={};}

void* ResolveWindowImport(const char* dll,const char* name){if(_stricmp(dll,"USER32.dll"))return nullptr;
 #define ENTRY(n,f) if(!strcmp(name,n))return reinterpret_cast<void*>(&f)
 ENTRY("GetSystemMenu",SystemMenu);ENTRY("EnableMenuItem",EnableSystemItem);ENTRY("GetMenuState",SystemItemState);
 ENTRY("LoadCursorW",LoadStockCursor);ENTRY("SetCursor",SelectCursor);
 ENTRY("RegisterTouchWindow",RegisterTouch);ENTRY("UnregisterTouchWindow",UnregisterTouch);ENTRY("GetTouchInputInfo",TouchInfo);ENTRY("CloseTouchInputHandle",CloseTouch);
 ENTRY("TranslateMessage",TranslateHostMessage);ENTRY("GetRawInputData",RawData);ENTRY("GetRawInputDeviceList",RawDevices);ENTRY("GetRawInputDeviceInfoA",RawDeviceInfoA);ENTRY("RegisterRawInputDevices",RegisterRaw);ENTRY("GetRegisteredRawInputDevices",RegisteredRaw);ENTRY("GetCursorPos",CursorPosition);ENTRY("SetCursorPos",WarpCursor);ENTRY("ShowCursor",CursorVisibility);
 ENTRY("EnumDisplayDevicesW",DisplayDevicesW);ENTRY("EnumDisplayDevicesA",DisplayDevicesA);ENTRY("EnumDisplaySettingsW",DisplaySettings);ENTRY("ChangeDisplaySettingsExW",ChangeSettingsEx);ENTRY("ChangeDisplaySettingsW",ChangeSettings);
 ENTRY("DestroyWindow",Destroy);ENTRY("DefWindowProcW",Default);ENTRY("GetMessageW",Get);ENTRY("RegisterClassW",Register);ENTRY("CreateWindowExW",Create);ENTRY("PostMessageW",Post);ENTRY("PostQuitMessage",Quit);ENTRY("PeekMessageW",Peek);ENTRY("DispatchMessageW",Dispatch);ENTRY("GetClientRect",Rect);ENTRY("GetWindowRect",Rect);ENTRY("GetAsyncKeyState",KeyState);ENTRY("GetKeyState",KeyState);
 ENTRY("IsWindow",Is);ENTRY("IsWindowEnabled",Enabled);ENTRY("IsIconic",Iconic);ENTRY("IsZoomed",Zoomed);ENTRY("GetParent",Parent);ENTRY("IsChild",Child);ENTRY("EnableWindow",Enable);ENTRY("ShowWindow",Show);ENTRY("GetFocus",Focus);ENTRY("SetFocus",SetFocusBridge);ENTRY("GetActiveWindow",Active);ENTRY("GetForegroundWindow",Active);ENTRY("SetActiveWindow",SetActive);ENTRY("SetForegroundWindow",Foreground);ENTRY("GetCapture",Capture);ENTRY("SetCapture",SetCaptureBridge);ENTRY("ReleaseCapture",ReleaseCaptureBridge);ENTRY("GetWindowLongPtrW",GetLong);ENTRY("GetWindowLongW",GetLong32);ENTRY("SetWindowLongPtrW",SetLong);ENTRY("SetWindowLongW",SetLong32);ENTRY("GetWindowThreadProcessId",Owner);ENTRY("SetWindowTextW",Text);ENTRY("ClientToScreen",Coordinates);ENTRY("ScreenToClient",Coordinates);ENTRY("WindowFromPoint",FromPoint);ENTRY("UnregisterClassW",Unregister);ENTRY("MonitorFromWindow",MonitorWindow);ENTRY("MonitorFromPoint",MonitorPoint);ENTRY("MonitorFromRect",MonitorRect);ENTRY("GetMonitorInfoW",MonitorInformation);ENTRY("EnumDisplayMonitors",Monitors);ENTRY("GetSystemMetrics",Metrics);
 ENTRY("AdjustWindowRectEx",Adjust);ENTRY("SetWindowPos",PositionWindow);ENTRY("GetWindowPlacement",GetPlacement);ENTRY("SetWindowPlacement",PutPlacement);ENTRY("GetWindowInfo",Info);ENTRY("GetTopWindow",Top);ENTRY("SetParent",Reparent);ENTRY("SystemParametersInfoW",Parameters);
 ENTRY("RegisterClassExW",RegisterEx);ENTRY("GetClassLongPtrW",ClassLong);ENTRY("GetClassNameW",ClassName);ENTRY("GetWindowTextW",Title);ENTRY("GetWindowTextLengthW",TitleLength);ENTRY("IsWindowVisible",Visible);ENTRY("EnumWindows",Enumerate);ENTRY("EnumChildWindows",EnumerateChildren);ENTRY("EnumThreadWindows",EnumerateThread);ENTRY("FindWindowW",Find);ENTRY("FindWindowExW",FindEx);ENTRY("CallWindowProcW",Call);ENTRY("SendMessageW",Send);ENTRY("PostThreadMessageW",PostThread);ENTRY("SetRectEmpty",EmptyRectangle);ENTRY("IsRectEmpty",RectangleEmpty);ENTRY("EqualRect",RectanglesEqual);ENTRY("PtInRect",PointInside);ENTRY("IntersectRect",Intersection);ENTRY("OffsetRect",Offset);ENTRY("InflateRect",Inflate);
 #undef ENTRY
 return nullptr;
}
static unsigned contractKeys=0;static bool contractCreate=false;
static LRESULT CALLBACK ContractProc(HWND,UINT message,WPARAM wp,LPARAM lp){if(message==0x81){auto c=(CreateStruct*)lp;contractCreate=c&&c->params==(void*)621&&c->name&&!wcscmp(c->name,L"HollowwakeContract");return contractCreate?1:0;}if(message==0x100&&wp==65)++contractKeys;return 0;}
extern "C" __declspec(dllexport) int __cdecl HWWindowContract(){
 ClassW cls={};cls.proc=ContractProc;cls.name=L"HollowwakeContract";if(!Register(&cls))return -1;HWND h=Create(0,cls.name,cls.name,0,0,0,0,0,nullptr,nullptr,nullptr,(void*)621);if(!h)return -2;
 RECT rect={};bool valid=Rect(h,&rect)&&rect.right>0&&rect.bottom>0;HWKey(65,1);bool pressed=(KeyState(65)&0x8000)!=0;Msg msg={};while(Peek(&msg,nullptr,0,0,1))Dispatch(&msg);HWKey(65,0);bool released=KeyState(65)==0;Destroy(h);while(Peek(&msg,nullptr,0,0,1)){};
 return contractCreate&&contractKeys==1&&valid&&pressed&&released?621:-3;
}
