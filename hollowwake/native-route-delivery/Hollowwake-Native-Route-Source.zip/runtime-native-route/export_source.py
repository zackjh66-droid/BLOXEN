from pathlib import Path
import zipfile,json,hashlib,re
root=Path(__file__).parent;project=root.parent
out=project/'native-route-delivery/Hollowwake-Native-Import-Runtime-Source.zip'
allowed={'.cpp','.h','.md','.ps1','.yml','.vcxproj','.def','.py'}
evidence={'all-checks-final.log','native-image-attempt-1.log','native-image-static.json','runtime-results.json','runtime-gap-audit.json','client-http-binding.json','native-proxy-attempt-1.log','native-proxy-attempt-2.log','native-proxy-attempt-3.log','native-proxy-first-pass.log','native-proxy-namespace-pass.log','native-proxy-static.json','native-packaged-entry-build.log','native-proxy-final-checks.log'}
files={}
for p in root.rglob('*'):
 if not p.is_file() or '__pycache__' in p.parts:continue
 rel=p.relative_to(root)
 if rel.parts[0]=='evidence':
  if p.name not in evidence:continue
 elif p.suffix not in allowed:continue
 if p.name in {'publish.py','package_followup.py','export_source.py'}:continue
 files['hollowwake/runtime-native-route/'+rel.as_posix()]=p.read_bytes()
for source in [project/'experimental-0.4.7/Native',project/'client-runtime/graphics']:
 for p in source.rglob('*'):
  if p.is_file() and p.suffix in {'.cpp','.h','.vcxproj','.ps1','.def'} and not {'bin','obj'}&set(p.relative_to(source).parts):files['hollowwake/'+p.relative_to(project).as_posix()]=p.read_bytes()
for target,source in [('Runtime.cpp','Runtime.integration.cpp'),('Native.vcxproj','Native.integration.vcxproj'),('ModuleLoader.cpp','ModuleLoader.integration.cpp'),('ModuleLoader.h','ModuleLoader.integration.h'),('Dependencies.cpp','Dependencies.integration.cpp')]:files['hollowwake/experimental-0.4.7/Native/'+target]=(root/source).read_bytes()
for target,source in [('CoreWindowBridge.cpp','CoreWindowBridge.integration.cpp'),('CoreWindowBridge.h','CoreWindowBridge.integration.h'),('GuestImports.cpp','GuestImports.integration.cpp')]:files['hollowwake/client-runtime/graphics/'+target]=(root/source).read_bytes()
files['.github/workflows/hollowwake-native-system.yml']=(root/'workflow.yml').read_bytes()
for name,data in files.items():
 if b'-----BEGIN PRIVATE KEY-----' in data or re.search(rb'gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{30,}',data):raise RuntimeError('Possible credential marker; export stopped')
 if Path(name).suffix.lower() in {'.exe','.dll','.appx','.msix','.pfx','.p12'}:raise RuntimeError('Executable/package/key export prohibited')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert 'hollowwake/experimental-0.4.7/Native/LegacyCrt.h' in z.namelist()
info={'path':str(out),'size':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'files':len(files),'fortniteExecuted':False,'xboxTested':False,'appxProduced':False}
(out.parent/'native-import-export.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
